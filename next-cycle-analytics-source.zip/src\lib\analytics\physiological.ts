import { RidePoint } from "@/types/ride";

// W' Balance Calculation (Skiba 2012 Model approximation)
// Requires CP (Critical Power) and W' (Anaerobic Capacity) from user settings.
// Tau is calculated dynamically or fixed.

interface WPrimeResult {
    balance: number[]; // W' balance at each point (Joules)
    minBalance: number;
}

export function calculateWPrimeBalance(
    points: RidePoint[],
    cp: number,
    wPrime: number
): WPrimeResult | null {
    if (!points || points.length === 0) return null;

    const balances: number[] = [];
    let currentW = wPrime;

    // Need time delta. If points are 1s, dt=1. Ideally use timestamp diff.

    for (let i = 0; i < points.length; i++) {
        const p = points[i];
        const power = p.power || 0;

        let dt = 1;
        if (i > 0) {
            dt = (p.timestamp.getTime() - points[i - 1].timestamp.getTime()) / 1000;
            if (dt <= 0) dt = 1; // Should not happen but safety
        }

        if (power > cp) {
            // Depletion: Simple linear subtraction of work above CP
            const workDoneAboveCP = (power - cp) * dt;
            currentW -= workDoneAboveCP;
        } else {
            // Recovery: Exponential
            // Skiba 2012 Dynamic Tau: Tau = 546 * e^(-0.01 * (CP - P)) + 316
            // But P must be < CP.
            const diff = cp - power;
            // const tau = 546 * Math.exp(-0.01 * diff) + 316; // Skiba 2012 seems to use D_CP = CP - P?
            // Simplified Tau often used is ~300-500s. Let's use dynamic.
            // Note: Difference in Skiba formula is typically (D_CP) where D_CP is power below CP.

            const tau = 546 * Math.exp(-0.01 * diff) + 316;

            // Recovery formula: W_bal(t) = W' - (W' - W_bal_prev) * e^(-t/tau)
            // Here t is dt.
            currentW = wPrime - (wPrime - currentW) * Math.exp(-dt / tau);
        }

        // Clamp
        if (currentW > wPrime) currentW = wPrime;
        if (currentW < 0) currentW = 0; // Usually doesn't go below 0 in model, but physically can? No, exhaustion.

        balances.push(currentW);
    }

    return {
        balance: balances,
        minBalance: Math.min(...balances),
    };
}

// Aerobic Decoupling (Pw:HR)
// EF = NP / Avg HR
// Decoupling = (EF_first_half - EF_second_half) / EF_first_half * 100

export function calculateAerobicDecoupling(points: RidePoint[]): number | null {
    // Need points with both Power and HR
    const validPoints = points.filter(p => p.power !== undefined && p.heartRate !== undefined && p.power > 0); // Ignore zeros? Usually yes for NP?
    // Ideally use raw points (including zeros) for NP, but HR might lag.
    // Standard Pw:HR uses normalized power over average HR.
    // We need to split the ride by DURATION.

    if (validPoints.length < 1200) return null; // Need at least 20 mins of data?

    const totalTime = (validPoints[validPoints.length - 1].timestamp.getTime() - validPoints[0].timestamp.getTime()) / 1000;
    const halfTime = totalTime / 2;

    // Split
    // This is approximation if points are not uniformly spaced.
    // Better to find index where time crosses half.

    const startTime = validPoints[0].timestamp.getTime();
    let splitIndex = 0;
    for (let i = 0; i < validPoints.length; i++) {
        if ((validPoints[i].timestamp.getTime() - startTime) / 1000 > halfTime) {
            splitIndex = i;
            break;
        }
    }

    const firstHalf = validPoints.slice(0, splitIndex);
    const secondHalf = validPoints.slice(splitIndex);

    const calculateEF = (pts: RidePoint[]) => {
        if (pts.length === 0) return 0;
        const avgHr = pts.reduce((sum, p) => sum + (p.heartRate || 0), 0) / pts.length;
        // Simply use Avg Power for MVP if NP is expensive to calc here (need rolling windows).
        // Power:HR decoupling usually uses NP. Let's assume Avg Power for now or calc NP if standardized.
        // To keep simple and robust: Avg Power / Avg HR is distinct from NP/HR but similar concept. Pw:HR specifically maps to NP/HR.
        // Let's implement simple NP.

        // Simple NP calc: 30s rolling avg -> ^4 -> avg -> ^0.25
        // Requires contiguous timeline.
        // Too complex for this snippet? No, let's just use Avg Power for "Efficiency Factor" used in Decoupling for simpler approximation
        // OR strictly implement NP.
        // Let's use Avg Power first for robustness.

        const avgPower = pts.reduce((sum, p) => sum + (p.power || 0), 0) / pts.length;

        if (avgHr === 0) return 0;
        return avgPower / avgHr;
    };

    const ef1 = calculateEF(firstHalf);
    const ef2 = calculateEF(secondHalf);

    if (ef1 === 0) return null;

    return ((ef1 - ef2) / ef1) * 100;
}
