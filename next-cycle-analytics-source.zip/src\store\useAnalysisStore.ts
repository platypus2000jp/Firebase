import { create } from "zustand";
import { RideData, RidePoint } from "@/types/ride";
import { calculateGekizakaFactor, GekizakaResult } from "@/lib/analytics/gekizaka";

interface AnalysisState {
    originalRide: RideData | null;
    filteredRidePoints: RidePoint[];
    range: [number, number]; // Start Dist, End Dist
    gekizaka: GekizakaResult | null;

    // Actions
    setRide: (ride: RideData) => void;
    setRange: (start: number, end: number) => void;
    resetRange: () => void;
}

export const useAnalysisStore = create<AnalysisState>((set, get) => ({
    originalRide: null,
    filteredRidePoints: [],
    range: [0, 0],
    gekizaka: null,

    setRide: (ride) => {
        const maxDist = ride.summary.totalDistance;
        const gekizaka = calculateGekizakaFactor(ride.points); // Initial factor for whole ride
        set({
            originalRide: ride,
            filteredRidePoints: ride.points,
            range: [0, maxDist],
            gekizaka,
        });
    },

    setRange: (start, end) => {
        const { originalRide } = get();
        if (!originalRide) return;

        // Filter points
        // Optimization: Points are sorted by distance? Usually yes.
        // Binary search or simple filter.
        const filtered = originalRide.points.filter(
            (p) => p.distance >= start && p.distance <= end
        );

        // Recalculate dynamic metrics for the range
        const gekizaka = calculateGekizakaFactor(filtered);

        set({
            range: [start, end],
            filteredRidePoints: filtered,
            gekizaka,
        });
    },

    resetRange: () => {
        const { originalRide } = get();
        if (!originalRide) return;
        set({
            range: [0, originalRide.summary.totalDistance],
            filteredRidePoints: originalRide.points,
            gekizaka: calculateGekizakaFactor(originalRide.points),
        });
    },
}));
