import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { RideData } from '@/types/ride';

interface CycleAnalyticsDB extends DBSchema {
    rides: {
        key: string;
        value: RideData;
        indexes: { 'by-date': Date };
    };
}

const DB_NAME = 'next-cycle-analytics-db';
const DB_VERSION = 1;

let dbPromise: Promise<IDBPDatabase<CycleAnalyticsDB>>;

export const getDB = () => {
    if (!dbPromise) {
        dbPromise = openDB<CycleAnalyticsDB>(DB_NAME, DB_VERSION, {
            upgrade(db) {
                const rideStore = db.createObjectStore('rides', { keyPath: 'id' });
                rideStore.createIndex('by-date', 'date');
            },
        });
    }
    return dbPromise;
};

export const saveRide = async (ride: RideData) => {
    const db = await getDB();
    await db.put('rides', ride);
    return ride.id;
};

export const getAllRides = async () => {
    const db = await getDB();
    // Get all keys or summary info? For now whole objects, careful with size.
    // In a real app we'd have a summary store.
    // But raw FIT data is not THAT huge (couple MBs max).
    return db.getAllFromIndex('rides', 'by-date');
};

export const getRide = async (id: string) => {
    const db = await getDB();
    return db.get('rides', id);
};

export const deleteRide = async (id: string) => {
    const db = await getDB();
    await db.delete('rides', id);
};
