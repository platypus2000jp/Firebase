"use client"

import React, { useMemo } from 'react';
import { ResponsiveContainer, ComposedChart, Line, Area, XAxis, YAxis, Tooltip, CartesianGrid, Legend, ReferenceLine } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { calculatePMC } from '@/lib/analytics/pmc';
import { generateMockTSSHistory } from '@/lib/analytics/mockData';

export const PMCChart: React.FC = () => {
    // Local state for simulation
    const [futureTSS, setFutureTSS] = React.useState<number[]>([0, 0, 0, 0, 0, 0, 0]); // Next 7 days
    const [showSim, setShowSim] = React.useState(false);

    // In real app, fetch from DB
    const data = useMemo(() => {
        let history = generateMockTSSHistory();

        // Append future days if sim enabled
        if (showSim) {
            const lastDate = new Date(history[history.length - 1].date);
            const future = futureTSS.map((tss, i) => {
                const d = new Date(lastDate);
                d.setDate(d.getDate() + i + 1);
                return {
                    date: d.toISOString().split('T')[0],
                    tss
                };
            });
            history = [...history, ...future];
        }

        return calculatePMC(history, 50, 50); // Start with assumed fitness
    }, [futureTSS, showSim]);

    const lastPoint = data[data.length - 1];

    // Find "Today" index (approx end of real data)
    // If showSim is false, todayIndex is last index.
    const todayIndex = showSim ? data.length - futureTSS.length - 1 : data.length - 1;

    if (!data.length) return null;

    return (
        <Card className="col-span-full">
            <CardHeader>
                <CardTitle className="flex justify-between items-center flex-wrap gap-4">
                    <span>Performance Management Chart (PMC)</span>
                    <div className="flex gap-4 text-sm font-normal text-muted-foreground items-center">
                        <span className="text-blue-500 font-bold">CTL: {lastPoint.ctl}</span>
                        <span className="text-pink-500 font-bold">ATL: {lastPoint.atl}</span>
                        <span className={`font-bold ${lastPoint.tsb >= 0 ? 'text-yellow-500' : 'text-red-500'}`}>TSB: {lastPoint.tsb}</span>

                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setShowSim(!showSim)}
                            className={showSim ? "bg-accent" : ""}
                        >
                            {showSim ? "Hide Simulator" : "Simulate Future"}
                        </Button>
                    </div>
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="h-[300px] w-full mb-4">
                    <ResponsiveContainer width="100%" height="100%">
                        <ComposedChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                            <XAxis
                                dataKey="date"
                                tickFormatter={(str) => {
                                    const d = new Date(str);
                                    return `${d.getMonth() + 1}/${d.getDate()}`;
                                }}
                                minTickGap={30}
                                stroke="hsl(var(--muted-foreground))"
                            />
                            <YAxis yAxisId="left" stroke="hsl(var(--muted-foreground))" />
                            <YAxis yAxisId="right" orientation="right" stroke="hsl(var(--muted-foreground))" />

                            <Tooltip
                                contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))' }}
                                labelStyle={{ color: 'hsl(var(--foreground))' }}
                            />
                            <Legend />

                            {/* TSB Area/Bar */}
                            <Area yAxisId="right" type="monotone" dataKey="tsb" fill="grey" stroke="none" fillOpacity={0.2} name="TSB (Form)" />
                            <ReferenceLine yAxisId="right" y={0} stroke="hsl(var(--muted-foreground))" />

                            {/* Today Line */}
                            {showSim && <ReferenceLine x={data[todayIndex]?.date} stroke="white" strokeDasharray="3 3" label="Today" />}

                            {/* CTL Line */}
                            <Line yAxisId="left" type="monotone" dataKey="ctl" stroke="#3b82f6" strokeWidth={2} dot={false} name="CTL (Fitness)" />

                            {/* ATL Line */}
                            <Line yAxisId="left" type="monotone" dataKey="atl" stroke="#ec4899" strokeWidth={2} dot={false} name="ATL (Fatigue)" />

                        </ComposedChart>
                    </ResponsiveContainer>
                </div>

                {showSim && (
                    <div className="bg-muted/30 p-4 rounded-lg">
                        <h4 className="text-sm font-bold mb-3">Future TSS Planner (Next 7 Days)</h4>
                        <div className="flex gap-2 overflow-x-auto pb-2">
                            {futureTSS.map((tss, i) => (
                                <div key={i} className="flex flex-col gap-1 min-w-[60px]">
                                    <span className="text-xs text-center text-muted-foreground">+ {i + 1}d</span>
                                    <input
                                        type="number"
                                        className="w-full bg-background border rounded px-2 py-1 text-sm text-center"
                                        value={tss}
                                        onChange={(e) => {
                                            const newTSS = [...futureTSS];
                                            newTSS[i] = Number(e.target.value);
                                            setFutureTSS(newTSS);
                                        }}
                                    />
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
};
