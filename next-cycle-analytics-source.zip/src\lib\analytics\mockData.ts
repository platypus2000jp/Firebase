import { DailyTSS } from "@/lib/analytics/pmc";

export const generateMockTSSHistory = (): DailyTSS[] => {
    const today = new Date();
    const history: DailyTSS[] = [];

    // Generate 90 days of history
    for (let i = 90; i >= 0; i--) {
        const d = new Date(today);
        d.setDate(d.getDate() - i);

        // Random TSS patterns to simulate training blocks
        // Weekends harder, rest days on Mon/Fri
        const dayOfWeek = d.getDay();
        let tss = 0;

        if (dayOfWeek === 1 || dayOfWeek === 5) { // Mon/Fri Rest
            tss = 0;
        } else if (dayOfWeek === 0 || dayOfWeek === 6) { // Weekends
            tss = 100 + Math.random() * 100; // 100-200
        } else {
            tss = 40 + Math.random() * 60; // 40-100
        }

        // Add random failures/skips
        if (Math.random() > 0.8) tss = 0;

        history.push({
            date: d.toISOString().split('T')[0],
            tss: Math.round(tss)
        });
    }

    return history;
};
