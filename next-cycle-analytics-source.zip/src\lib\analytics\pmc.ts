export interface DailyTSS {
    date: string; // ISO date string YYYY-MM-DD
    tss: number;
}

export interface PMCDataPoint {
    date: string;
    ctl: number; // Fitness
    atl: number; // Fatigue
    tsb: number; // Form
}

/**
 * Calculate PMC metrics based on a series of daily TSS values.
 * 
 * Formulas:
 * CTL(today) = CTL(yesterday) + (TSS(today) - CTL(yesterday)) / 42
 * ATL(today) = ATL(yesterday) + (TSS(today) - ATL(yesterday)) / 7
 * TSB(today) = CTL(yesterday) - ATL(yesterday)
 * 
 * Note: TSB is usually calculated as yesterday's fitness - yesterday's fatigue for "today's" form, 
 * OR sometimes today's numbers. 
 * Coggan: TSB = CTL - ATL (using today's post-ride numbers gives tomorrow's form, effectively).
 * Standard practice: TSB = CTL - ATL.
 * 
 * We will calculate a rolling series.
 */
export const calculatePMC = (
    history: DailyTSS[],
    startCtl: number = 0,
    startAtl: number = 0
): PMCDataPoint[] => {
    const sortedHistory = [...history].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    if (sortedHistory.length === 0) return [];

    let ctl = startCtl;
    let atl = startAtl;

    const pmcData: PMCDataPoint[] = [];

    // Fill gaps? 
    // Ideally we iterate day by day from start to end.
    const startDate = new Date(sortedHistory[0].date);
    const endDate = new Date(sortedHistory[sortedHistory.length - 1].date);

    // Iterate day by day
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
        const dateStr = d.toISOString().split('T')[0];
        const dayRecord = sortedHistory.find(h => h.date === dateStr);
        const tss = dayRecord ? dayRecord.tss : 0;

        // Exponential Weighted Moving Average
        // CTL time constant = 42 days (default)
        // ATL time constant = 7 days (default)
        ctl = ctl + (tss - ctl) / 42;
        atl = atl + (tss - atl) / 7;
        const tsb = ctl - atl;

        pmcData.push({
            date: dateStr,
            ctl: Number(ctl.toFixed(1)),
            atl: Number(atl.toFixed(1)),
            tsb: Number(tsb.toFixed(1))
        });
    }

    return pmcData;
};
