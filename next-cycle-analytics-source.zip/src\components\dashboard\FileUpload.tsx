"use client"

import React, { useState } from 'react';
import { useAnalysisStore } from '@/store/useAnalysisStore';
import { parseFitFile } from '@/lib/parsers/fitParser';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, FileType, CheckCircle, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { RideData } from '@/types/ride';
import { saveRide } from '@/lib/db';

export const FileUpload: React.FC = () => {
    const { setRide, originalRide } = useAnalysisStore();
    const [isDragging, setIsDragging] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleFile = async (file: File) => {
        setIsLoading(true);
        setError(null);
        try {
            const buffer = await file.arrayBuffer();
            let ride: RideData;

            if (file.name.endsWith('.fit')) {
                ride = await parseFitFile(buffer);
            } else if (file.name.endsWith('.gpx')) {
                const { parseGpxFile } = await import('@/lib/parsers/gpxParser');
                ride = await parseGpxFile(buffer);
            } else {
                throw new Error("Only .fit and .gpx files are currently supported");
            }

            // Set name to filename if not present or generic
            if (!ride.name || ride.name === "GPX Ride" || ride.name === "Activity") {
                ride.name = file.name.replace(/\.(fit|gpx)$/i, '');
            }

            await saveRide(ride);
            setRide(ride);
        } catch (err: any) { // eslint-disable-line @typescript-eslint/no-explicit-any
            console.error(err);
            setError(err.message || "Failed to parse file");
        } finally {
            setIsLoading(false);
        }
    };

    const onDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            handleFile(e.dataTransfer.files[0]);
        }
    };

    const onDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const onDragLeave = () => {
        setIsDragging(false);
    };

    return (
        <Card className="w-full">
            <CardHeader>
                <CardTitle className="text-lg">Upload Ride Data</CardTitle>
            </CardHeader>
            <CardContent>
                <div
                    className={cn(
                        "border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer",
                        isDragging ? "border-primary bg-primary/10" : "border-muted-foreground/25 hover:border-primary/50",
                        originalRide ? "bg-accent/50" : ""
                    )}
                    onDrop={onDrop}
                    onDragOver={onDragOver}
                    onDragLeave={onDragLeave}
                    onClick={() => document.getElementById('file-input')?.click()}
                >
                    <input
                        type="file"
                        id="file-input"
                        className="hidden"
                        accept=".fit,.gpx"
                        onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
                    />

                    <div className="flex flex-col items-center gap-2">
                        {isLoading ? (
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                        ) : originalRide ? (
                            <>
                                <CheckCircle className="h-10 w-10 text-green-500" />
                                <p className="font-medium text-green-500">Analysis Ready: {originalRide.name}</p>
                                <p className="text-xs text-muted-foreground">Click or drop .fit/.gpx to replace</p>
                            </>
                        ) : (
                            <>
                                <Upload className="h-10 w-10 text-muted-foreground" />
                                <p className="text-muted-foreground font-medium">Drag & drop .fit or .gpx file</p>
                                <p className="text-xs text-muted-foreground">or click to browse</p>
                            </>
                        )}
                        {error && (
                            <div className="text-destructive flex items-center gap-1 text-sm mt-2">
                                <AlertCircle className="h-4 w-4" /> {error}
                            </div>
                        )}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};
