import { RidePoint } from "@/types/ride";

export interface HistogramData {
    binStart: number;
    binEnd: number;
    count: number;
    label: string;
}

export function calculateHistogram(
    data: number[],
    binSize: number = 0.5,
    minVal?: number,
    maxVal?: number
): HistogramData[] {
    if (data.length === 0) return [];

    const min = minVal ?? Math.floor(Math.min(...data));
    const max = maxVal ?? Math.ceil(Math.max(...data));

    const bins: HistogramData[] = [];
    // Ensure we cover the range
    for (let start = min; start < max; start += binSize) {
        bins.push({
            binStart: start,
            binEnd: start + binSize,
            count: 0,
            label: `${start.toFixed(1)}`,
        });
    }

    data.forEach((val) => {
        // Find bin
        const binIndex = Math.floor((val - min) / binSize);
        if (binIndex >= 0 && binIndex < bins.length) {
            bins[binIndex].count++;
        } else if (val === max) {
            // Include max value in last bin or create new? usually last bin is inclusive of end if designed so, but here standard [ )
            if (bins.length > 0) bins[bins.length - 1].count++;
        }
    });

    return bins;
}

export interface AggregatedStat {
    label: string;
    value: number;
}

export function calculateAvgSpeedPerGrade(points: RidePoint[], binSize: number = 0.5): AggregatedStat[] {
    // Similar logic to Histogram but summing Speed
    const gradeSpeedMap = new Map<number, { sumSpeed: number; count: number }>();

    points.forEach(p => {
        const binStart = Math.floor(p.grade / binSize) * binSize;
        const current = gradeSpeedMap.get(binStart) || { sumSpeed: 0, count: 0 };
        if (p.speed > 0) { // Only moving speed?
            current.sumSpeed += p.speed;
            current.count++;
            gradeSpeedMap.set(binStart, current);
        }
    });

    // Convert to array and sort
    const result: AggregatedStat[] = [];
    gradeSpeedMap.forEach((val, key) => {
        if (val.count > 0) {
            result.push({
                label: key.toFixed(1),
                value: val.sumSpeed / val.count
            });
        }
    });

    return result.sort((a, b) => parseFloat(a.label) - parseFloat(b.label));
}
