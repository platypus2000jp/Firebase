import AnalysisDashboard from "@/components/dashboard/AnalysisDashboard";

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <AnalysisDashboard />
    </main>
  );
}
