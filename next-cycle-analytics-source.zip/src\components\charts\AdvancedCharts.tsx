"use client"

import React, { useMemo } from 'react';
import { useAnalysisStore } from '@/store/useAnalysisStore';
import {
    ResponsiveContainer, ComposedChart, Line, Area, BarChart, Bar,
    XAxis, YAxis, CartesianGrid, Tooltip, Legend, ScatterChart, Scatter, Cell
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { calculateHistogram, calculateAvgSpeedPerGrade } from '@/lib/analytics/stats';

export const AdvancedCharts: React.FC = () => {
    const { filteredRidePoints } = useAnalysisStore();

    // Prepare data for charts
    // Downsample if too many points for performance? Recharts handles ~1000 ok.
    const chartData = useMemo(() => {
        // Map points to simple objects for Recharts
        return filteredRidePoints.map(p => ({
            dist: (p.distance / 1000).toFixed(2), // km
            alt: p.altitude,
            speed: p.speed,
            grade: p.grade,
            cadence: p.cadence,
            power: p.power,
            hr: p.heartRate
        }));
    }, [filteredRidePoints]);

    const gradeHistogram = useMemo(() => calculateHistogram(filteredRidePoints.map(p => p.grade), 1.0, -5, 20), [filteredRidePoints]);
    const speedPerGrade = useMemo(() => calculateAvgSpeedPerGrade(filteredRidePoints), [filteredRidePoints]);

    if (filteredRidePoints.length === 0) {
        return <div className="text-muted-foreground p-8 text-center">Load data to view charts</div>;
    }

    return (
        <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="grade">Grade Analysis</TabsTrigger>
                <TabsTrigger value="correlation">Correlations</TabsTrigger>
                {/* <TabsTrigger value="power">Power</TabsTrigger> if we have power data */}
                <TabsTrigger value="custom">Custom</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
                <Card>
                    <CardHeader>
                        <CardTitle>Speed & Altitude Profile</CardTitle>
                    </CardHeader>
                    <CardContent className="h-[400px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <ComposedChart data={chartData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--muted-foreground))" opacity={0.2} />
                                <XAxis dataKey="dist" label={{ value: 'Distance (km)', position: 'insideBottomRight', offset: -5 }} minTickGap={30} />
                                <YAxis yAxisId="left" label={{ value: 'Speed (km/h)', angle: -90, position: 'insideLeft' }} stroke="hsl(var(--chart-1))" />
                                <YAxis yAxisId="right" orientation="right" label={{ value: 'Altitude (m)', angle: 90, position: 'insideRight' }} stroke="hsl(var(--chart-2))" />
                                <Tooltip
                                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--card-foreground))' }}
                                />
                                <Legend />
                                <Area yAxisId="right" type="monotone" dataKey="alt" fill="hsl(var(--chart-2))" stroke="hsl(var(--chart-2))" fillOpacity={0.1} name="Altitude" />
                                <Line yAxisId="left" type="monotone" dataKey="speed" stroke="hsl(var(--chart-1))" dot={false} strokeWidth={2} name="Speed" />
                            </ComposedChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="grade">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card>
                        <CardHeader>
                            <CardTitle>Grade Distribution</CardTitle>
                        </CardHeader>
                        <CardContent className="h-[300px]">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={gradeHistogram}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                                    <XAxis dataKey="label" label={{ value: 'Grade (%)', position: 'insideBottom', offset: -5 }} />
                                    <YAxis label={{ value: 'Count', angle: -90, position: 'insideLeft' }} />
                                    <Tooltip cursor={{ fill: 'hsl(var(--muted))', opacity: 0.3 }} contentStyle={{ backgroundColor: 'hsl(var(--card))' }} />
                                    <Bar dataKey="count" fill="hsl(var(--chart-3))" name="Frequency" radius={[4, 4, 0, 0]} />
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle>Avg Speed vs Grade</CardTitle>
                        </CardHeader>
                        <CardContent className="h-[300px]">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={speedPerGrade}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                                    <XAxis dataKey="label" label={{ value: 'Grade (%)', position: 'insideBottom', offset: -5 }} />
                                    <YAxis label={{ value: 'Speed (km/h)', angle: -90, position: 'insideLeft' }} />
                                    <Tooltip cursor={{ fill: 'hsl(var(--muted))', opacity: 0.3 }} contentStyle={{ backgroundColor: 'hsl(var(--card))' }} />
                                    <Bar dataKey="value" fill="hsl(var(--chart-4))" name="Avg Speed" radius={[4, 4, 0, 0]} />
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                </div>
            </TabsContent>

            <TabsContent value="correlation">
                <Card>
                    <CardHeader>
                        <CardTitle>Speed vs Grade Correlation</CardTitle>
                    </CardHeader>
                    <CardContent className="h-[400px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                                <XAxis type="number" dataKey="grade" name="Grade" unit="%" label={{ value: 'Grade (%)', position: 'insideBottom', offset: -5 }} />
                                <YAxis type="number" dataKey="speed" name="Speed" unit="km/h" label={{ value: 'Speed (km/h)', angle: -90, position: 'insideLeft' }} />
                                <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ backgroundColor: 'hsl(var(--card))' }} />
                                <Scatter name="Points" data={chartData} fill="hsl(var(--chart-5))" fillOpacity={0.6} />
                            </ScatterChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="custom">
                <div className="flex items-center justify-center h-[300px] text-muted-foreground">
                    Custom analysis coming soon (User defined axes)
                </div>
            </TabsContent>
        </Tabs>
    );
};
