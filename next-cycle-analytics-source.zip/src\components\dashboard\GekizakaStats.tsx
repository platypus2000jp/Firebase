"use client"

import React from 'react';
import { useAnalysisStore } from '@/store/useAnalysisStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils'; // Assuming cn exists

export const GekizakaStats: React.FC = () => {
    const { gekizaka, range } = useAnalysisStore();

    if (!gekizaka) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle className="text-lg">Gekizaka Factor</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground text-sm">Upload data to analyze hills.</p>
                </CardContent>
            </Card>
        );
    }

    const { factors, details } = gekizaka;
    const labels = ["High Angle (15.5%+)", "Steep (12.5-15%)", "Hard (9.5-12%)", "Climb Score", "Overall Factor"];

    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-bold">Gekizaka Factor</CardTitle>
                <span className="text-xs text-muted-foreground">Range: {(range[1] - range[0]).toFixed(0)}m</span>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-5 gap-2 text-center mb-4">
                    {factors.map((f, i) => (
                        <div key={i} className="flex flex-col items-center p-2 bg-secondary/50 rounded-md">
                            <span className={cn(
                                "text-2xl font-bold",
                                i >= 3 ? "text-primary" : "text-foreground"
                            )}>
                                {f.toFixed(3)}
                            </span>
                            <span className="text-[10px] uppercase text-muted-foreground mt-1 leading-tight">{labels[i]}</span>
                        </div>
                    ))}
                </div>

                <div className="space-y-1 text-xs text-muted-foreground">
                    <p>Total Climbing Dist (3%+): {details.totalRelevantDist.toFixed(1)}m</p>
                    <div className="grid grid-cols-2 gap-x-4">
                        <span>15.5%+: {details.dist155_18.toFixed(1)}m</span>
                        <span>12.5-15%: {details.dist125_15.toFixed(1)}m</span>
                        <span>9.5-12%: {details.dist95_12.toFixed(1)}m</span>
                        <span>6.5-9%: {details.dist65_9.toFixed(1)}m</span>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};
