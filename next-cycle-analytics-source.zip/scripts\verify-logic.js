
const calculateEMA = (todayValue, prevEMA, timeConstant) => {
    return (todayValue - prevEMA) * (1 / timeConstant) + prevEMA;
};

const calculatePMC = (history, startCTL = 0, startATL = 0) => {
    const pmcData = [];
    let prevCTL = startCTL;
    let prevATL = startATL;

    // Sort by date just in case
    const sortedHistory = [...history].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Fill gaps? 
    // Standard PMC assumes daily calculation. If we have gaps, we must simulate decaying on empty days.
    // For this simple test, we assume 'history' contains every day or we handle gaps.
    // Let's see how the implementation handles it. The current implementation in pmc.ts MIGHT NOT handle gaps.
    // Let's test if it handles gaps or if we need to fix it.

    if (sortedHistory.length === 0) return [];

    const firstDate = new Date(sortedHistory[0].date);
    const lastDate = new Date(sortedHistory[sortedHistory.length - 1].date);

    // Create map for easy lookup
    const tssMap = new Map();
    sortedHistory.forEach(d => tssMap.set(d.date.split('T')[0], d.tss));

    const oneDay = 24 * 60 * 60 * 1000;
    let currentDate = firstDate;

    // Loop through every single day from start to end
    while (currentDate <= lastDate) {
        const dateStr = currentDate.toISOString().split('T')[0];
        const tss = tssMap.get(dateStr) || 0;

        const ctl = calculateEMA(tss, prevCTL, 42);
        const atl = calculateEMA(tss, prevATL, 7);
        const tsb = prevCTL - prevATL; // TSB is yesterday's fitness - yesterday's fatigue usually, or today? 
        // Standard definition: TSB = Yesterday's CTL - Yesterday's ATL. Or Today's CTL - Today's ATL?
        // Actually usually TSB = CTL(yesterday) - ATL(yesterday). 
        // But often visualized as TSB(today) = CTL(today) - ATL(today). 
        // Let's check consistency.

        // For this test script, we replicate the logic we WANT.

        pmcData.push({
            date: dateStr,
            ctl: parseFloat(ctl.toFixed(1)),
            atl: parseFloat(atl.toFixed(1)),
            tsb: parseFloat(tsb.toFixed(1))
        });

        prevCTL = ctl;
        prevATL = atl;
        currentDate = new Date(currentDate.getTime() + oneDay);
    }

    return pmcData;
};

// --- Test Cases ---

// 1. Steady State
// If 100 TSS every day, CTL and ATL should converge to 100.
console.log("Test 1: Steady State (100 TSS / 100 days)");
const steadyData = [];
const start = new Date("2024-01-01");
for (let i = 0; i < 100; i++) {
    const d = new Date(start.getTime() + i * 24 * 60 * 60 * 1000);
    steadyData.push({ date: d.toISOString().split('T')[0], tss: 100 });
}
const result1 = calculatePMC(steadyData, 0, 0);
const last1 = result1[result1.length - 1];
console.log(`Day 100 - CTL: ${last1.ctl}, ATL: ${last1.atl}, TSB: ${last1.tsb}`);
if (last1.ctl > 85 && last1.atl > 95) console.log("PASS: Converging correctly.");
else console.log("FAIL: Not converging.");


// 2. Gaps
console.log("\nTest 2: Gaps (100 TSS, then 0 TSS for 10 days)");
// Impl note: My current verify script handles gaps by filling days.
// I need to verify if the APP's pmc.ts handles gaps.
// If the app's code (which I'll copy below to test) doesn't fill gaps, it will be WRONG.
