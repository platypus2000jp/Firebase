
$src = "c:\Dev\Antigravity app\Next-Cycle Analytics"
$destBase = "C:\Users\platypus2000jp\Downloads\Antigravity\Next-Cycle Analytics"
$tempDir = Join-Path $destBase "temp_export"
$zipPath = Join-Path $destBase "next-cycle-analytics-source.zip"

# Clean up previous runs
if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force }
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }

New-Item -ItemType Directory -Path $tempDir | Out-Null

# Robocopy to exclude folders efficiently
# Exclude: node_modules, .next, .git, .firebase, out, .vscode
$excludeDirs = @("node_modules", ".next", ".git", ".firebase", "out", ".vscode", "build")
$excludeFiles = @("*.log", ".DS_Store", "firebase-debug.log", ".env.local", ".env")

# Using robocopy for robustness with exclusions
# /E = recursive, /XD = exclude dirs, /XF = exclude files
$roboArgs = @($src, $tempDir, "/E", "/XD", $excludeDirs, "/XF", $excludeFiles)
& robocopy @roboArgs

# Sanitize .env.local if needed
$envLocalPath = Join-Path $src ".env.local"
if (Test-Path $envLocalPath) {
    Write-Host "Sanitizing .env.local..."
    $content = Get-Content $envLocalPath
    $newContent = @()
    foreach ($line in $content) {
        if ($line -match "^#") {
            $newContent += $line
        } elseif ($line -match "=") {
            $parts = $line -split "=", 2
            $key = $parts[0]
            # Redact value
            $newContent += "$key=YOUR_${key}_HERE"
        } else {
            $newContent += $line
        }
    }
    $newContent | Set-Content (Join-Path $tempDir ".env.example")
}

# Zip
Write-Host "Compressing..."
Compress-Archive -Path "$tempDir\*" -DestinationPath $zipPath

# Cleanup
Remove-Item $tempDir -Recurse -Force

Write-Host "Archive created at: $zipPath"
