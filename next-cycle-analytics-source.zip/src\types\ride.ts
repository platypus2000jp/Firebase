export interface RidePoint {
    timestamp: Date;
    distance: number; // meters
    altitude: number; // meters
    speed: number; // km/h (converted from m/s if needed)
    grade: number; // percentage
    cadence?: number; // rpm
    heartRate?: number; // bpm
    power?: number; // watts
    lat?: number;
    lon?: number;
    // Computed fields for analysis
    timeFromStart?: number; // seconds
}

export interface RideData {
    id: string; // unique ID (uuid)
    name: string;
    date: Date;
    points: RidePoint[];
    summary: {
        totalDistance: number; // meters
        totalTime: number; // seconds
        avgPower?: number;
        normalizedPower?: number;
        avgSpeed?: number;
        avgCadence?: number;
        avgHeartRate?: number;
        maxPower?: number;
        maxHeartRate?: number;
        elevationGain?: number;
        tss?: number;
        if?: number;
        work?: number; // kJ
    };
}
