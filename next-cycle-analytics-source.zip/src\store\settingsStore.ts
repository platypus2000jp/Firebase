import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface UserSettings {
    ftp: number; // Functional Threshold Power (W)
    wPrime: number; // Anaerobic Work Capacity (J)
    weight: number; // kg
    setFtp: (ftp: number) => void;
    setWPrime: (wp: number) => void;
    setWeight: (w: number) => void;
    updateSettings: (settings: Partial<{ ftp: number; wPrime: number; weight: number }>) => void;
}

export const useSettingsStore = create<UserSettings>()(
    persist(
        (set) => ({
            ftp: 250, // Default constants
            wPrime: 20000,
            weight: 70,
            setFtp: (ftp) => set({ ftp }),
            setWPrime: (wPrime) => set({ wPrime }),
            setWeight: (weight) => set({ weight }),
            updateSettings: (newSettings) => set((state) => ({ ...state, ...newSettings })),
        }),
        {
            name: 'next-cycle-settings',
        }
    )
);
