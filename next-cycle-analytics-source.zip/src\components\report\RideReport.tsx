"use client"

import React from 'react';
import { useAnalysisStore } from '@/store/useAnalysisStore';
import { useSettingsStore } from '@/store/settingsStore';
import { calculateAerobicDecoupling } from '@/lib/analytics/physiological';
import { Button } from '@/components/ui/button';
import { Printer } from 'lucide-react';

export const RideReport: React.FC = () => {
    const { originalRide, filteredRidePoints, range, gekizaka } = useAnalysisStore();
    const { ftp, wPrime, weight } = useSettingsStore();

    if (!originalRide) return <div className="p-8 text-center">No data loaded.</div>;

    const summary = originalRide.summary;
    const durationMin = summary.totalTime / 60;
    const distKm = summary.totalDistance / 1000;

    // Recalculate range-specific summary
    // Simple verification: if range is full ride, use summary. Else recalc.
    // For MVP transparency, using whole ride summary often, but let's try to be specific if range selected.
    const isRangeSelected = range[1] - range[0] < summary.totalDistance * 0.99;

    // Decoupling
    const decoupling = filteredRidePoints.length > 600 ? calculateAerobicDecoupling(filteredRidePoints) : null;

    // Power/Weight
    const pwrWeight = summary.avgPower ? (summary.avgPower / weight).toFixed(2) : '-';

    const handlePrint = () => {
        window.print();
    };

    return (
        <div className="max-w-4xl mx-auto bg-white text-black p-8 shadow-lg print:shadow-none print:p-0">
            <div className="flex justify-between items-start mb-8 print:hidden">
                <h1 className="text-2xl font-bold">Ride Report Preview</h1>
                <Button onClick={handlePrint} variant="outline">
                    <Printer className="mr-2 h-4 w-4" /> Print / Save PDF
                </Button>
            </div>

            {/* Header */}
            <div className="border-b-2 border-black pb-4 mb-6 flex justify-between items-end">
                <div>
                    <h1 className="text-4xl font-extrabold uppercase tracking-tight">{originalRide.name}</h1>
                    <p className="text-lg text-gray-600">{originalRide.date.toDateString()}</p>
                </div>
                <div className="text-right">
                    <div className="text-3xl font-bold">{distKm.toFixed(1)} <span className="text-sm font-normal text-gray-500">km</span></div>
                    <div className="text-xl">{durationMin.toFixed(0)} <span className="text-sm font-normal text-gray-500">min</span></div>
                </div>
            </div>

            {/* Key Stats Grid */}
            <div className="grid grid-cols-4 gap-4 mb-8">
                <div className="p-4 bg-gray-100 rounded-lg text-center">
                    <div className="text-xs text-gray-500 uppercase">TSS</div>
                    <div className="text-2xl font-bold">{summary.tss?.toFixed(0) || '-'}</div>
                </div>
                <div className="p-4 bg-gray-100 rounded-lg text-center">
                    <div className="text-xs text-gray-500 uppercase">Intensity (IF)</div>
                    <div className="text-2xl font-bold">{summary.if?.toFixed(2) || '-'}</div>
                </div>
                <div className="p-4 bg-gray-100 rounded-lg text-center">
                    <div className="text-xs text-gray-500 uppercase">Avg Power</div>
                    <div className="text-2xl font-bold">{summary.avgPower?.toFixed(0) || '-'} <span className="text-xs">W</span></div>
                </div>
                <div className="p-4 bg-gray-100 rounded-lg text-center">
                    <div className="text-xs text-gray-500 uppercase">Pw:HR (Decoupling)</div>
                    <div className={`text-2xl font-bold ${decoupling && decoupling > 5 ? 'text-red-600' : ''}`}>
                        {decoupling ? decoupling.toFixed(1) + '%' : '-'}
                    </div>
                </div>
            </div>

            {/* Detailed Analysis Section */}
            <div className="grid grid-cols-2 gap-8 mb-8">
                <div>
                    <h3 className="text-lg font-bold border-b border-gray-300 mb-2 pb-1">Climb Analysis (Gekizaka)</h3>
                    {gekizaka ? (
                        <ul className="space-y-2 text-sm">
                            <li className="flex justify-between">
                                <span>Climb Score (F4)</span>
                                <span className="font-bold">{gekizaka.factors[3].toFixed(2)}</span>
                            </li>
                            <li className="flex justify-between">
                                <span>Hard Climbing (12.5%+)</span>
                                <span className="font-bold">{(gekizaka.details.dist125_15 + gekizaka.details.dist155_18).toFixed(0)} m</span>
                            </li>
                            <li className="flex justify-between">
                                <span>Moderate Climbing (6%+)</span>
                                <span>{gekizaka.details.totalRelevantDist.toFixed(0)} m</span>
                            </li>
                        </ul>
                    ) : <p className="text-sm text-gray-500">No climb data detected.</p>}
                </div>
                <div>
                    <h3 className="text-lg font-bold border-b border-gray-300 mb-2 pb-1">Physio & Efficiency</h3>
                    <ul className="space-y-2 text-sm">
                        <li className="flex justify-between">
                            <span>W&apos; Capacity Setting</span>
                            <span>{wPrime / 1000} kJ</span>
                        </li>
                        <li className="flex justify-between">
                            <span>FTP Setting</span>
                            <span>{ftp} W</span>
                        </li>
                        <li className="flex justify-between">
                            <span>Watts / Kg</span>
                            <span className="font-bold">{pwrWeight} W/kg</span>
                        </li>
                    </ul>
                </div>
            </div>

            {/* Coach's Comment Placeholder */}
            <div className="bg-blue-50 border border-blue-100 p-6 rounded-lg mb-8">
                <h3 className="text-blue-800 font-bold mb-2">Automated Insight</h3>
                <p className="text-blue-900 text-sm leading-relaxed">
                    {summary.tss && summary.tss > 150 ? "This was a high-stress ride. Ensure sufficient recovery." :
                        summary.if && summary.if > 0.85 ? "High intensity effort detected. Good for threshold development." :
                            "A solid base training ride. Consistent effort maintained."}
                    {decoupling && decoupling > 5 ? " Cardiac drift detected (>5%). Aerobic endurance might be a limiter." : ""}
                </p>
            </div>

            <div className="text-center text-xs text-gray-400 mt-12 print:fixed print:bottom-4 print:w-full">
                Generated by Next-Cycle Analytics
            </div>
        </div>
    );
};
