import { RideData, RidePoint } from '@/types/ride';
import { v4 as uuidv4 } from 'uuid';

/**
 * Parse a GPX file string into RideData.
 * Maps:
 * - trkpt lat/lon -> lat, lon
 * - ele -> altitude
 * - time -> timestamp
 * - extensions -> power, cadence, hr (if available in TrackPointExtension)
 */
export const parseGpxFile = async (buffer: ArrayBuffer): Promise<RideData> => {
    const text = new TextDecoder("utf-8").decode(buffer);
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(text, "text/xml");

    const trkpts = xmlDoc.getElementsByTagName("trkpt");
    const points: RidePoint[] = [];

    const name = xmlDoc.querySelector("metadata > name")?.textContent ||
        xmlDoc.querySelector("trk > name")?.textContent ||
        "GPX Ride";

    let totalDist = 0;
    let prevPoint: RidePoint | null = null;
    let maxEle = 0;
    let minEle = 9999;

    // Helper to calc distance between two coords
    const getDist = (lat1: number, lon1: number, lat2: number, lon2: number) => {
        const R = 6371e3; // metres
        const φ1 = lat1 * Math.PI / 180;
        const φ2 = lat2 * Math.PI / 180;
        const Δφ = (lat2 - lat1) * Math.PI / 180;
        const Δλ = (lon2 - lon1) * Math.PI / 180;

        const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    };

    for (let i = 0; i < trkpts.length; i++) {
        const pt = trkpts[i];
        const lat = parseFloat(pt.getAttribute("lat") || "0");
        const lon = parseFloat(pt.getAttribute("lon") || "0");
        const ele = parseFloat(pt.getElementsByTagName("ele")[0]?.textContent || "0");
        const timeStr = pt.getElementsByTagName("time")[0]?.textContent;

        if (!timeStr) continue;

        const timestamp = new Date(timeStr);

        // Extensions (Garmin TrackPointExtension)
        let hr: number | undefined;
        let cad: number | undefined;
        let power: number | undefined;

        // Try standard GPX extensions (ns3, tp1, etc.)
        // This is messy in standard XML DOM without namespaces, so we check simple tags recursively
        const extensions = pt.getElementsByTagName("extensions")[0];
        if (extensions) {
            // Heart Rate
            const hrTag = extensions.querySelector("hr") || extensions.querySelector("ns3\\:hr") || extensions.querySelector("gpxtpx\\:hr");
            if (hrTag) hr = parseFloat(hrTag.textContent || "0");

            // Cadence
            const cadTag = extensions.querySelector("cad") || extensions.querySelector("ns3\\:cad") || extensions.querySelector("gpxtpx\\:cad");
            if (cadTag) cad = parseFloat(cadTag.textContent || "0");

            // Power (sometimes in extensions, sometimes top level depending on schema)
            const powerTag = extensions.querySelector("power") || extensions.querySelector("ns3\\:watts");
            if (powerTag) power = parseFloat(powerTag.textContent || "0");
        }

        let distFromPrev = 0;
        let speed = 0;
        let grade = 0;

        if (prevPoint) {
            distFromPrev = getDist(prevPoint.lat!, prevPoint.lon!, lat, lon);
            totalDist += distFromPrev;

            const timeDiff = (timestamp.getTime() - prevPoint.timestamp.getTime()) / 1000; // seconds
            if (timeDiff > 0) {
                speed = (distFromPrev / timeDiff) * 3.6; // km/h
            }

            const eleDiff = ele - prevPoint.altitude;
            if (distFromPrev > 0) {
                grade = (eleDiff / distFromPrev) * 100;
            }
        }

        if (ele > maxEle) maxEle = ele;
        if (ele < minEle) minEle = ele;

        const newPoint: RidePoint = {
            timestamp,
            distance: totalDist,
            altitude: ele,
            speed,
            grade,
            cadence: cad,
            heartRate: hr,
            power: power,
            lat,
            lon,
            timeFromStart: 0 // Calc later
        };

        points.push(newPoint);
        prevPoint = newPoint;
    }

    // Post-process for averages and timeFromStart
    let totalTime = 0;
    if (points.length > 0) {
        const start = points[0].timestamp.getTime();
        totalTime = (points[points.length - 1].timestamp.getTime() - start) / 1000;
        points.forEach(p => {
            p.timeFromStart = (p.timestamp.getTime() - start) / 1000;
        });
    }

    const summary = {
        totalDistance: totalDist,
        totalTime,
        elevationGain: maxEle - minEle, // simple approx
        avgSpeed: points.reduce((a, b) => a + b.speed, 0) / points.length || 0,
        maxHeartRate: points.reduce((max, p) => Math.max(max, p.heartRate || 0), 0),
        avgHeartRate: points.reduce((a, b) => a + (b.heartRate || 0), 0) / points.filter(p => p.heartRate).length || 0,
        avgPower: points.reduce((a, b) => a + (b.power || 0), 0) / points.filter(p => p.power).length || 0,
        maxPower: points.reduce((max, p) => Math.max(max, p.power || 0), 0),
    };

    return {
        id: uuidv4(),
        name,
        date: points[0]?.timestamp || new Date(),
        points,
        summary
    };
};
