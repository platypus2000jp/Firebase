"use client";

import React from 'react';

// Mock session provider that does nothing but render children
// This allows the app to run in static mode without NextAuth context errors
export function Providers({ children }: { children: React.ReactNode }) {
    return <>{children}</>;
}
