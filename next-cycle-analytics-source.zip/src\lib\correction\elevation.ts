import { RidePoint } from '@/types/ride';

/**
 * Corrects elevation data for a set of ride points using Open-Meteo API.
 * https://open-meteo.com/en/docs/elevation-api
 * 
 * Free tier constraints (check usage):
 * - Non-commercial use is free.
 * - < 10,000 daily reqs.
 * - Batching is efficient.
 */
export const correctElevation = async (points: RidePoint[]): Promise<RidePoint[]> => {
    // Only process points with Lat/Lon
    const validPoints = points.filter(p => p.lat !== undefined && p.lon !== undefined);

    // We shouldn't process massive files point-by-point if not needed.
    // However, for accurate grade/gain, we want resolution.
    // Open-Meteo URL length limit is the bottleneck. ~2000 chars roughly safe.
    // Lat/Lon "52.52" is 5 chars. + comma. ~12 chars per point. 
    // Batch size of 100-200 is safe. Let's go with 100.
    const BATCH_SIZE = 150;

    // Create chunks
    const chunks: RidePoint[][] = [];
    for (let i = 0; i < validPoints.length; i += BATCH_SIZE) {
        chunks.push(validPoints.slice(i, i + BATCH_SIZE));
    }

    const correctedPoints = [...points]; // Clone to mutate matches (naive matching by ref or index if we filter first...)
    // Actually, filter created new refs? No, shallow copy of array, but objects are refs? 
    // points.filter returns new array of refs. So modifying objects in validPoints modifies original objects? Yes.

    let processedCount = 0;

    for (const chunk of chunks) {
        const lats = chunk.map(p => p.lat).join(',');
        const lons = chunk.map(p => p.lon).join(',');

        try {
            const url = `https://api.open-meteo.com/v1/elevation?latitude=${lats}&longitude=${lons}`;
            const res = await fetch(url);
            if (!res.ok) throw new Error(`Open-Meteo Error: ${res.statusText}`);

            const data = await res.json();
            // data.elevation is array of numbers

            if (data.elevation && Array.isArray(data.elevation)) {
                data.elevation.forEach((ele: number, idx: number) => {
                    if (chunk[idx]) {
                        chunk[idx].altitude = ele;
                    }
                });
            }
            processedCount += chunk.length;
            // console.log(`Processed elevation for ${processedCount} points...`);

            // Respect rate limits - small delay? Open-Meteo is fast but let's be nice.
            await new Promise(r => setTimeout(r, 200));

        } catch (err) {
            console.error("Failed to fetch elevation for chunk", err);
            // Continue to next chunk or fail? 
            // If one chunk fails, maybe just keep old data (0).
        }
    }

    // Since we mutated the objects inside the original array (via refs), we can just return the original array structure?
    // We need to re-calculate grades and climbing summary since alts changed.
    return recalculateMetrics(correctedPoints);
};

const recalculateMetrics = (points: RidePoint[]): RidePoint[] => {
    let maxEle = -9999;
    let minEle = 9999;

    for (let i = 0; i < points.length; i++) {
        const p = points[i];
        if (p.altitude > maxEle) maxEle = p.altitude;
        if (p.altitude < minEle) minEle = p.altitude;

        if (i > 0) {
            const prev = points[i - 1];
            const distDiff = p.distance - prev.distance; // meters
            const eleDiff = p.altitude - prev.altitude;

            if (distDiff > 0) {
                p.grade = (eleDiff / distDiff) * 100;
            } else {
                p.grade = 0;
            }
        } else {
            p.grade = 0;
        }
    }

    return points;
};
