import { RideData, RidePoint } from "@/types/ride";
import FitParser from "fit-file-parser";

export const parseFitFile = (arrayBuffer: ArrayBuffer): Promise<RideData> => {
    return new Promise((resolve, reject) => {
        const parser = new FitParser({
            force: true,
            speedUnit: "km/h",
            lengthUnit: "m",
            temperatureUnit: "celsius",
            elapsedRecordField: true,
            mode: "list",
        });

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        parser.parse(arrayBuffer, (error: any, data: any) => {
            if (error) {
                reject(error);
                return;
            }

            try {
                const points: RidePoint[] = [];
                let startTime = new Date();

                if (data.records && Array.isArray(data.records)) {
                    // Find first valid timestamp
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    const firstRecord = data.records.find((r: any) => r.timestamp);
                    if (firstRecord) {
                        startTime = new Date(firstRecord.timestamp);
                    }

                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    data.records.forEach((record: any) => {
                        if (record.timestamp) {
                            const point: RidePoint = {
                                timestamp: new Date(record.timestamp),
                                distance: record.distance || 0,
                                altitude: record.altitude || 0,
                                speed: record.speed || 0,
                                grade: record.grade || 0, // Some devices allow grade, if not we compute later
                                cadence: record.cadence,
                                heartRate: record.heart_rate,
                                power: record.power,
                                lat: record.position_lat,
                                lon: record.position_long,
                            };

                            points.push(point);
                        }
                    });
                }

                // Initialize summary with explicitly typed optional fields to avoid TS errors
                const summary: RideData['summary'] = {
                    totalDistance: points.length > 0 ? points[points.length - 1].distance : 0,
                    totalTime: points.length > 0 ? (points[points.length - 1].timestamp.getTime() - startTime.getTime()) / 1000 : 0,
                };

                // If sessions data exists, try to extract summary stats
                if (data.sessions && data.sessions.length > 0) {
                    const session = data.sessions[0];
                    if (session.total_ascent) summary.elevationGain = session.total_ascent;
                    if (session.avg_power) summary.avgPower = session.avg_power;
                    if (session.max_power) summary.maxPower = session.max_power;
                    if (session.training_stress_score) summary.tss = session.training_stress_score;
                    if (session.intensity_factor) summary.if = session.intensity_factor;
                    if (session.total_work) summary.work = session.total_work / 1000; // usually joules, want kJ? 
                }

                const ride: RideData = {
                    id: crypto.randomUUID(),
                    name: "Imported Ride", // Could default to file name passed in
                    date: startTime,
                    points,
                    summary,
                };

                resolve(ride);
            } catch (err) {
                reject(err);
            }
        });
    });
};
