"use client"

import React, { useMemo } from 'react';
import { useAnalysisStore } from '@/store/useAnalysisStore';
import { useSettingsStore } from '@/store/settingsStore';
import { calculateWPrimeBalance, calculateAerobicDecoupling } from '@/lib/analytics/physiological';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, ReferenceLine } from 'recharts';

export const PhysioStats: React.FC = () => {
    const { originalRide, filteredRidePoints, range } = useAnalysisStore();
    const { ftp, wPrime } = useSettingsStore();

    // W' Balance is distinct because it relies on history.
    // We calculate it for the FULL ride to get correct state at the start of the range.
    const wPrimeData = useMemo(() => {
        if (!originalRide) return null;
        return calculateWPrimeBalance(originalRide.points, ftp, wPrime);
    }, [originalRide, ftp, wPrime]);

    // Aerobic Decoupling applies to the filtered range (e.g. checking decoupling on a climb or long segment)
    const decoupling = useMemo(() => {
        if (!filteredRidePoints || filteredRidePoints.length < 600) return null; // Needs robust data
        return calculateAerobicDecoupling(filteredRidePoints);
    }, [filteredRidePoints]);

    if (!wPrimeData) return null;

    // Filter W' data for the chart based on range
    // We Map original points to W' values
    // Find startIndex and endIndex in original points
    // Assumption: filteredRidePoints is a slice of originalRide.points.
    // But filteredRidePoints might be a new copy.
    // Better: Filter wPrimeData.balance by range indices.
    // We need to know indices.

    // Simple approach: Map original points to chart data with W' then filter
    const fullChartData = originalRide?.points.map((p, i) => ({
        dist: p.distance,
        bal: wPrimeData.balance[i],
        pwr: p.power || 0
    })) || [];

    const chartData = fullChartData.filter(d => d.dist >= range[0] && d.dist <= range[1]);
    const minBal = Math.min(...chartData.map(d => d.bal));

    return (
        <Card className="h-full">
            <CardHeader className="pb-2">
                <CardTitle className="text-lg font-bold flex justify-between">
                    <span>Physiological Metrics</span>
                    {decoupling !== null && (
                        <span className={decoupling < 5 ? "text-green-500" : "text-amber-500"}>
                            Pw:HR {decoupling.toFixed(1)}%
                        </span>
                    )}
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="h-[200px] w-full">
                    <p className="text-xs text-muted-foreground mb-1">
                        W&apos; Balance (Matches Burnt) - Lowest: {(minBal / 1000).toFixed(1)} kJ
                    </p>
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={chartData}>
                            <XAxis dataKey="dist" hide />
                            <YAxis hide domain={[0, wPrime]} />
                            <Tooltip
                                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                                formatter={(val: any) => [(Number(val) / 1000).toFixed(1) + ' kJ', "Matches"]}
                                contentStyle={{ backgroundColor: 'hsl(var(--card))' }}
                            />
                            <ReferenceLine y={0} stroke="red" />
                            <Area
                                type="monotone"
                                dataKey="bal"
                                stroke={minBal < 2000 ? "red" : "hsl(var(--chart-5))"}
                                fill="url(#colorBal)"
                                fillOpacity={0.3}
                            />
                            <defs>
                                <linearGradient id="colorBal" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="hsl(var(--chart-5))" stopOpacity={0.8} />
                                    <stop offset="95%" stopColor="hsl(var(--chart-5))" stopOpacity={0} />
                                </linearGradient>
                            </defs>
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
    );
};
