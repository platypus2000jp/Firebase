import { RidePoint } from "@/types/ride";

// Gekizaka Factor Logic ported from Python
// Grade Bins: 3.0-6.0, 6.5-9.0, 9.5-12.0, 12.5-15.0, 15.5-18.0 (and above)
// Factor 1 (15.5%+): Ratio of dist > 15.5%
// Factor 2 (12.5-15%): Ratio
// Factor 3 (9.5-12%): Ratio
// Factor 4 (Weighted High): (F3 + 2*F2 + 3*F1) / Total
// Factor 5 (Weighted All): (0.5*F_low + F_mid + ... + 5*F_high) / Total

export interface GekizakaResult {
    factors: number[]; // [F1, F2, F3, F4, F5]
    details: {
        dist3_6: number;
        dist65_9: number;
        dist95_12: number;
        dist125_15: number;
        dist155_18: number;
        totalRelevantDist: number;
    };
}

export function calculateGekizakaFactor(points: RidePoint[]): GekizakaResult | null {
    if (!points || points.length < 2) return null;

    let dist3_6 = 0;
    let dist65_9 = 0;
    let dist95_12 = 0;
    let dist125_15 = 0;
    let dist155_18 = 0;

    // Iterate through points to calculate distance per grade bin
    // Use distance diff between points
    for (let i = 1; i < points.length; i++) {
        const p1 = points[i - 1];
        const p2 = points[i];
        const distDiff = p2.distance - p1.distance;
        const grade = p2.grade;

        if (distDiff <= 0) continue;

        // Range checking with slight tolerance (1e-6 in python, just standard here)
        if (grade >= 3.0 && grade <= 6.0) dist3_6 += distDiff;
        else if (grade >= 6.5 && grade <= 9.0) dist65_9 += distDiff;
        else if (grade >= 9.5 && grade <= 12.0) dist95_12 += distDiff;
        else if (grade >= 12.5 && grade <= 15.0) dist125_15 += distDiff;
        else if (grade >= 15.5) dist155_18 += distDiff; // Upper bound 18.0 in python but + handling usually implies open ended
    }

    const totalRelevantDist = dist3_6 + dist65_9 + dist95_12 + dist125_15 + dist155_18;

    if (totalRelevantDist <= 0.001) {
        return {
            factors: [0, 0, 0, 0, 0],
            details: { dist3_6, dist65_9, dist95_12, dist125_15, dist155_18, totalRelevantDist },
        };
    }

    const f1 = dist155_18 / totalRelevantDist;
    const f2 = dist125_15 / totalRelevantDist;
    const f3 = dist95_12 / totalRelevantDist;

    // Factor 4 (Emphasis on steep)
    // Python: (sum_95_12 + 2 * sum_125_15 + 3 * sum_155_18) / total
    const f4 = (dist95_12 + 2 * dist125_15 + 3 * dist155_18) / totalRelevantDist;

    // Factor 5 (Comprehensive)
    // Python: (0.5 * sum_3_6 + sum_65_9 + 1.5 * sum_95_12 + 3 * sum_125_15 + 5 * sum_155_18) / total
    const f5 =
        (0.5 * dist3_6 + dist65_9 + 1.5 * dist95_12 + 3 * dist125_15 + 5 * dist155_18) /
        totalRelevantDist;

    return {
        factors: [f1, f2, f3, f4, f5],
        details: { dist3_6, dist65_9, dist95_12, dist125_15, dist155_18, totalRelevantDist },
    };
}
