"use client"

import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useSettingsStore } from '@/store/settingsStore';

export default function SettingsPage() {
    const { ftp, wPrime, weight, updateSettings } = useSettingsStore();
    const [localFtp, setLocalFtp] = useState(ftp);
    const [localWPrime, setLocalWPrime] = useState(wPrime);
    const [localWeight, setLocalWeight] = useState(weight);

    useEffect(() => {
        setLocalFtp(ftp);
        setLocalWPrime(wPrime);
        setLocalWeight(weight);
    }, [ftp, wPrime, weight]);

    const handleSave = () => {
        updateSettings({
            ftp: localFtp,
            wPrime: localWPrime,
            weight: localWeight,
        });
        alert("Settings saved!");
    };


    return (
        <div className="container mx-auto p-6 max-w-2xl space-y-8">
            <h1 className="text-3xl font-bold">Settings</h1>

            {/* User Profile */}
            <Card>
                <CardHeader>
                    <CardTitle>Rider Profile</CardTitle>
                    <CardDescription>
                        Key metrics used for calculation (IF, TSS, W' Bal).
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="ftp">FTP (Watts)</Label>
                            <Input
                                id="ftp"
                                type="number"
                                value={localFtp}
                                onChange={(e) => setLocalFtp(Number(e.target.value))}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="weight">Weight (kg)</Label>
                            <Input
                                id="weight"
                                type="number"
                                value={localWeight}
                                onChange={(e) => setLocalWeight(Number(e.target.value))}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="wPrime">W' (Joules)</Label>
                            <Input
                                id="wPrime"
                                type="number"
                                value={localWPrime}
                                onChange={(e) => setLocalWPrime(Number(e.target.value))}
                            />
                        </div>
                    </div>
                    <Button onClick={handleSave}>Save Profile</Button>
                </CardContent>
            </Card>

            {/* Integrations (Disabled in Static Mode) */}
            <Card>
                <CardHeader>
                    <CardTitle>Integrations</CardTitle>
                    <CardDescription>
                        Connect external services.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-4 border rounded-lg bg-muted/50">
                        <div className="flex items-center gap-3">
                            <div className="h-10 w-10 bg-orange-500 rounded flex items-center justify-center text-white font-bold">
                                S
                            </div>
                            <div>
                                <p className="font-medium">Strava</p>
                                <p className="text-sm text-yellow-600">Unavailable in Static Demo</p>
                            </div>
                        </div>
                        <Button variant="outline" disabled>Connect</Button>
                    </div>
                </CardContent>
            </Card>

            <Button variant="ghost" onClick={() => window.open('/', '_self')}>
                &larr; Back to Dashboard
            </Button>
        </div>
    );
}
