"use client"

import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

// Mock data generator for a complete revolution (0-360 degrees)
// 12 points (every 30 degrees) or 24 points (every 15). 
// Pioneer usually has 30 degree resolution (12 vectors).
interface VectorPoint {
    angle: number; // 0 is top (12 o'clock), 90 is front (3 o'clock)
    magnitude: number; // Force in Newtons or arbitrary scale
    efficiency: number; // Tangential component ratio for color (Red=High eff, Blue=Low)
}

const generateVectors = (power: number): VectorPoint[] => {
    // Simulate a typical pedal stroke: peak at 90-110 deg, low at top/bottom centers
    return Array.from({ length: 12 }, (_, i) => {
        const angle = i * 30;
        // Peak force around 90-120 degrees
        let baseForce = Math.sin((angle * Math.PI) / 180) * power * 0.5;
        if (baseForce < 0) baseForce = 0; // Downstroke mainly
        // Add some baseline
        const magnitude = Math.max(10, baseForce + Math.random() * 20);

        // Efficiency: Highest at 90 deg (tangential)
        const efficiency = Math.abs(Math.sin((angle * Math.PI) / 180));

        return { angle, magnitude, efficiency };
    });
};

export const PedalingVectors: React.FC = () => {
    const [leftVectors, setLeftVectors] = useState<VectorPoint[]>([]);
    const [rightVectors, setRightVectors] = useState<VectorPoint[]>([]);
    const [isAnimating, setIsAnimating] = useState(false);

    useEffect(() => {
        setLeftVectors(generateVectors(200));
        setRightVectors(generateVectors(210));
    }, []);

    // Animation loop to simulate live data or playback
    useEffect(() => {
        if (!isAnimating) return;
        const interval = setInterval(() => {
            // vary power slightly
            setLeftVectors(generateVectors(200 + Math.random() * 50));
            setRightVectors(generateVectors(210 + Math.random() * 50));
        }, 500);
        return () => clearInterval(interval);
    }, [isAnimating]);

    const renderOClockLines = (cx: number, cy: number, r: number) => {
        return [0, 90, 180, 270].map((deg) => {
            const rad = (deg - 90) * (Math.PI / 180);
            const x2 = cx + r * Math.cos(rad);
            const y2 = cy + r * Math.sin(rad);
            return <line key={deg} x1={cx} y1={cy} x2={x2} y2={y2} stroke="#333" strokeDasharray="2 2" />;
        });
    };

    const renderVectors = (vectors: VectorPoint[], cx: number, cy: number, scale: number) => {
        return vectors.map((v, i) => {
            // SVG coordinate system: 0 degrees usually 3 o'clock.
            // We want 0 degrees to be 12 o'clock. 
            // So subtract 90 degrees from angle.
            const rad = (v.angle - 90) * (Math.PI / 180);

            // Start point (center or offset ring?)
            // Usually vectors start from a chainring circle.
            const ringRadius = 40;
            const x1 = cx + ringRadius * Math.cos(rad);
            const y1 = cy + ringRadius * Math.sin(rad);

            // End point
            const len = v.magnitude * scale;
            const x2 = cx + (ringRadius + len) * Math.cos(rad);
            const y2 = cy + (ringRadius + len) * Math.sin(rad);

            // Color based on efficiency (Tangential)
            // Red (high) -> Blue (low)
            const color = v.efficiency > 0.8 ? "#ef4444" : v.efficiency > 0.5 ? "#eab308" : "#3b82f6";

            return (
                <g key={i}>
                    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={color} strokeWidth="4" strokeLinecap="round" />
                    {/* Arrowhead? maybe too detailed for now */}
                </g>
            );
        });
    };

    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Pedaling Monitor (Mock)</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => setIsAnimating(!isAnimating)}>
                    {isAnimating ? "Pause" : "Play Demo"}
                </Button>
            </CardHeader>
            <CardContent>
                <div className="flex justify-around items-center h-[200px]">
                    {/* Left Leg */}
                    <div className="relative">
                        <div className="absolute top-0 left-0 w-full text-center text-xs font-bold text-blue-500">L</div>
                        <svg width="140" height="140" viewBox="0 0 200 200">
                            <circle cx="100" cy="100" r="40" fill="none" stroke="#444" strokeWidth="2" />
                            {renderOClockLines(100, 100, 90)}
                            {renderVectors(leftVectors, 100, 100, 0.5)}
                        </svg>
                        <div className="text-center text-xs text-muted-foreground mt-2">48% / 52%</div>
                    </div>

                    {/* Right Leg */}
                    <div className="relative">
                        <div className="absolute top-0 left-0 w-full text-center text-xs font-bold text-red-500">R</div>
                        <svg width="140" height="140" viewBox="0 0 200 200">
                            <circle cx="100" cy="100" r="40" fill="none" stroke="#444" strokeWidth="2" />
                            {renderOClockLines(100, 100, 90)}
                            {renderVectors(rightVectors, 100, 100, 0.5)}
                        </svg>
                        <div className="text-center text-xs text-muted-foreground mt-2">Eff: 62%</div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};
