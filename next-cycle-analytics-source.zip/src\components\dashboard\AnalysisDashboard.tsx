"use client"

import React, { useEffect, useState } from 'react';
import { useAnalysisStore } from '@/store/useAnalysisStore';
import { FileUpload } from './FileUpload';
import { RideHistory } from './RideHistory';
import { GekizakaStats } from './GekizakaStats';
import { PhysioStats } from './PhysioStats';
import { PedalingVectors } from './PedalingVectors';
import { PMCChart } from '@/components/charts/PMCChart';
import { AdvancedCharts } from '@/components/charts/AdvancedCharts';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Download, Save, Printer, Settings, Mountain } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { correctElevation } from '@/lib/correction/elevation';
import { saveRide } from '@/lib/db';

export default function AnalysisDashboard() {
    const { originalRide, range, setRange, filteredRidePoints } = useAnalysisStore();
    const [sliderValue, setSliderValue] = useState([0, 0]);

    // Sync slider with store range when file loads or range resets
    useEffect(() => {
        if (range) {
            setSliderValue(range);
        }
    }, [range]); // Be careful of loops, but range comes from store actions

    const handleSliderChange = (val: number[]) => {
        setSliderValue(val);
        // Debounce or commit on change end? Slider radix primitive supports onValueCommit usually.
        // We'll update efficient store on commit or simplified debounce.
        // For now, let's update store only on commit if possible, but radix slider primitive in our wrapper
        // passes ...props to Root. But Root has onValueChange and onValueCommit.
        // Let's implement onValueCommit in Slider component or just pass it here if we exposed it.
        // Wait, our Slider component wraps Root and passes ...props.
    };

    const handleSliderCommit = (val: number[]) => {
        if (val.length === 2) {
            setRange(val[0], val[1]);
        }
    };

    const [isCorrecting, setIsCorrecting] = useState(false);

    const handleElevationCorrection = async () => {
        if (!originalRide) return;
        const confirm = window.confirm("Fetch elevation data from Open-Meteo? This will update altitude and grade for all points based on Lat/Lon.");
        if (!confirm) return;

        setIsCorrecting(true);
        try {
            // Clone points to avoid direct mutation issues before store update
            // Actually service mutates objects but returns same array ref or matched.
            // Best to deep clone if strict but performance...
            // correction service returns the same array with updated props.

            // We need to work on the ORIGINAL points (all points), not filtered.
            const updatedPoints = await correctElevation(JSON.parse(JSON.stringify(originalRide.points)));

            // Update Stats
            let maxEle = -9999;
            let minEle = 9999;
            let gain = 0;

            updatedPoints.forEach((p, i) => {
                if (p.altitude > maxEle) maxEle = p.altitude;
                if (p.altitude < minEle) minEle = p.altitude;
                if (i > 0) {
                    const diff = p.altitude - updatedPoints[i - 1].altitude;
                    if (diff > 0) gain += diff;
                }
            });

            const updatedRide = {
                ...originalRide,
                points: updatedPoints,
                summary: {
                    ...originalRide.summary,
                    elevationGain: gain,
                    // Re-calculate average power/speed? Speed doesn't change really. Power might if estimated, but we used measured.
                }
            };

            await saveRide(updatedRide); // Persist
            // useAnalysisStore setRide will update everything
            // Need to reload window or just setRide? setRide should work.
            // But we need to import setRide method... wait, we have { ... } = useAnalysisStore().
            // Oh, we need 'setRide' from store.
            window.location.reload(); // Simplest to ensure full store re-calc/refresh of derived states

        } catch (err) {
            console.error(err);
            alert("Failed to correct elevation.");
        } finally {
            setIsCorrecting(false);
        }
    };

    const handleDownloadCSV = () => {
        if (filteredRidePoints.length === 0) return;
        // implementation of CSV export
        const headers = ["timestamp", "distance", "altitude", "speed", "grade", "cadence", "power", "heartRate"];
        const csvContent = "data:text/csv;charset=utf-8,"
            + headers.join(",") + "\n"
            + filteredRidePoints.map(p => {
                return [
                    p.timestamp.toISOString(),
                    p.distance.toFixed(1),
                    p.altitude.toFixed(1),
                    p.speed.toFixed(1),
                    p.grade.toFixed(1),
                    p.cadence || "",
                    p.power || "",
                    p.heartRate || ""
                ].join(",");
            }).join("\n");

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `ride_data_${range[0].toFixed(0)}_${range[1].toFixed(0)}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    if (!originalRide) {
        return (
            <div className="container mx-auto p-6 max-w-4xl space-y-6">
                <div className="text-center space-y-2 mb-10">
                    <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl text-primary">Next-Cycle Analytics</h1>
                    <p className="text-muted-foreground text-xl">
                        Advanced cycling metrics. Gekizaka Factors. Future prediction.
                    </p>
                </div>
                <FileUpload />
                <RideHistory />
            </div>
        );
    }

    const maxDist = originalRide.summary.totalDistance;

    return (
        <div className="container mx-auto p-4 space-y-6">
            <header className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold">{originalRide.name}</h2>
                    <p className="text-sm text-muted-foreground">
                        {originalRide.date.toDateString()} • {(originalRide.summary.totalDistance / 1000).toFixed(1)} km
                    </p>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => window.open('/report', '_blank')}>
                        <Printer className="mr-2 h-4 w-4" /> Report
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => window.open('/settings', '_self')}>
                        <Settings className="h-5 w-5" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleElevationCorrection} disabled={isCorrecting}>
                        <Mountain className="mr-2 h-4 w-4" /> {isCorrecting ? "Fixing..." : "Fix Elevation"}
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleDownloadCSV}>
                        <Download className="mr-2 h-4 w-4" /> CSV
                    </Button>
                    <FileUpload /> {/* Allow re-upload or add new */}
                </div>
            </header>

            {/* Range Selection */}
            <Card className="bg-muted/30">
                <CardContent className="pt-6">
                    <div className="space-y-4">
                        <div className="flex justify-between text-sm font-medium">
                            <span>Start: {(sliderValue[0] / 1000).toFixed(2)} km</span>
                            <span>Range Filter</span>
                            <span>End: {(sliderValue[1] / 1000).toFixed(2)} km</span>
                        </div>
                        <Slider
                            value={sliderValue}
                            min={0}
                            max={maxDist}
                            step={10}
                            minStepsBetweenThumbs={1}
                            onValueChange={handleSliderChange}
                            onValueCommit={handleSliderCommit}
                            className="py-2"
                        />
                    </div>
                </CardContent>
            </Card>

            {/* PMC Chart */}
            <div className="mb-6">
                <PMCChart />
            </div>

            {/* Metrics & Custom Badges */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                    <AdvancedCharts />
                </div>
                <div className="md:col-span-1">
                    <div className="space-y-6">
                        <GekizakaStats />
                        <PhysioStats />
                        <PedalingVectors />
                    </div>
                </div>
            </div>

        </div>
    );
}
