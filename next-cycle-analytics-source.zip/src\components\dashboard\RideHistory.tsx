"use client"

import React, { useEffect, useState } from 'react';
import { getAllRides, deleteRide } from '@/lib/db';
import { RideData } from '@/types/ride';
import { useAnalysisStore } from '@/store/useAnalysisStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trash2, Play } from 'lucide-react';
import { format } from 'date-fns';

export const RideHistory: React.FC = () => {
    const [history, setHistory] = useState<RideData[]>([]);
    const { setRide, originalRide } = useAnalysisStore();

    const loadHistory = async () => {
        const rides = await getAllRides();
        // Sort descending
        setHistory(rides.sort((a, b) => b.date.getTime() - a.date.getTime()));
    };

    useEffect(() => {
        loadHistory();
    }, [originalRide]); // Refresh when a new ride is loaded (likely saved)

    const handleLoad = (ride: RideData) => {
        setRide(ride);
    };

    const handleDelete = async (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        if (confirm("Are you sure you want to delete this ride?")) {
            await deleteRide(id);
            loadHistory();
        }
    };

    if (history.length === 0) return null;

    return (
        <Card className="mt-6">
            <CardHeader>
                <CardTitle className="text-lg">Recent Rides</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-2 max-h-[200px] overflow-y-auto">
                    {history.map((ride) => (
                        <div key={ride.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                            <div className="flex flex-col cursor-pointer" onClick={() => handleLoad(ride)}>
                                <span className="font-bold text-sm block">{ride.name}</span>
                                <span className="text-xs text-muted-foreground">
                                    {format(ride.date, 'yyyy-MM-dd HH:mm')} • {(ride.summary.totalDistance / 1000).toFixed(1)}km
                                </span>
                            </div>
                            <div className="flex gap-2">
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => handleLoad(ride)}>
                                    <Play className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-red-500 hover:text-red-600" onClick={(e) => handleDelete(ride.id, e)}>
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
};
