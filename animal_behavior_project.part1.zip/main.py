import os
from crewai import Agent, Task, Crew, Process
from tools.behavior_tools import BehaviorTools

# エージェント1: 行動解析エージェント
analyst = Agent(
    role='Bio-mechanics Data Scientist',
    goal='DeepLabCutデータから精緻な運動学的特徴を抽出し、統計的な信頼性を確保する',
    backstory=(
        "あなたは世界トップクラスの神経科学ラボに所属するデータサイエンティストです。"
        "DLC(DeepLabCut)やYOLOの出力データからノイズを除去し、動物の微細な動き（Kinematics）を"
        "解析する専門家です。ユークリッド距離や速度計算において正確さを最優先します。"
    ),
    tools=[
        BehaviorTools.calculate_metrics, 
        BehaviorTools.object_detection_stub
    ],
    verbose=True,
    allow_delegation=False
)

# エージェント2: 論文執筆エージェント
researcher = Agent(
    role='Neuroscience Researcher',
    goal='解析データを解釈し、学術論文（Nature Neuroscience水準）のResultsセクションを執筆する',
    backstory=(
        "あなたは複雑な行動データを生物学的な意義に変換するベテラン研究者です。"
        "単なる数値の羅列ではなく、それが動物の探索行動、社会性、または運動機能の障害において"
        "どのような意味を持つのかを論理的に、かつ洗練された英語で考察します。"
    ),
    tools=[BehaviorTools.statistical_test],
    verbose=True,
    allow_delegation=False
)

# タスク1: データ解析
analysis_task = Task(
    description=(
        "1. 'data/sample_dlc.csv' を解析して、総移動距離と平均速度を算出してください。\n"
        "2. YOLOによる物体検出結果をシミュレートし、給餌器付近での滞在時間を取得してください。\n"
        "3. これらの結果をJSON形式のサマリーにまとめてください。"
    ),
    expected_output="移動距離、速度、物体接触時間を含む網羅的な解析PDFまたはJSONサマリーレポート。",
    agent=analyst
)

# タスク2: 論文執筆
writing_task = Task(
    description=(
        "1. 解析エージェントから渡された数値を基に、統計的検定を実行してください。\n"
        "2. その結果を用いて、学術論文の 'Results' セクションを執筆してください。\n"
        "3. 形式はMarkdownとし、背景(Context)も含めて考察してください。"
    ),
    expected_output="学術的考察、統計値(p値)、および運動指標が含まれたMarkdown形式のResultsセクション。",
    agent=researcher,
    context=[analysis_task]
)

# クルーの結成と実行
if __name__ == "__main__":
    # APIキーのチェック
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key or "dummy" in api_key.lower() or "your-key" in api_key.lower():
        print("\n[WARNING] 有効な OPENAI_API_KEY が設定されていません。")
        print("ダミーキーを使用している場合、LLMの呼び出しで 'AuthenticationError' が発生します。")
        print("実際の解析を行うには、有効なAPIキーを環境変数に設定してください。\n")

    try:
        crew = Crew(
            agents=[analyst, researcher],
            tasks=[analysis_task, writing_task],
            process=Process.sequential, 
            verbose=True
        )

        print("### 行動解析ワークフローを開始します ###")
        result = crew.kickoff()
        
        print("\n\n########################")
        print("## 最終解析レポート ##")
        print("########################\n")
        print(result)

        with open("behavior_analysis_report.md", "w", encoding="utf-8") as f:
            f.write(str(result))
            print("レポートを 'behavior_analysis_report.md' に保存しました。")

    except Exception as e:
        print(f"\n[ERROR] 実行中にエラーが発生しました: {str(e)}")
        if "401" in str(e) or "Authentication" in str(e):
            print("APIキーが正しくないか、無効である可能性があります。")
