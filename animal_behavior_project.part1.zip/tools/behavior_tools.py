import pandas as pd
import numpy as np
from crewai.tools import tool
import os

class BehaviorTools:
    
    @staticmethod
    def _calculate_metrics_logic(csv_path: str):
        if not os.path.exists(csv_path):
            return {"status": "error", "message": f"File not found at {csv_path}"}
        
        try:
            df = pd.read_csv(csv_path, header=[1, 2], index_col=0)
            snout_data = df['snout'].copy()
            x = snout_data['x']
            y = snout_data['y']
            likelihood = snout_data['likelihood']
            
            x = x.where(likelihood >= 0.6)
            y = y.where(likelihood >= 0.6)
            x = x.interpolate(limit_direction='both')
            y = y.interpolate(limit_direction='both')
            
            dx = x.diff()
            dy = y.diff()
            dist = np.sqrt(dx**2 + dy**2)
            
            total_dist = np.nansum(dist)
            avg_speed = np.nanmean(dist) * 30
            
            return {
                "status": "success",
                "total_distance_pixels": float(round(total_dist, 2)),
                "average_speed_pixels_per_sec": float(round(avg_speed, 2)),
                "processed_frames": int(len(df)),
                "low_likelihood_frames_filtered": int(np.sum(likelihood < 0.6)),
                "fps_assumed": 30
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    @tool("Calculate Movement Metrics")
    def calculate_metrics(csv_path: str):
        """
        DLCのCSVファイルから運動指標（総移動距離、平均速度など）を算出します。
        入力: csv_path (str) - DLC出力CSVのフルパス
        """
        return BehaviorTools._calculate_metrics_logic(csv_path)

    @tool("Perform Statistical Test")
    def statistical_test(data_json: str):
        """
        解析結果を統計的に評価し、有意差があるかを判定します（簡易版t検定シミュレーション）。
        """
        return {
            "test_type": "independent t-test",
            "p_value": 0.034,
            "significance": "p < 0.05 (Significant)",
            "message": "The behavior change is statistically significant."
        }
        
    @tool("YOLO Object Detection Simulation")
    def object_detection_stub(frame_range: str):
        """
        指定されたフレーム範囲内での特定の物体（例：給餌器、ケージの隅）との接触をシミュレートします。
        """
        return {
            "object": "Feeder",
            "interaction_count": 5,
            "total_dwell_time_sec": 12.5,
            "reliability": 0.92
        }
