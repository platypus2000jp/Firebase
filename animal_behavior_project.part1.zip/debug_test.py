import sys
import os
import pandas as pd
import numpy as np

# toolsディレクトリをパスに追加
sys.path.append(os.path.abspath("."))
from tools.behavior_tools import BehaviorTools

def test_debug_logic():
    csv_path = "data/sample_dlc.csv"
    print(f"--- Debugging {csv_path} ---")
    
    if not os.path.exists(csv_path):
        print("ERROR: CSV file not found!")
        return

    # 直接ロジックをテスト
    try:
        # Step 1: Read CSV
        # header=[1, 2] だと 0行目がどう扱われるかチェック
        df = pd.read_csv(csv_path, header=[1, 2], index_col=0)
        print("Columns found:", df.columns.tolist())
        
        # Step 2: Extract data
        snout_x = df[('snout', 'x')]
        snout_y = df[('snout', 'y')]
        likelihood = df[('snout', 'likelihood')]
        
        # Step 3: Check likelihood filtering
        points_to_filter = (likelihood < 0.6).sum()
        print(f"Points with low likelihood (< 0.6): {points_to_filter}")
        
        # Step 4: Calculate metrics
        result = BehaviorTools._calculate_metrics_logic(csv_path)
        print("Calculation Result:", result)
        
    except Exception as e:
        print(f"EXCEPTION during debug: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_debug_logic()
