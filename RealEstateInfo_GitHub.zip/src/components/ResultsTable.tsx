'use client';

import { motion } from 'framer-motion';

export interface TransactionData {
    Type: string;
    Region: string;
    Municipality: string;
    DistrictName: string;
    TradePrice: string;
    Area: string;
    BuildingYear: string;
    Structure: string;
    Use: string;
    CityPlanning: string;
    CoverageRatio: string;
    FloorAreaRatio: string;
    Period: string;
    [key: string]: string; // Catch-all for other fields
}

interface ResultsTableProps {
    data: TransactionData[];
}

export default function ResultsTable({ data }: ResultsTableProps) {
    if (data.length === 0) {
        return (
            <div className="text-center text-gray-400 mt-10">
                No results found. Try adjusting your search parameters.
            </div>
        );
    }

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 overflow-hidden rounded-xl border border-white/20 shadow-2xl bg-black/40 backdrop-blur-sm"
        >
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-300">
                    <caption className="sr-only">Real Estate Transaction Prices</caption>
                    <thead className="text-xs text-gray-100 uppercase bg-white/10">
                        <tr>
                            <th scope="col" className="px-6 py-4">Type</th>
                            <th scope="col" className="px-6 py-4">Location</th>
                            <th scope="col" className="px-6 py-4">Price (JPY)</th>
                            <th scope="col" className="px-6 py-4">Area (㎡)</th>
                            <th scope="col" className="px-6 py-4">Built Year</th>
                            <th scope="col" className="px-6 py-4">Structure</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((item, index) => (
                            <tr key={index} className="border-b border-gray-700 hover:bg-white/5 transition-colors">
                                <td className="px-6 py-4 font-medium text-white">{item.Type}</td>
                                <td className="px-6 py-4">
                                    {item.Prefecture} {item.Municipality} {item.DistrictName}
                                </td>
                                <td className="px-6 py-4 font-bold text-green-400">
                                    {parseInt(item.TradePrice).toLocaleString()}
                                </td>
                                <td className="px-6 py-4">{item.Area}</td>
                                <td className="px-6 py-4">{item.BuildingYear || '-'}</td>
                                <td className="px-6 py-4">{item.Structure || '-'}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="p-4 text-xs text-gray-500 text-center border-t border-gray-700">
                Showing {data.length} results
            </div>
        </motion.div>
    );
}
