'use client';

import { useState } from 'react';
import { Search, Key } from 'lucide-react';

interface SearchParams {
    year: string;
    quarter: string;
    prefecture: string;
    city: string;
    apiKey: string;
}

interface SearchFormProps {
    onSearch: (params: SearchParams) => void;
    isLoading: boolean;
}

const PREFECTURES = [
    { code: '13', name: '東京都' },
    { code: '14', name: '神奈川県' },
    { code: '11', name: '埼玉県' },
    { code: '12', name: '千葉県' },
    { code: '27', name: '大阪府' },
    { code: '26', name: '京都府' },
    { code: '28', name: '兵庫県' },
    { code: '23', name: '愛知県' },
    { code: '01', name: '北海道' },
    { code: '40', name: '福岡県' },
    // Add more as needed or fetch dynamically if possible, keeping it simple for now
];

const YEARS = Array.from({ length: 15 }, (_, i) => (2024 - i).toString());
const QUARTERS = ['1', '2', '3', '4'];

export default function SearchForm({ onSearch, isLoading }: SearchFormProps) {
    const [apiKey, setApiKey] = useState(process.env.NEXT_PUBLIC_MLIT_API_KEY || '');
    const [year, setYear] = useState('2024');
    const [quarter, setQuarter] = useState('1');
    const [prefecture, setPrefecture] = useState('13');
    const [city, setCity] = useState(''); // simplified: entering city code manually or left blank for full prefecture scan (warning: large data)
    // Actually, city code is often required or strongly recommended by MLIT API to avoid timeouts.
    // Let's stick to entering a 5-digit city code or generic search if API supports it.
    // Better: Let user input city code manually for now to save lookup logic complexity.

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSearch({ year, quarter, prefecture, city, apiKey });
    };

    return (
        <form onSubmit={handleSubmit} className="bg-white/10 backdrop-blur-md p-6 rounded-2xl shadow-xl border border-white/20">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">

                {/* API Key Input */}
                <div className="col-span-full">
                    <label htmlFor="apiKey" className="block text-sm font-medium text-gray-100 mb-1">
                        MLIT API Key (Required)
                    </label>
                    <div className="relative">
                        <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                            type="password"
                            id="apiKey"
                            required
                            value={apiKey}
                            onChange={(e) => setApiKey(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 bg-black/40 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 text-white placeholder-gray-500"
                            placeholder="Enter your API Key..."
                        />
                    </div>
                    <p className="text-xs text-gray-400 mt-1">
                        Get your key at <a href="https://www.reinfolib.mlit.go.jp/" target="_blank" rel="noreferrer" className="text-blue-400 hover:underline">reinfolib.mlit.go.jp</a>
                    </p>
                </div>

                {/* Year Selection */}
                <div>
                    <label htmlFor="year" className="block text-sm font-medium text-gray-100 mb-1">Year</label>
                    <select
                        id="year"
                        value={year}
                        onChange={(e) => setYear(e.target.value)}
                        className="w-full px-4 py-2 bg-black/40 border border-gray-600 rounded-lg text-white"
                    >
                        {YEARS.map((y) => (
                            <option key={y} value={y}>{y}</option>
                        ))}
                    </select>
                </div>

                {/* Quarter Selection */}
                <div>
                    <label htmlFor="quarter" className="block text-sm font-medium text-gray-100 mb-1">Quarter</label>
                    <select
                        id="quarter"
                        value={quarter}
                        onChange={(e) => setQuarter(e.target.value)}
                        className="w-full px-4 py-2 bg-black/40 border border-gray-600 rounded-lg text-white"
                    >
                        {QUARTERS.map((q) => (
                            <option key={q} value={q}>Q{q}</option>
                        ))}
                    </select>
                </div>

                {/* Prefecture Selection */}
                <div>
                    <label htmlFor="prefecture" className="block text-sm font-medium text-gray-100 mb-1">Prefecture</label>
                    <select
                        id="prefecture"
                        value={prefecture}
                        onChange={(e) => setPrefecture(e.target.value)}
                        className="w-full px-4 py-2 bg-black/40 border border-gray-600 rounded-lg text-white"
                    >
                        {PREFECTURES.map((p) => (
                            <option key={p.code} value={p.code}>{p.name}</option>
                        ))}
                    </select>
                </div>

                {/* City Code Input (Optional but recommended) */}
                <div>
                    <label htmlFor="city" className="block text-sm font-medium text-gray-100 mb-1">City Code (Optional)</label>
                    <input
                        id="city"
                        type="text"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        placeholder="e.g. 13101"
                        className="w-full px-4 py-2 bg-black/40 border border-gray-600 rounded-lg text-white"
                    />
                </div>

            </div>

            <button
                type="submit"
                disabled={isLoading}
                className="mt-6 w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
                {isLoading ? (
                    <span className="animate-pulse">Searching...</span>
                ) : (
                    <>
                        <Search className="w-5 h-5" />
                        Search Real Estate Prices
                    </>
                )}
            </button>
        </form>
    );
}
