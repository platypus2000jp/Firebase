'use client';

import { useState } from 'react';
import SearchForm from '@/components/SearchForm';
import ResultsTable, { TransactionData } from '@/components/ResultsTable';

export default function Home() {
  const [results, setResults] = useState<TransactionData[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (params: any) => {
    setLoading(true);
    setError('');
    setResults([]);

    try {
      // Direct request to external API
      // Note: This requires the API to support CORS.
      const BASE_URL = 'https://www.reinfolib.mlit.go.jp/api/realestate/v1/transaction';

      const cleanQuery = new URLSearchParams();
      if (params.year) cleanQuery.append('year', params.year);
      if (params.quarter) cleanQuery.append('quarter', params.quarter);
      if (params.prefecture) cleanQuery.append('area', params.prefecture);
      if (params.city) cleanQuery.append('city', params.city);
      // apiKey is sent via header, not query param for this API usually, 
      // but let's check headers usage in the new request.

      const response = await fetch(`${BASE_URL}?${cleanQuery.toString()}`, {
        headers: {
          'Ocp-Apim-Subscription-Key': params.apiKey
        }
      });

      if (!response.ok) {
        if (response.status === 401) throw new Error('Invalid API Key');
        throw new Error(`API Error: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.data) {
        setResults(data.data);
      } else {
        setResults([]);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-purple-950 to-slate-950 text-white p-4 md:p-10 font-sans selection:bg-purple-500/30">
      <div className="max-w-6xl mx-auto space-y-12">

        {/* Header Section */}
        <header className="text-center space-y-4 pt-10">
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent drop-shadow-lg">
            Real Estate Intel
          </h1>
          <p className="text-lg md:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Explore transaction prices across Japan using official MLIT data.
            <span className="block text-sm text-slate-400 mt-2">Professional Grade • High Precision • Real-time Access</span>
          </p>
        </header>

        {/* Search Section */}
        <section>
          <SearchForm onSearch={handleSearch} isLoading={loading} />
        </section>

        {/* Results Section */}
        <section>
          {error && (
            <div className="p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-200 text-center">
              Error: {error}
            </div>
          )}

          <ResultsTable data={results} />
        </section>

        <footer className="text-center text-slate-600 text-sm py-10">
          Powered by Ministry of Land, Infrastructure, Transport and Tourism API
        </footer>
      </div>
    </main>
  );
}
