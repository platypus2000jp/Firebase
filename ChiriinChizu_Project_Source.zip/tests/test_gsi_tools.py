"""
地理院地図APIツールのテスト
"""

import pytest
import asyncio
from unittest.mock import AsyncMock, patch, MagicMock
import sys
import os

# テスト対象モジュールのパスを追加
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.tools.gsi_tools import (
    GSIApiClient,
    get_elevation,
    get_elevation_profile,
    get_disaster_map_tiles,
    ElevationResult,
    ElevationProfile,
)
from src.config import GSIEndpoints, GSITileLayers


class TestGSIApiClient:
    """GSIApiClientのテスト"""
    
    @pytest.fixture
    def client(self):
        return GSIApiClient()
    
    @pytest.mark.asyncio
    async def test_get_elevation_success(self, client):
        """標高取得成功のテスト"""
        # モックレスポンス
        mock_response = {
            "elevation": 35.5,
            "hsrc": "5m（精密）"
        }
        
        with patch('aiohttp.ClientSession') as mock_session:
            mock_session.return_value.__aenter__.return_value.get.return_value.__aenter__.return_value.status = 200
            mock_session.return_value.__aenter__.return_value.get.return_value.__aenter__.return_value.json = AsyncMock(return_value=mock_response)
            
            result = await client.get_elevation(35.6812, 139.7671)
            
            assert result.success is True
            assert result.elevation == 35.5
            assert result.data_source == "5m（精密）"
    
    @pytest.mark.asyncio
    async def test_get_elevation_no_data(self, client):
        """標高データなし地点のテスト"""
        mock_response = {
            "elevation": "-----",
            "hsrc": ""
        }
        
        with patch('aiohttp.ClientSession') as mock_session:
            mock_session.return_value.__aenter__.return_value.get.return_value.__aenter__.return_value.status = 200
            mock_session.return_value.__aenter__.return_value.get.return_value.__aenter__.return_value.json = AsyncMock(return_value=mock_response)
            
            result = await client.get_elevation(0.0, 0.0)  # 海洋等
            
            assert result.success is False
            assert "存在しない" in result.error_message
    
    def test_latlon_to_tile(self, client):
        """緯度経度→タイル座標変換のテスト"""
        # 東京駅付近
        x, y = client._latlon_to_tile(35.6812, 139.7671, 15)
        
        assert isinstance(x, int)
        assert isinstance(y, int)
        assert x > 0
        assert y > 0
    
    def test_haversine_distance(self, client):
        """距離計算のテスト"""
        # 東京駅 → 新宿駅（約6.5km）
        distance = client._haversine_distance(
            35.6812, 139.7671,  # 東京駅
            35.6896, 139.7006   # 新宿駅
        )
        
        assert 6000 < distance < 7000  # 6-7kmの範囲


class TestGSITileLayers:
    """地理院タイルレイヤーのテスト"""
    
    def test_get_tile_url(self):
        """タイルURL生成のテスト"""
        url = GSITileLayers.get_tile_url("std", 15, 29102, 12903)
        
        assert "cyberjapandata.gsi.go.jp" in url
        assert "/std/" in url
        assert "/15/" in url
    
    def test_get_available_layers(self):
        """利用可能レイヤー一覧のテスト"""
        layers = GSITileLayers.get_available_layers()
        
        assert "standard" in layers
        assert "relief" in layers
        assert "slope" in layers


class TestToolWrappers:
    """ツールラッパー関数のテスト"""
    
    @pytest.mark.asyncio
    async def test_get_disaster_map_tiles(self):
        """災害関連タイル取得のテスト"""
        tiles = get_disaster_map_tiles(35.6812, 139.7671, 15)
        
        assert "standard" in tiles
        assert "relief" in tiles
        assert "hillshade" in tiles
        assert "slope" in tiles
        assert "flood_control" in tiles
        
        # 各URLが有効な形式か確認
        for name, url in tiles.items():
            assert url.startswith("https://")
            assert ".png" in url


class TestElevationProfile:
    """経路標高プロファイルのテスト"""
    
    @pytest.fixture
    def client(self):
        return GSIApiClient()
    
    def test_interpolate_route(self, client):
        """経路補間のテスト"""
        route = [
            (35.68, 139.76),
            (35.69, 139.77),
            (35.70, 139.78)
        ]
        
        interpolated = client._interpolate_route(route, 10)
        
        assert len(interpolated) == 10
        assert interpolated[0] == route[0]  # 開始点
    
    @pytest.mark.asyncio
    async def test_get_elevation_profile_invalid_input(self, client):
        """不正な入力のテスト"""
        with pytest.raises(ValueError):
            await client.get_elevation_profile([(35.68, 139.76)])  # 1点のみ


# =============================================================================
# スタンドアロンテスト実行用
# =============================================================================

if __name__ == "__main__":
    # 簡易テスト実行
    async def run_manual_tests():
        print("=== GSI API ツール 手動テスト ===\n")
        
        # 1. 標高取得テスト
        print("1. 標高取得テスト:")
        result = await get_elevation(35.6812, 139.7671)
        print(f"   東京駅の標高: {result}")
        
        # 2. タイルURL取得テスト
        print("\n2. 災害関連タイルURL取得テスト:")
        tiles = get_disaster_map_tiles(35.6812, 139.7671, 15)
        for name, url in tiles.items():
            print(f"   {name}: {url[:60]}...")
        
        print("\n=== テスト完了 ===")
    
    asyncio.run(run_manual_tests())
