"""
災害リスク判定ツールのテスト
"""

import pytest
import asyncio
from unittest.mock import AsyncMock, patch
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.tools.hazard_tools import (
    HazardAssessmentClient,
    check_flood_risk,
    check_landslide_zone,
    check_comprehensive_risk,
    evaluate_route_safety,
    RiskLevel,
    LandslideZoneType,
    FloodRiskResult,
    LandslideRiskResult,
)
from src.config import EvacuationThresholds


class TestHazardAssessmentClient:
    """HazardAssessmentClientのテスト"""
    
    @pytest.fixture
    def client(self):
        return HazardAssessmentClient()
    
    @pytest.mark.asyncio
    async def test_check_flood_risk_demo_mode(self, client):
        """浸水リスク判定（デモモード）のテスト"""
        result = await client.check_flood_risk(35.7756, 139.8042)
        
        assert result.success is True
        assert isinstance(result.flood_depth, float)
        assert isinstance(result.risk_level, RiskLevel)
        assert result.latitude == 35.7756
        assert result.longitude == 139.8042
    
    @pytest.mark.asyncio
    async def test_check_landslide_zone_demo_mode(self, client):
        """土砂災害警戒区域判定（デモモード）のテスト"""
        result = await client.check_landslide_zone(35.7756, 139.8042)
        
        assert result.success is True
        assert isinstance(result.is_in_hazard_zone, bool)
        assert isinstance(result.risk_level, RiskLevel)
    
    @pytest.mark.asyncio
    async def test_evaluate_comprehensive_risk(self, client):
        """総合リスク評価のテスト"""
        result = await client.evaluate_comprehensive_risk(35.7756, 139.8042)
        
        assert result.flood_risk is not None
        assert result.landslide_risk is not None
        assert isinstance(result.overall_risk_level, RiskLevel)
        assert 1 <= result.evacuation_priority <= 5
    
    def test_classify_flood_risk(self, client):
        """浸水リスク分類のテスト"""
        assert client._classify_flood_risk(0.0) == RiskLevel.NONE
        assert client._classify_flood_risk(0.3) == RiskLevel.NONE
        assert client._classify_flood_risk(0.7) == RiskLevel.LOW
        assert client._classify_flood_risk(1.5) == RiskLevel.MEDIUM
        assert client._classify_flood_risk(3.0) == RiskLevel.HIGH
        assert client._classify_flood_risk(6.0) == RiskLevel.CRITICAL


class TestFloodRiskResult:
    """FloodRiskResultのテスト"""
    
    def test_recommendation_critical(self):
        """危険レベルの推奨メッセージ"""
        result = FloodRiskResult(
            latitude=35.0,
            longitude=139.0,
            flood_depth=6.0,
            risk_level=RiskLevel.CRITICAL
        )
        assert "即時避難" in result.recommendation
        assert "3階" in result.recommendation
    
    def test_recommendation_low(self):
        """低リスクの推奨メッセージ"""
        result = FloodRiskResult(
            latitude=35.0,
            longitude=139.0,
            flood_depth=0.3,
            risk_level=RiskLevel.NONE
        )
        assert "注意" in result.recommendation


class TestLandslideRiskResult:
    """LandslideRiskResultのテスト"""
    
    def test_recommendation_red_zone(self):
        """レッドゾーンの推奨メッセージ"""
        from src.tools.hazard_tools import LandslideZoneInfo
        
        result = LandslideRiskResult(
            latitude=35.0,
            longitude=139.0,
            is_in_hazard_zone=True,
            zones=[
                LandslideZoneInfo(
                    zone_type=LandslideZoneType.RED,
                    phenomenon_type="急傾斜地の崩壊",
                    zone_name="テスト区域",
                    location="テスト所在地",
                    prefecture_code="13"
                )
            ],
            risk_level=RiskLevel.HIGH
        )
        assert "レッドゾーン" in result.recommendation
        assert "早期避難" in result.recommendation


class TestToolWrappers:
    """ツールラッパー関数のテスト"""
    
    @pytest.mark.asyncio
    async def test_check_flood_risk_wrapper(self):
        """check_flood_riskラッパーのテスト"""
        result = await check_flood_risk(35.7756, 139.8042)
        
        assert "flood_depth" in result
        assert "risk_level" in result
        assert "recommendation" in result
        assert "success" in result
    
    @pytest.mark.asyncio
    async def test_check_landslide_zone_wrapper(self):
        """check_landslide_zoneラッパーのテスト"""
        result = await check_landslide_zone(35.7756, 139.8042)
        
        assert "is_in_hazard_zone" in result
        assert "risk_level" in result
        assert "recommendation" in result
    
    @pytest.mark.asyncio
    async def test_check_comprehensive_risk_wrapper(self):
        """check_comprehensive_riskラッパーのテスト"""
        result = await check_comprehensive_risk(35.7756, 139.8042)
        
        assert "overall_risk_level" in result
        assert "evacuation_priority" in result
        assert "flood_risk" in result
        assert "landslide_risk" in result


class TestRouteSafety:
    """経路安全性評価のテスト"""
    
    @pytest.mark.asyncio
    async def test_evaluate_route_safety_wrapper(self):
        """evaluate_route_safetyラッパーのテスト"""
        route = [
            {"lat": 35.77, "lon": 139.80},
            {"lat": 35.78, "lon": 139.81},
            {"lat": 35.79, "lon": 139.82}
        ]
        
        result = await evaluate_route_safety(route)
        
        assert "is_safe" in result
        assert "hazard_count" in result
        assert "hazard_points" in result
        assert "recommendation" in result


# =============================================================================
# スタンドアロンテスト実行用
# =============================================================================

if __name__ == "__main__":
    async def run_manual_tests():
        print("=== 災害リスク判定ツール 手動テスト ===\n")
        
        # 1. 浸水リスク判定テスト
        print("1. 浸水リスク判定テスト:")
        result = await check_flood_risk(35.7756, 139.8042)
        print(f"   浸水深: {result['flood_depth']}m")
        print(f"   リスクレベル: {result['risk_level']}")
        print(f"   推奨: {result['recommendation'][:50]}...")
        
        # 2. 土砂災害警戒区域判定テスト
        print("\n2. 土砂災害警戒区域判定テスト:")
        result = await check_landslide_zone(35.7756, 139.8042)
        print(f"   警戒区域内: {result['is_in_hazard_zone']}")
        print(f"   リスクレベル: {result['risk_level']}")
        
        # 3. 総合リスク評価テスト
        print("\n3. 総合リスク評価テスト:")
        result = await check_comprehensive_risk(35.7756, 139.8042)
        print(f"   総合リスク: {result['overall_risk_level']}")
        print(f"   避難優先度: {result['evacuation_priority']}")
        print(f"   サマリー: {result['summary'][:50]}...")
        
        print("\n=== テスト完了 ===")
    
    asyncio.run(run_manual_tests())
