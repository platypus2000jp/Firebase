"""
統合テスト

全コンポーネント（APIツール、Ontology、知識ベース）の連携動作を確認
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import asyncio
from src.tools.gsi_tools import get_elevation
from src.tools.hazard_tools import check_comprehensive_risk
from src.tools.shelter_tools import find_nearby_shelters, get_shelter_status
from src.knowledge_base import get_rag_chain, RAGConfig

async def test_full_evacuation_scenario():
    """避難支援シナリオの統合テスト
    
    シナリオ:
    1. ユーザーの位置情報（足立区）から標高とリスクを取得
    2. 周辺の避難所を検索
    3. 避難所の詳細情報を取得
    4. RAGエージェントに避難アドバイスを求める
    """
    print("\n=== 統合テスト開始: 避難支援シナリオ ===\n")
    
    # 1. 位置情報とリスク評価
    lat, lon = 35.78, 139.80  # 足立区付近
    print(f"1. 現在地: 緯度{lat}, 経度{lon}")
    
    elevation = await get_elevation(lat, lon)
    assert elevation['success']
    print(f"   標高: {elevation['elevation']}m")
    
    risk = await check_comprehensive_risk(lat, lon)
    assert 'overall_risk_level' in risk
    print(f"   総合リスク: {risk['overall_risk_level']}")
    print(f"   推奨行動: {risk['summary']}")
    
    # 2. 避難所検索
    print("\n2. 周辺避難所検索")
    shelters = await find_nearby_shelters(lat, lon, radius_km=2.0)
    assert len(shelters['shelters']) > 0
    
    nearest_shelter = shelters['shelters'][0]
    print(f"   最寄り: {nearest_shelter['name']}")
    
    # 3. 避難所詳細
    print("\n3. 避難所詳細確認")
    shelter_status = await get_shelter_status(nearest_shelter['id'])
    assert shelter_status['id'] == nearest_shelter['id']
    print(f"   状況: {shelter_status['open_status']}")
    print(f"   収容: {shelter_status['current_occupancy']}/{shelter_status['capacity']}")
    
    # 4. RAGアドバイス
    print("\n4. RAGエージェントへの相談")
    # 設定（テスト用コレクション）
    config = RAGConfig()
    config.vector_store.collection_name = "test_integration_rag"
    
    chain = get_rag_chain(config)
    # ナレッジベース初期化（必要なら）
    chain.retriever.initialize()
    
    query = f"現在地は標高{elevation['elevation']}mで、{risk['summary']}という状況です。避難すべきですか？"
    print(f"   質問: {query}")
    
    # 注: LLM呼び出しはモックまたは実際にAPIキーがあれば実行
    # ここではretrieveまでを確認して、フォールバック応答でもOKとする
    response = chain.query(query)
    
    print(f"   回答: {response['answer'][:100]}...")
    assert response['answer']
    assert len(response['sources']) >= 0  # 検索結果がなくてもエラーにならないこと
    
    print("\n=== 統合テスト完了: 成功 ===")

if __name__ == "__main__":
    asyncio.run(test_full_evacuation_scenario())
