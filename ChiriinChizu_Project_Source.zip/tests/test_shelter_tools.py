"""
避難所ツールのテスト
"""

import pytest
import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.tools.shelter_tools import (
    ShelterClient,
    find_nearby_shelters,
    find_accessible_shelters,
    recommend_shelter,
    get_shelter_status,
    ShelterType,
    ShelterFacility,
    OpenStatus,
)


class TestShelterClient:
    """ShelterClientのテスト"""
    
    @pytest.fixture
    def client(self):
        return ShelterClient()
    
    @pytest.mark.asyncio
    async def test_find_nearby_shelters(self, client):
        """周辺避難所検索のテスト"""
        result = await client.find_nearby_shelters(35.7756, 139.8042, radius_km=5.0)
        
        assert result.total_count >= 0
        assert result.search_radius_km == 5.0
        assert result.center_latitude == 35.7756
    
    @pytest.mark.asyncio
    async def test_find_shelters_by_criteria_wheelchair(self, client):
        """車椅子対応フィルタのテスト"""
        result = await client.find_shelters_by_criteria(
            latitude=35.7756,
            longitude=139.8042,
            radius_km=10.0,
            require_wheelchair=True,
            require_open=False  # デモデータのためOFFに
        )
        
        # すべての結果が車椅子対応であることを確認
        for shelter in result.shelters:
            assert shelter.is_wheelchair_accessible
    
    @pytest.mark.asyncio
    async def test_find_shelters_by_criteria_elevation(self, client):
        """標高フィルタのテスト"""
        result = await client.find_shelters_by_criteria(
            latitude=35.7756,
            longitude=139.8042,
            radius_km=10.0,
            min_elevation=5.0,
            require_open=False
        )
        
        # すべての結果が指定標高以上であることを確認
        for shelter in result.shelters:
            assert shelter.elevation >= 5.0
    
    @pytest.mark.asyncio
    async def test_recommend_shelter(self, client):
        """避難所推奨のテスト"""
        recommendations = await client.recommend_shelter(
            latitude=35.7756,
            longitude=139.8042,
            user_requirements={"wheelchair": True, "flood_risk": True}
        )
        
        # 推奨結果があることを確認
        assert isinstance(recommendations, list)
        
        if recommendations:
            top = recommendations[0]
            assert top.suitability_score > 0
            assert len(top.reasons) > 0
    
    @pytest.mark.asyncio
    async def test_get_shelter_by_id(self, client):
        """ID検索のテスト"""
        shelter = await client.get_shelter_by_id("shelter_001")
        
        assert shelter is not None
        assert shelter.id == "shelter_001"
        assert shelter.name == "中央小学校"
    
    @pytest.mark.asyncio
    async def test_get_shelter_by_id_not_found(self, client):
        """存在しないIDのテスト"""
        shelter = await client.get_shelter_by_id("nonexistent_id")
        
        assert shelter is None
    
    def test_haversine_distance(self, client):
        """距離計算のテスト"""
        # 約1km離れた2点
        distance = client._haversine_distance(
            35.7756, 139.8042,
            35.7846, 139.8042
        )
        
        # 約1km（緯度0.01度≒約1.1km）
        assert 0.9 < distance < 1.2


class TestShelterInfo:
    """ShelterInfoのテスト"""
    
    @pytest.fixture
    def client(self):
        return ShelterClient()
    
    @pytest.mark.asyncio
    async def test_shelter_properties(self, client):
        """避難所プロパティのテスト"""
        shelter = await client.get_shelter_by_id("shelter_002")
        
        assert shelter.available_capacity == shelter.capacity - shelter.current_occupancy
        assert 0 <= shelter.occupancy_rate <= 100
        assert shelter.is_wheelchair_accessible == (ShelterFacility.WHEELCHAIR_ACCESS in shelter.facilities)


class TestToolWrappers:
    """ツールラッパー関数のテスト"""
    
    @pytest.mark.asyncio
    async def test_find_nearby_shelters_wrapper(self):
        """find_nearby_sheltersラッパーのテスト"""
        result = await find_nearby_shelters(35.7756, 139.8042, radius_km=5.0)
        
        assert "shelters" in result
        assert "total_count" in result
        assert "search_radius_km" in result
        
        if result["shelters"]:
            shelter = result["shelters"][0]
            assert "id" in shelter
            assert "name" in shelter
            assert "latitude" in shelter
            assert "longitude" in shelter
    
    @pytest.mark.asyncio
    async def test_find_accessible_shelters_wrapper(self):
        """find_accessible_sheltersラッパーのテスト"""
        result = await find_accessible_shelters(
            latitude=35.7756,
            longitude=139.8042,
            require_wheelchair=True
        )
        
        assert "shelters" in result
        assert "filters_applied" in result
        assert result["filters_applied"]["wheelchair"] is True
    
    @pytest.mark.asyncio
    async def test_recommend_shelter_wrapper(self):
        """recommend_shelterラッパーのテスト"""
        result = await recommend_shelter(
            latitude=35.7756,
            longitude=139.8042,
            wheelchair=True,
            flood_risk=True
        )
        
        assert "recommendations" in result
        
        if result.get("top_recommendation"):
            top = result["top_recommendation"]
            assert "name" in top
            assert "address" in top
            assert "walking_time" in top
            assert "why" in top
    
    @pytest.mark.asyncio
    async def test_get_shelter_status_wrapper(self):
        """get_shelter_statusラッパーのテスト"""
        result = await get_shelter_status("shelter_002")
        
        assert "id" in result
        assert "name" in result
        assert "open_status" in result
        assert "capacity" in result
        assert "available_capacity" in result


# =============================================================================
# スタンドアロンテスト実行用
# =============================================================================

if __name__ == "__main__":
    async def run_manual_tests():
        print("=== 避難所ツール 手動テスト ===\n")
        
        # 1. 周辺避難所検索テスト
        print("1. 周辺避難所検索テスト:")
        result = await find_nearby_shelters(35.7756, 139.8042, radius_km=5.0)
        print(f"   検出された避難所数: {result['total_count']}")
        for s in result['shelters'][:3]:
            print(f"   - {s['name']} (標高: {s['elevation']}m)")
        
        # 2. 条件付き検索テスト
        print("\n2. 車椅子対応避難所検索テスト:")
        result = await find_accessible_shelters(
            latitude=35.7756,
            longitude=139.8042,
            require_wheelchair=True
        )
        print(f"   車椅子対応避難所数: {result['total_count']}")
        
        # 3. 避難所推奨テスト
        print("\n3. 避難所推奨テスト:")
        result = await recommend_shelter(
            latitude=35.7756,
            longitude=139.8042,
            wheelchair=True,
            elderly=True,
            flood_risk=True
        )
        if result.get("top_recommendation"):
            top = result["top_recommendation"]
            print(f"   推奨避難所: {top['name']}")
            print(f"   所在地: {top['address']}")
            print(f"   徒歩時間: {top['walking_time']}")
            print(f"   理由: {top['why']}")
        
        # 4. 避難所状態確認テスト
        print("\n4. 避難所状態確認テスト:")
        result = await get_shelter_status("shelter_002")
        print(f"   避難所: {result['name']}")
        print(f"   開設状況: {result['open_status']}")
        print(f"   収容人数: {result['current_occupancy']}/{result['capacity']}")
        print(f"   残り収容可能: {result['available_capacity']}")
        
        print("\n=== テスト完了 ===")
    
    asyncio.run(run_manual_tests())
