"""
Foundry Ontologyクライアントのテスト
"""

import pytest
import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.ontology import (
    get_ontology_client,
    set_ontology_client,
    DemoOntologyClient,
    EvacuationShelterSchema,
    DisasterEventSchema,
    RiverWaterLevelSchema,
    ShelterType,
    OpenStatus,
    DisasterType,
    WaterLevelStatus,
)


class TestDemoOntologyClient:
    """DemoOntologyClientのテスト"""
    
    @pytest.fixture
    def client(self):
        return DemoOntologyClient()
    
    @pytest.mark.asyncio
    async def test_get_shelters_in_area(self, client):
        """エリア内避難所検索のテスト"""
        # 足立区周辺
        shelters = await client.get_shelters_in_area(
            min_lat=35.75,
            min_lon=139.78,
            max_lat=35.82,
            max_lon=139.85
        )
        
        assert isinstance(shelters, list)
        assert len(shelters) > 0
        
        for shelter in shelters:
            assert isinstance(shelter, EvacuationShelterSchema)
            assert 35.75 <= shelter.latitude <= 35.82
            assert 139.78 <= shelter.longitude <= 139.85
    
    @pytest.mark.asyncio
    async def test_get_shelters_with_filters(self, client):
        """フィルタ付き検索のテスト"""
        shelters = await client.get_shelters_in_area(
            min_lat=35.75,
            min_lon=139.78,
            max_lat=35.82,
            max_lon=139.85,
            filters={
                "require_wheelchair": True,
                "require_open": False  # デモデータのため
            }
        )
        
        # 全て車椅子対応
        for shelter in shelters:
            assert shelter.is_wheelchair_accessible
    
    @pytest.mark.asyncio
    async def test_get_shelter_by_id(self, client):
        """ID検索のテスト"""
        shelter = await client.get_shelter_by_id("shelter_001")
        
        assert shelter is not None
        assert shelter.shelter_id == "shelter_001"
        assert shelter.name == "中央小学校"
    
    @pytest.mark.asyncio
    async def test_get_shelter_by_id_not_found(self, client):
        """存在しないIDのテスト"""
        shelter = await client.get_shelter_by_id("nonexistent")
        
        assert shelter is None
    
    @pytest.mark.asyncio
    async def test_update_shelter_status(self, client):
        """避難所状態更新のテスト"""
        result = await client.update_shelter_status(
            shelter_id="shelter_001",
            open_status=OpenStatus.OPEN,
            current_occupancy=100
        )
        
        assert result is True
        
        # 更新を確認
        shelter = await client.get_shelter_by_id("shelter_001")
        assert shelter.open_status == OpenStatus.OPEN
        assert shelter.current_occupancy == 100
    
    @pytest.mark.asyncio
    async def test_get_active_disasters(self, client):
        """発生中災害取得のテスト"""
        disasters = await client.get_active_disasters()
        
        assert isinstance(disasters, list)
        
        for disaster in disasters:
            assert isinstance(disaster, DisasterEventSchema)
            assert disaster.is_active
    
    @pytest.mark.asyncio
    async def test_get_active_disasters_with_filter(self, client):
        """災害種別フィルタのテスト"""
        disasters = await client.get_active_disasters(
            disaster_types=[DisasterType.HEAVY_RAIN]
        )
        
        for disaster in disasters:
            assert disaster.disaster_type == DisasterType.HEAVY_RAIN
    
    @pytest.mark.asyncio
    async def test_get_river_levels(self, client):
        """河川水位取得のテスト"""
        levels = await client.get_river_levels()
        
        assert isinstance(levels, list)
        assert len(levels) > 0
        
        for level in levels:
            assert isinstance(level, RiverWaterLevelSchema)
    
    @pytest.mark.asyncio
    async def test_get_river_levels_only_dangerous(self, client):
        """危険水位のみ取得のテスト"""
        levels = await client.get_river_levels(only_dangerous=True)
        
        for level in levels:
            assert level.is_dangerous


class TestOntologySchemas:
    """Ontologyスキーマのテスト"""
    
    def test_shelter_schema_properties(self):
        """避難所スキーマのプロパティテスト"""
        from src.ontology.schemas import Facility
        
        shelter = EvacuationShelterSchema(
            shelter_id="test_001",
            name="テスト避難所",
            address="東京都テスト区1-1-1",
            latitude=35.7,
            longitude=139.8,
            elevation=5.0,
            capacity=100,
            current_occupancy=30,
            open_status=OpenStatus.OPEN,
            facilities=[Facility.WHEELCHAIR_ACCESS, Facility.TOILET]
        )
        
        assert shelter.available_capacity == 70
        assert shelter.occupancy_rate == 30.0
        assert shelter.is_wheelchair_accessible
        assert shelter.is_available
    
    def test_shelter_schema_to_foundry_object(self):
        """Foundryオブジェクト変換のテスト"""
        shelter = EvacuationShelterSchema(
            shelter_id="test_001",
            name="テスト避難所",
            address="東京都テスト区1-1-1",
            latitude=35.7,
            longitude=139.8,
        )
        
        obj = shelter.to_foundry_object()
        
        assert obj["primaryKey"] == "test_001"
        assert obj["properties"]["name"] == "テスト避難所"
        assert obj["properties"]["latitude"] == 35.7
    
    def test_disaster_event_requires_evacuation(self):
        """避難必要性判定のテスト"""
        from src.ontology.schemas import AlertLevel, Severity
        
        # レベル4は避難必要
        disaster = DisasterEventSchema(
            event_id="test_001",
            disaster_type=DisasterType.FLOOD,
            severity=Severity.WARNING,
            alert_level=AlertLevel.LEVEL_4
        )
        
        assert disaster.requires_evacuation
        
        # レベル2は避難不要
        disaster2 = DisasterEventSchema(
            event_id="test_002",
            disaster_type=DisasterType.HEAVY_RAIN,
            severity=Severity.ADVISORY,
            alert_level=AlertLevel.LEVEL_2
        )
        
        assert not disaster2.requires_evacuation
    
    def test_river_water_level_status(self):
        """水位状態判定のテスト"""
        river = RiverWaterLevelSchema(
            station_id="test_001",
            station_name="テスト観測所",
            river_name="テスト川",
            current_level=7.0,
            danger_level=6.0,
            levee_height=10.0,
            status=WaterLevelStatus.CRITICAL
        )
        
        assert river.is_dangerous
        assert river.requires_attention
        assert river.margin_to_danger == -1.0
        assert river.level_percentage == 70.0
    
    def test_river_determine_status(self):
        """水位状態自動判定のテスト"""
        river = RiverWaterLevelSchema(
            station_id="test_001",
            station_name="テスト観測所",
            river_name="テスト川",
            current_level=5.5,
            standby_level=3.0,
            attention_level=5.0,
            warning_level=6.5,
            danger_level=7.5,
        )
        
        status = river.determine_status()
        assert status == WaterLevelStatus.WARNING


class TestClientFactory:
    """クライアントファクトリのテスト"""
    
    def test_get_ontology_client_demo_mode(self):
        """デモモードでのクライアント取得"""
        # 環境変数未設定の場合はデモクライアント
        client = get_ontology_client()
        
        assert isinstance(client, DemoOntologyClient)
    
    def test_set_ontology_client(self):
        """カスタムクライアント設定"""
        mock_client = DemoOntologyClient()
        set_ontology_client(mock_client)
        
        client = get_ontology_client()
        assert client is mock_client


# =============================================================================
# スタンドアロンテスト実行用
# =============================================================================

if __name__ == "__main__":
    async def run_manual_tests():
        print("=== Foundry Ontology クライアント 手動テスト ===\n")
        
        client = DemoOntologyClient()
        
        # 1. 避難所検索テスト
        print("1. エリア内避難所検索テスト:")
        shelters = await client.get_shelters_in_area(35.75, 139.78, 35.82, 139.85)
        print(f"   検出数: {len(shelters)}")
        for s in shelters[:3]:
            print(f"   - {s.name} ({s.shelter_type.value})")
        
        # 2. 災害イベント取得テスト
        print("\n2. 発生中災害イベント取得テスト:")
        disasters = await client.get_active_disasters()
        print(f"   発生中: {len(disasters)}")
        for d in disasters:
            print(f"   - {d.title} ({d.severity.value})")
        
        # 3. 河川水位取得テスト
        print("\n3. 河川水位取得テスト:")
        levels = await client.get_river_levels()
        for r in levels:
            print(f"   - {r.station_name}: {r.current_level}m ({r.status.value})")
        
        print("\n=== テスト完了 ===")
    
    asyncio.run(run_manual_tests())
