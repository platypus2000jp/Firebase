"""
RAGナレッジベースのテスト
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.knowledge_base import (
    RAGConfig,
    ChunkingConfig,
    DocumentType,
    DocumentMetadata,
    DocumentLoader,
    DocumentChunk,
    JapaneseTextSplitter,
    create_sample_evacuation_documents,
    VectorStore,
    SearchResult,
    RAGRetriever,
    RetrievedContext,
)


class TestJapaneseTextSplitter:
    """日本語テキストスプリッターのテスト"""
    
    def test_split_by_sentence(self):
        """文単位での分割テスト"""
        config = ChunkingConfig(chunk_size=100, chunk_overlap=0)
        splitter = JapaneseTextSplitter(config)
        
        text = "これは最初の文です。これは2番目の文です。これは3番目の文です。"
        chunks = splitter.split_text(text)
        
        assert len(chunks) >= 1
        # 元のテキストが保持されている
        assert all(c in text.replace("\n", "") for c in "".join(chunks).replace("\n", ""))
    
    def test_split_long_text(self):
        """長いテキストの分割テスト"""
        config = ChunkingConfig(chunk_size=50, chunk_overlap=10)
        splitter = JapaneseTextSplitter(config)
        
        text = "あ" * 200  # 200文字のテキスト
        chunks = splitter.split_text(text)
        
        # 複数チャンクに分割される
        assert len(chunks) > 1
        
        # 各チャンクが制限内（オーバーラップ込み）
        for chunk in chunks:
            assert len(chunk) <= config.chunk_size + config.chunk_overlap
    
    def test_split_with_paragraph(self):
        """段落区切りでの分割テスト"""
        config = ChunkingConfig(chunk_size=100, chunk_overlap=0)
        splitter = JapaneseTextSplitter(config)
        
        text = "第1段落の内容です。\n\n第2段落の内容です。\n\n第3段落の内容です。"
        chunks = splitter.split_text(text)
        
        assert len(chunks) >= 1


class TestDocumentLoader:
    """ドキュメントローダーのテスト"""
    
    def test_load_from_string(self):
        """文字列からの読み込みテスト"""
        loader = DocumentLoader()
        
        text = "テストドキュメントの内容です。これはテスト用のテキストです。"
        metadata = DocumentMetadata(
            doc_type=DocumentType.EVACUATION_MANUAL,
            source="test_source"
        )
        
        chunks = loader.load_from_string(text, metadata)
        
        assert len(chunks) > 0
        assert all(isinstance(c, DocumentChunk) for c in chunks)
        assert chunks[0].metadata["doc_type"] == "evacuation_manual"
    
    def test_create_sample_documents(self):
        """サンプルドキュメント生成テスト"""
        chunks = create_sample_evacuation_documents()
        
        assert len(chunks) > 0
        
        # 複数のドキュメントタイプが含まれる
        doc_types = set(c.metadata.get("doc_type") for c in chunks)
        assert len(doc_types) >= 2


class TestVectorStore:
    """ベクトルストアのテスト"""
    
    @pytest.fixture
    def temp_vector_store(self, tmp_path):
        """一時ベクトルストア"""
        config = RAGConfig()
        config.vector_store.persist_directory = str(tmp_path / ".vectorstore")
        config.vector_store.collection_name = "test_collection"
        return VectorStore(config)
    
    def test_add_and_search(self, temp_vector_store):
        """追加と検索のテスト"""
        # ドキュメントを追加
        chunks = create_sample_evacuation_documents()[:5]
        count = temp_vector_store.add_documents(chunks)
        
        assert count == 5
        
        # 検索
        results = temp_vector_store.search("避難所", k=3)
        
        assert len(results) <= 3
        assert all(isinstance(r, SearchResult) for r in results)
    
    def test_search_with_filter(self, temp_vector_store):
        """フィルタ付き検索のテスト"""
        chunks = create_sample_evacuation_documents()
        temp_vector_store.add_documents(chunks)
        
        # ドキュメントタイプでフィルタ
        results = temp_vector_store.search(
            "浸水",
            filter_metadata={"doc_type": "disaster_guideline"}
        )
        
        for result in results:
            assert result.doc_type == "disaster_guideline"
    
    def test_get_stats(self, temp_vector_store):
        """統計情報取得のテスト"""
        chunks = create_sample_evacuation_documents()[:3]
        temp_vector_store.add_documents(chunks)
        
        stats = temp_vector_store.get_stats()
        
        assert "document_count" in stats
        assert stats["document_count"] == 3


class TestRAGRetriever:
    """RAGリトリーバーのテスト"""
    
    @pytest.fixture
    def temp_retriever(self, tmp_path):
        """一時リトリーバー"""
        config = RAGConfig()
        config.vector_store.persist_directory = str(tmp_path / ".vectorstore")
        config.vector_store.collection_name = "test_rag"
        return RAGRetriever(config)
    
    def test_initialize(self, temp_retriever):
        """初期化テスト"""
        result = temp_retriever.initialize()
        
        assert result is True
        assert temp_retriever._initialized
    
    def test_retrieve(self, temp_retriever):
        """検索テスト"""
        temp_retriever.initialize()
        
        context = temp_retriever.retrieve("警戒レベル4とは何ですか？")
        
        assert isinstance(context, RetrievedContext)
        assert context.has_results
        assert len(context.combined_context) > 0
    
    def test_retrieve_for_evacuation(self, temp_retriever):
        """避難関連検索テスト"""
        temp_retriever.initialize()
        
        context = temp_retriever.retrieve_for_evacuation(
            "土砂災害の前兆現象を教えてください"
        )
        
        assert context.has_results
        # 土砂災害関連の情報が含まれる
        assert "土砂" in context.combined_context or "前兆" in context.combined_context


class TestDocumentMetadata:
    """ドキュメントメタデータのテスト"""
    
    def test_to_dict(self):
        """辞書変換テスト"""
        metadata = DocumentMetadata(
            doc_type=DocumentType.EVACUATION_MANUAL,
            source="test.md",
            title="テストドキュメント",
            tags=["避難", "テスト"]
        )
        
        result = metadata.to_dict()
        
        assert result["doc_type"] == "evacuation_manual"
        assert result["source"] == "test.md"
        assert result["title"] == "テストドキュメント"
        assert result["tags"] == "避難,テスト"


# =============================================================================
# スタンドアロンテスト実行用
# =============================================================================

if __name__ == "__main__":
    import tempfile
    
    print("=== RAG ナレッジベース 手動テスト ===\n")
    
    with tempfile.TemporaryDirectory() as tmp_dir:
        # 1. サンプルドキュメント生成テスト
        print("1. サンプルドキュメント生成テスト:")
        chunks = create_sample_evacuation_documents()
        print(f"   生成されたチャンク数: {len(chunks)}")
        
        # 2. ベクトルストアテスト
        print("\n2. ベクトルストアテスト:")
        config = RAGConfig()
        config.vector_store.persist_directory = os.path.join(tmp_dir, ".vectorstore")
        
        store = VectorStore(config)
        store.add_documents(chunks)
        
        results = store.search("警戒レベル", k=3)
        print(f"   検索結果数: {len(results)}")
        if results:
            print(f"   最高スコア: {results[0].score:.3f}")
            print(f"   ソース: {results[0].source}")
        
        # 3. RAGリトリーバーテスト
        print("\n3. RAGリトリーバーテスト:")
        retriever = RAGRetriever(config)
        retriever.initialize()
        
        queries = [
            "避難所の種類を教えてください",
            "浸水深1mの場合どうすればいい？",
            "土砂災害の前兆現象は？"
        ]
        
        for query in queries:
            context = retriever.retrieve(query, k=2)
            print(f"\n   Q: {query}")
            print(f"   結果数: {len(context.results)}")
            print(f"   最高スコア: {context.best_score:.3f}")
    
    print("\n=== テスト完了 ===")
