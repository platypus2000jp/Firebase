# 地理院地図API × Foundry IQ Agentic RAG

避難支援に特化したAgentic RAGシステムのPythonパッケージです。

## 概要

国土地理院の地理空間データ（標高、浸水想定、土砂災害警戒区域等）と
Foundry IQを統合し、LLMエージェントによる自律的な避難支援を実現します。

## 機能

### 1. 地理院地図APIツール (`src/tools/gsi_tools.py`)
- **標高取得** (`get_elevation`): 指定地点の標高を取得
- **経路標高プロファイル** (`get_elevation_profile`): 避難経路の勾配分析
- **地図タイル** (`get_disaster_map_tiles`): 災害関連地図レイヤーのURL取得

### 2. 災害リスク判定ツール (`src/tools/hazard_tools.py`)
- **浸水リスク判定** (`check_flood_risk`): 洪水浸水想定区域の確認
- **土砂災害警戒区域判定** (`check_landslide_zone`): イエロー/レッドゾーンの判定
- **総合リスク評価** (`check_comprehensive_risk`): 複合災害リスクの評価
- **経路安全性評価** (`evaluate_route_safety`): 避難経路上の危険箇所特定

### 3. 避難所ツール (`src/tools/shelter_tools.py`)
- **周辺避難所検索** (`find_nearby_shelters`): 距離順の避難所リスト
- **条件付き検索** (`find_accessible_shelters`): 車椅子対応、標高条件等でフィルタ
- **最適避難所推奨** (`recommend_shelter`): ユーザー状況に応じた推奨
- **避難所状態確認** (`get_shelter_status`): リアルタイムの開設・収容状況

## インストール

```bash
pip install -r requirements.txt
```

## 使用方法

### 基本的な使い方

```python
import asyncio
from src.tools import (
    get_elevation,
    check_flood_risk,
    recommend_shelter
)

async def main():
    # 標高を取得
    elevation = await get_elevation(35.6812, 139.7671)
    print(f"標高: {elevation['elevation']}m")
    
    # 浸水リスクを確認
    flood = await check_flood_risk(35.6812, 139.7671)
    print(f"想定浸水深: {flood['flood_depth']}m")
    
    # 避難所を推奨
    shelters = await recommend_shelter(
        latitude=35.6812,
        longitude=139.7671,
        wheelchair=True,
        flood_risk=True
    )
    print(f"推奨避難所: {shelters['top_recommendation']['name']}")

asyncio.run(main())
```

### Foundry IQとの統合

エージェント定義は `src/agent/agent_definitions.py` に格納されています。

```python
from src.agent import EVACUATION_AGENT_TOOLS, EVACUATION_AGENT_SYSTEM_PROMPT

# Foundry IQまたはLangChainでエージェントを初期化
agent = create_agent(
    tools=EVACUATION_AGENT_TOOLS,
    system_prompt=EVACUATION_AGENT_SYSTEM_PROMPT
)
```

## プロジェクト構造

```
ChiriinChizu API/
├── src/
│   ├── __init__.py
│   ├── config.py              # API設定・定数
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── gsi_tools.py       # 地理院地図APIツール
│   │   ├── hazard_tools.py    # 災害リスク判定
│   │   └── shelter_tools.py   # 避難所連携
│   └── agent/
│       ├── __init__.py
│       └── agent_definitions.py  # ツール定義・プロンプト
├── tests/
│   ├── test_gsi_tools.py
│   └── test_hazard_tools.py
├── requirements.txt
└── README.md
```

## APIエンドポイント

| API | エンドポイント | 用途 |
|-----|--------------|------|
| 標高API | `cyberjapandata2.gsi.go.jp/general/dem/scripts/getelevation.php` | 標高取得 |
| 地理院タイル | `cyberjapandata.gsi.go.jp/xyz/{layer}/{z}/{x}/{y}.png` | 地図表示 |
| 土砂災害警戒区域 | `reinfolib.mlit.go.jp/ex-api/external/XKT029` | リスク判定 |
| 洪水浸水想定区域 | `reinfolib.mlit.go.jp/ex-api/external/XKT030` | 浸水判定 |

## ライセンス

- 地理院タイル: [国土地理院コンテンツ利用規約](https://www.gsi.go.jp/kikakuchousei/kikakuchousei40182.html)
- 国土数値情報: [国土交通省利用規約](https://www.reinfolib.mlit.go.jp/)

## 注意事項

- 地理院地図APIは1秒に1回程度のアクセスを推奨しています
- 本システムは避難判断の参考情報であり、最終判断はユーザーに委ねてください
- 実際の災害時は自治体の指示に従ってください
