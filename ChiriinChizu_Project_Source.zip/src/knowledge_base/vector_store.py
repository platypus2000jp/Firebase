"""
ベクトルストア

Chromaを使用したドキュメントベクトルの保存・検索
"""

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass

from .config import RAGConfig, VectorStoreConfig, EmbeddingModel
from .document_loader import DocumentChunk

logger = logging.getLogger(__name__)


# =============================================================================
# 検索結果
# =============================================================================

@dataclass
class SearchResult:
    """検索結果"""
    content: str
    metadata: Dict[str, Any]
    score: float  # 類似度スコア（0-1、高いほど類似）
    
    @property
    def source(self) -> str:
        """ソースを取得"""
        return self.metadata.get("source", "unknown")
    
    @property
    def doc_type(self) -> str:
        """ドキュメントタイプを取得"""
        return self.metadata.get("doc_type", "unknown")


# =============================================================================
# エンベディング関数
# =============================================================================

class EmbeddingFunction:
    """エンベディング関数のラッパー"""
    
    def __init__(self, config: RAGConfig = None):
        self.config = config or RAGConfig()
        self._embedder = None
    
    def _initialize_embedder(self):
        """エンベッダーを初期化"""
        if self._embedder is not None:
            return
        
        model_name = self.config.embedding.model.value
        
        # OpenAIモデルの場合
        if model_name.startswith("text-embedding"):
            try:
                from langchain_openai import OpenAIEmbeddings
                self._embedder = OpenAIEmbeddings(
                    model=model_name,
                    openai_api_key=self.config.embedding.openai_api_key
                )
                logger.info(f"OpenAI Embeddingsを初期化: {model_name}")
            except ImportError:
                logger.warning("langchain-openai未インストール、HuggingFaceにフォールバック")
                self._initialize_huggingface_embedder()
        else:
            self._initialize_huggingface_embedder()
    
    def _initialize_huggingface_embedder(self):
        """HuggingFaceエンベッダーを初期化"""
        model_name = self.config.embedding.model.value
        
        try:
            from langchain_huggingface import HuggingFaceEmbeddings
            self._embedder = HuggingFaceEmbeddings(
                model_name=model_name,
                model_kwargs={"device": "cpu"},
                encode_kwargs={"normalize_embeddings": True}
            )
            logger.info(f"HuggingFace Embeddingsを初期化: {model_name}")
        except ImportError:
            logger.warning("langchain-huggingface未インストール、ダミーエンベッダーを使用")
            self._embedder = DummyEmbeddings()
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """ドキュメントをエンベッディング"""
        self._initialize_embedder()
        return self._embedder.embed_documents(texts)
    
    def embed_query(self, text: str) -> List[float]:
        """クエリをエンベッディング"""
        self._initialize_embedder()
        return self._embedder.embed_query(text)


class DummyEmbeddings:
    """ダミーエンベディング（テスト用）"""
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """ダミーのドキュメントエンベディング"""
        import hashlib
        result = []
        for text in texts:
            # テキストのハッシュから擬似的なベクトルを生成
            hash_bytes = hashlib.md5(text.encode()).digest()
            vector = [b / 255.0 for b in hash_bytes]
            # 384次元に拡張
            vector = (vector * 24)[:384]
            result.append(vector)
        return result
    
    def embed_query(self, text: str) -> List[float]:
        """ダミーのクエリエンベディング"""
        return self.embed_documents([text])[0]


# =============================================================================
# ベクトルストア
# =============================================================================

class VectorStore:
    """ベクトルストア（Chroma使用）"""
    
    def __init__(self, config: RAGConfig = None):
        self.config = config or RAGConfig()
        self.embedding_fn = EmbeddingFunction(self.config)
        self._collection = None
        self._client = None
    
    def _initialize_chroma(self):
        """Chromaを初期化"""
        if self._collection is not None:
            return
        
        try:
            import chromadb
            from chromadb.config import Settings
            
            # 永続化ディレクトリ
            persist_dir = self.config.vector_store.persist_directory
            Path(persist_dir).mkdir(parents=True, exist_ok=True)
            
            # クライアント初期化
            self._client = chromadb.PersistentClient(
                path=persist_dir,
                settings=Settings(anonymized_telemetry=False)
            )
            
            # コレクション取得または作成
            collection_name = self.config.vector_store.collection_name
            self._collection = self._client.get_or_create_collection(
                name=collection_name,
                metadata={"hnsw:space": self.config.vector_store.distance_metric}
            )
            
            logger.info(f"Chromaコレクション初期化: {collection_name} ({self._collection.count()} ドキュメント)")
            
        except ImportError:
            logger.error("chromadb未インストール: pip install chromadb")
            raise
    
    def add_documents(self, chunks: List[DocumentChunk]) -> int:
        """ドキュメントチャンクを追加"""
        if not chunks:
            return 0
        
        self._initialize_chroma()
        
        # テキストとメタデータを抽出
        texts = [chunk.content for chunk in chunks]
        metadatas = [chunk.metadata for chunk in chunks]
        
        # IDを生成
        ids = [f"doc_{hash(chunk.content) % 10**10}" for chunk in chunks]
        
        # エンベディング生成
        embeddings = self.embedding_fn.embed_documents(texts)
        
        # Chromaに追加
        self._collection.add(
            ids=ids,
            documents=texts,
            embeddings=embeddings,
            metadatas=metadatas
        )
        
        logger.info(f"{len(chunks)} ドキュメントを追加")
        return len(chunks)
    
    def search(
        self,
        query: str,
        k: int = None,
        filter_metadata: Dict[str, Any] = None
    ) -> List[SearchResult]:
        """類似ドキュメントを検索"""
        self._initialize_chroma()
        
        k = k or self.config.vector_store.search_k
        
        # クエリをエンベッディング
        query_embedding = self.embedding_fn.embed_query(query)
        
        # 検索パラメータ
        query_params = {
            "query_embeddings": [query_embedding],
            "n_results": k,
            "include": ["documents", "metadatas", "distances"]
        }
        
        # メタデータフィルタ
        if filter_metadata:
            query_params["where"] = filter_metadata
        
        # 検索実行
        results = self._collection.query(**query_params)
        
        # 結果を変換
        search_results = []
        
        if results and results["documents"]:
            for i, doc in enumerate(results["documents"][0]):
                # 距離をスコアに変換（コサイン距離の場合、1 - distance = similarity）
                distance = results["distances"][0][i] if results["distances"] else 0
                score = 1 - distance
                
                search_results.append(SearchResult(
                    content=doc,
                    metadata=results["metadatas"][0][i] if results["metadatas"] else {},
                    score=score
                ))
        
        return search_results
    
    def search_with_threshold(
        self,
        query: str,
        k: int = None,
        score_threshold: float = None
    ) -> List[SearchResult]:
        """スコアしきい値付き検索"""
        results = self.search(query, k)
        threshold = score_threshold or self.config.vector_store.score_threshold
        
        return [r for r in results if r.score >= threshold]
    
    def delete_collection(self) -> bool:
        """コレクションを削除"""
        if self._client is None:
            self._initialize_chroma()
        
        try:
            self._client.delete_collection(self.config.vector_store.collection_name)
            self._collection = None
            logger.info("コレクションを削除しました")
            return True
        except Exception as e:
            logger.error(f"コレクション削除エラー: {e}")
            return False
    
    def get_stats(self) -> Dict[str, Any]:
        """統計情報を取得"""
        self._initialize_chroma()
        
        return {
            "collection_name": self.config.vector_store.collection_name,
            "document_count": self._collection.count(),
            "persist_directory": self.config.vector_store.persist_directory
        }


# =============================================================================
# シングルトンインスタンス
# =============================================================================

_vector_store: Optional[VectorStore] = None

def get_vector_store(config: RAGConfig = None) -> VectorStore:
    """ベクトルストアのシングルトンを取得"""
    global _vector_store
    
    if _vector_store is None:
        _vector_store = VectorStore(config)
    
    return _vector_store
