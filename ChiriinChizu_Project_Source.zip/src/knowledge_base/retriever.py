"""
RAG リトリーバー

ナレッジベースからのコンテキスト検索と回答生成
"""

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .config import RAGConfig, DocumentType
from .vector_store import VectorStore, SearchResult, get_vector_store
from .document_loader import DocumentLoader, create_sample_evacuation_documents

logger = logging.getLogger(__name__)


# =============================================================================
# コンテキスト
# =============================================================================

@dataclass
class RetrievedContext:
    """検索されたコンテキスト"""
    
    query: str
    results: List[SearchResult]
    combined_context: str
    source_count: int
    
    @property
    def has_results(self) -> bool:
        """結果があるか"""
        return len(self.results) > 0
    
    @property
    def best_score(self) -> float:
        """最高スコア"""
        if not self.results:
            return 0.0
        return max(r.score for r in self.results)
    
    def get_sources(self) -> List[str]:
        """ソース一覧を取得"""
        return list(set(r.source for r in self.results))


# =============================================================================
# RAG リトリーバー
# =============================================================================

class RAGRetriever:
    """RAGリトリーバー
    
    ナレッジベースから関連コンテキストを検索し、
    LLMへの入力用にフォーマットする
    """
    
    def __init__(self, config: RAGConfig = None):
        self.config = config or RAGConfig()
        self.vector_store = get_vector_store(self.config)
        self._initialized = False
    
    def initialize(self, force_reload: bool = False) -> bool:
        """ナレッジベースを初期化
        
        Args:
            force_reload: 既存データを削除して再読み込み
        
        Returns:
            bool: 成功フラグ
        """
        if self._initialized and not force_reload:
            return True
        
        try:
            if force_reload:
                self.vector_store.delete_collection()
            
            # サンプルドキュメントを読み込み
            stats = self.vector_store.get_stats()
            
            if stats["document_count"] == 0:
                logger.info("ナレッジベースが空です。サンプルドキュメントを読み込みます。")
                sample_chunks = create_sample_evacuation_documents()
                self.vector_store.add_documents(sample_chunks)
            
            self._initialized = True
            logger.info(f"RAGリトリーバー初期化完了: {self.vector_store.get_stats()['document_count']} ドキュメント")
            return True
            
        except Exception as e:
            logger.error(f"RAGリトリーバー初期化エラー: {e}")
            return False
    
    def retrieve(
        self,
        query: str,
        k: int = None,
        doc_types: List[DocumentType] = None
    ) -> RetrievedContext:
        """クエリに関連するコンテキストを検索
        
        Args:
            query: 検索クエリ
            k: 取得数
            doc_types: フィルタするドキュメントタイプ
        
        Returns:
            RetrievedContext: 検索結果
        """
        self.initialize()
        
        k = k or self.config.vector_store.search_k
        
        # メタデータフィルタ
        filter_metadata = None
        if doc_types:
            # Chromaのフィルタ形式
            if len(doc_types) == 1:
                filter_metadata = {"doc_type": doc_types[0].value}
            else:
                filter_metadata = {
                    "$or": [{"doc_type": t.value} for t in doc_types]
                }
        
        # 検索実行
        results = self.vector_store.search(
            query=query,
            k=k,
            filter_metadata=filter_metadata
        )
        
        # コンテキストを結合
        combined_context = self._format_context(results)
        
        return RetrievedContext(
            query=query,
            results=results,
            combined_context=combined_context,
            source_count=len(set(r.source for r in results))
        )
    
    def retrieve_for_evacuation(
        self,
        query: str,
        include_guidelines: bool = True,
        include_manuals: bool = True
    ) -> RetrievedContext:
        """避難関連のコンテキストを検索
        
        避難支援に特化した検索メソッド
        """
        doc_types = []
        
        if include_manuals:
            doc_types.append(DocumentType.EVACUATION_MANUAL)
        
        if include_guidelines:
            doc_types.append(DocumentType.DISASTER_GUIDELINE)
        
        return self.retrieve(query, doc_types=doc_types if doc_types else None)
    
    def _format_context(self, results: List[SearchResult]) -> str:
        """検索結果をLLM入力用にフォーマット"""
        if not results:
            return ""
        
        context_parts = []
        
        for i, result in enumerate(results, 1):
            source = result.source
            doc_type = result.doc_type
            
            part = f"【参考資料 {i}】\n"
            part += f"ソース: {source} ({doc_type})\n"
            part += f"関連度: {result.score:.2f}\n"
            part += f"内容:\n{result.content}\n"
            
            context_parts.append(part)
        
        return "\n---\n".join(context_parts)
    
    def add_documents(
        self,
        texts: List[str],
        doc_type: DocumentType,
        source: str
    ) -> int:
        """ドキュメントを追加"""
        from .document_loader import DocumentLoader, DocumentMetadata
        
        loader = DocumentLoader(self.config)
        all_chunks = []
        
        for text in texts:
            metadata = DocumentMetadata(
                doc_type=doc_type,
                source=source
            )
            chunks = loader.load_from_string(text, metadata)
            all_chunks.extend(chunks)
        
        return self.vector_store.add_documents(all_chunks)
    
    def get_stats(self) -> Dict[str, Any]:
        """統計情報を取得"""
        return self.vector_store.get_stats()


# =============================================================================
# RAG チェーン
# =============================================================================

class RAGChain:
    """RAGチェーン
    
    リトリーバーとLLMを組み合わせて質問応答を行う
    """
    
    def __init__(
        self,
        retriever: RAGRetriever = None,
        config: RAGConfig = None
    ):
        self.config = config or RAGConfig()
        self.retriever = retriever or RAGRetriever(self.config)
        self._llm = None
    
    def _get_llm(self):
        """LLMを取得"""
        if self._llm is not None:
            return self._llm
        
        try:
            from langchain_openai import ChatOpenAI
            
            self._llm = ChatOpenAI(
                model=self.config.llm_model,
                temperature=self.config.llm_temperature,
                max_tokens=self.config.llm_max_tokens,
            )
            return self._llm
            
        except ImportError:
            logger.warning("langchain-openai未インストール")
            return None
    
    def query(
        self,
        question: str,
        system_prompt: str = None
    ) -> Dict[str, Any]:
        """質問に回答
        
        Args:
            question: 質問文
            system_prompt: システムプロンプト（カスタマイズ用）
        
        Returns:
            dict: {
                "answer": 回答文,
                "context": 使用したコンテキスト,
                "sources": ソース一覧
            }
        """
        # コンテキストを検索
        context = self.retriever.retrieve_for_evacuation(question)
        
        if not context.has_results:
            return {
                "answer": "関連する情報が見つかりませんでした。",
                "context": "",
                "sources": []
            }
        
        # プロンプトを構築
        system_prompt = system_prompt or self._get_default_system_prompt()
        
        prompt = f"""以下の参考資料に基づいて、質問に回答してください。

{context.combined_context}

---

質問: {question}

回答（参考資料に基づいて、具体的かつ正確に回答してください）:
"""
        
        # LLMで回答生成
        llm = self._get_llm()
        
        if llm:
            try:
                from langchain_core.messages import SystemMessage, HumanMessage
                
                messages = [
                    SystemMessage(content=system_prompt),
                    HumanMessage(content=prompt)
                ]
                
                response = llm.invoke(messages)
                answer = response.content
            except Exception as e:
                logger.error(f"LLM呼び出しエラー: {e}")
                answer = self._fallback_answer(question, context)
        else:
            answer = self._fallback_answer(question, context)
        
        return {
            "answer": answer,
            "context": context.combined_context,
            "sources": context.get_sources(),
            "result_count": len(context.results),
            "best_score": context.best_score
        }
    
    def _get_default_system_prompt(self) -> str:
        """デフォルトシステムプロンプト"""
        return """あなたは防災・避難に関する専門家です。
提供された参考資料に基づいて、正確かつ分かりやすく回答してください。

回答のルール:
1. 参考資料に記載されている情報のみを使用する
2. 具体的な数値や基準がある場合は、それを明記する
3. 安全を最優先とした助言を行う
4. 不確かな情報は推測しない
5. 回答の最後に根拠となった資料を明示する
"""
    
    def _fallback_answer(self, question: str, context: RetrievedContext) -> str:
        """LLMが利用できない場合のフォールバック"""
        if not context.has_results:
            return "関連する情報が見つかりませんでした。"
        
        # 最も関連性の高い結果を返す
        best_result = max(context.results, key=lambda r: r.score)
        
        return f"""【参考情報】

{best_result.content}

※この回答はナレッジベースの検索結果です。詳細はソース「{best_result.source}」を確認してください。"""


# =============================================================================
# シングルトン
# =============================================================================

_rag_retriever: Optional[RAGRetriever] = None
_rag_chain: Optional[RAGChain] = None

def get_rag_retriever(config: RAGConfig = None) -> RAGRetriever:
    """RAGリトリーバーのシングルトンを取得"""
    global _rag_retriever
    
    if _rag_retriever is None:
        _rag_retriever = RAGRetriever(config)
    
    return _rag_retriever

def get_rag_chain(config: RAGConfig = None) -> RAGChain:
    """RAGチェーンのシングルトンを取得"""
    global _rag_chain
    
    if _rag_chain is None:
        _rag_chain = RAGChain(config=config)
    
    return _rag_chain
