"""
RAG ナレッジベースパッケージ

避難マニュアル、ガイドラインのベクトル化とLangChain統合
"""

from .config import (
    RAGConfig,
    EmbeddingConfig,
    VectorStoreConfig,
    ChunkingConfig,
    EmbeddingModel,
    VectorStoreType,
    DocumentType,
    DocumentMetadata,
)

from .document_loader import (
    DocumentLoader,
    DocumentChunk,
    JapaneseTextSplitter,
    create_sample_evacuation_documents,
)

from .vector_store import (
    VectorStore,
    SearchResult,
    EmbeddingFunction,
    get_vector_store,
)

from .retriever import (
    RAGRetriever,
    RAGChain,
    RetrievedContext,
    get_rag_retriever,
    get_rag_chain,
)

from .langchain_tools import (
    create_langchain_tools,
    create_evacuation_agent,
    run_agent_query,
)


__all__ = [
    # 設定
    "RAGConfig",
    "EmbeddingConfig",
    "VectorStoreConfig",
    "ChunkingConfig",
    "EmbeddingModel",
    "VectorStoreType",
    "DocumentType",
    "DocumentMetadata",
    
    # ドキュメントローダー
    "DocumentLoader",
    "DocumentChunk",
    "JapaneseTextSplitter",
    "create_sample_evacuation_documents",
    
    # ベクトルストア
    "VectorStore",
    "SearchResult",
    "EmbeddingFunction",
    "get_vector_store",
    
    # リトリーバー
    "RAGRetriever",
    "RAGChain",
    "RetrievedContext",
    "get_rag_retriever",
    "get_rag_chain",
    
    # LangChain統合
    "create_langchain_tools",
    "create_evacuation_agent",
    "run_agent_query",
]
