"""
RAG ナレッジベース 設定

ベクトルストア、エンベディング、チャンキングの設定
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional
import os


class EmbeddingModel(Enum):
    """エンベディングモデル"""
    
    # OpenAI
    OPENAI_ADA_002 = "text-embedding-ada-002"
    OPENAI_3_SMALL = "text-embedding-3-small"
    OPENAI_3_LARGE = "text-embedding-3-large"
    
    # 日本語対応モデル
    MULTILINGUAL_E5_LARGE = "intfloat/multilingual-e5-large"
    MULTILINGUAL_E5_BASE = "intfloat/multilingual-e5-base"
    
    # ローカル軽量モデル
    ALL_MINILM_L6 = "sentence-transformers/all-MiniLM-L6-v2"


class VectorStoreType(Enum):
    """ベクトルストアタイプ"""
    CHROMA = "chroma"
    FAISS = "faiss"
    IN_MEMORY = "in_memory"


@dataclass
class ChunkingConfig:
    """テキストチャンキング設定"""
    
    # チャンクサイズ（文字数）
    chunk_size: int = 1000
    
    # チャンクオーバーラップ
    chunk_overlap: int = 200
    
    # セパレータ（日本語対応）
    separators: List[str] = field(default_factory=lambda: [
        "\n\n",   # 段落区切り
        "\n",     # 改行
        "。",     # 句点
        "、",     # 読点
        " ",      # スペース
        ""        # 文字単位
    ])
    
    # 長さ関数
    length_function: str = "len"


@dataclass
class EmbeddingConfig:
    """エンベディング設定"""
    
    # 使用モデル
    model: EmbeddingModel = EmbeddingModel.MULTILINGUAL_E5_BASE
    
    # OpenAI APIキー（OpenAIモデル使用時）
    openai_api_key: Optional[str] = None
    
    # バッチサイズ
    batch_size: int = 100
    
    # 次元数（モデルによって異なる）
    dimensions: Optional[int] = None
    
    @classmethod
    def from_env(cls) -> "EmbeddingConfig":
        """環境変数から設定を読み込み"""
        model_name = os.getenv("EMBEDDING_MODEL", "intfloat/multilingual-e5-base")
        
        # モデル名からEnumを取得
        model = EmbeddingModel.MULTILINGUAL_E5_BASE
        for m in EmbeddingModel:
            if m.value == model_name:
                model = m
                break
        
        return cls(
            model=model,
            openai_api_key=os.getenv("OPENAI_API_KEY"),
        )


@dataclass
class VectorStoreConfig:
    """ベクトルストア設定"""
    
    # ストアタイプ
    store_type: VectorStoreType = VectorStoreType.CHROMA
    
    # 永続化ディレクトリ
    persist_directory: str = ".vectorstore"
    
    # コレクション名
    collection_name: str = "evacuation_knowledge"
    
    # 類似度メトリック
    distance_metric: str = "cosine"
    
    # 検索時のトップK
    search_k: int = 5
    
    # スコアしきい値（0-1、低いほど類似）
    score_threshold: float = 0.7


@dataclass
class RAGConfig:
    """RAG全体設定"""
    
    chunking: ChunkingConfig = field(default_factory=ChunkingConfig)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    vector_store: VectorStoreConfig = field(default_factory=VectorStoreConfig)
    
    # LLM設定
    llm_model: str = "gpt-4o-mini"
    llm_temperature: float = 0.2
    llm_max_tokens: int = 2048
    
    # コンテキスト設定
    max_context_length: int = 4000
    include_metadata: bool = True
    
    @classmethod
    def from_env(cls) -> "RAGConfig":
        """環境変数から設定を読み込み"""
        return cls(
            embedding=EmbeddingConfig.from_env(),
            llm_model=os.getenv("LLM_MODEL", "gpt-4o-mini"),
            llm_temperature=float(os.getenv("LLM_TEMPERATURE", "0.2")),
        )


# =============================================================================
# RAGシステムで使用するドキュメントタイプ
# =============================================================================

class DocumentType(Enum):
    """ナレッジベースに格納するドキュメントタイプ"""
    
    EVACUATION_MANUAL = "evacuation_manual"     # 避難計画マニュアル
    API_DOCUMENTATION = "api_documentation"      # 地理院地図API仕様
    DISASTER_GUIDELINE = "disaster_guideline"    # 災害対応ガイドライン
    SHELTER_INFO = "shelter_info"                # 避難所情報
    HAZARD_MAP_GUIDE = "hazard_map_guide"        # ハザードマップ解説
    LEGAL_DOCUMENT = "legal_document"            # 防災関連法規


@dataclass
class DocumentMetadata:
    """ドキュメントメタデータ"""
    
    # 必須フィールド
    doc_type: DocumentType
    source: str           # ソースファイル/URL
    
    # オプションフィールド
    title: Optional[str] = None
    author: Optional[str] = None
    created_date: Optional[str] = None
    updated_date: Optional[str] = None
    municipality_code: Optional[str] = None  # 自治体コード
    prefecture: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        """辞書形式に変換"""
        return {
            "doc_type": self.doc_type.value,
            "source": self.source,
            "title": self.title,
            "author": self.author,
            "created_date": self.created_date,
            "updated_date": self.updated_date,
            "municipality_code": self.municipality_code,
            "prefecture": self.prefecture,
            "tags": ",".join(self.tags) if self.tags else None
        }
