"""
LangChain ツール統合

避難支援APIツールをLangChainエージェント用にラップ
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional, Type

logger = logging.getLogger(__name__)


# =============================================================================
# ツール定義（LangChain互換）
# =============================================================================

def create_langchain_tools():
    """LangChainツールを作成
    
    既存のAPIツールをLangChainのTool形式に変換
    """
    try:
        from langchain_core.tools import BaseTool, tool
        from pydantic import BaseModel, Field
    except ImportError:
        logger.error("langchain-core未インストール")
        return []
    
    tools = []
    
    # -------------------------------------------------------------------------
    # 標高取得ツール
    # -------------------------------------------------------------------------
    
    class GetElevationInput(BaseModel):
        """標高取得の入力スキーマ"""
        latitude: float = Field(description="緯度（例: 35.6812）")
        longitude: float = Field(description="経度（例: 139.7671）")
    
    @tool("get_elevation", args_schema=GetElevationInput)
    async def get_elevation_tool(latitude: float, longitude: float) -> str:
        """指定地点の標高（海抜）を取得します。浸水リスクの判断や避難所の安全性評価に使用します。"""
        from src.tools.gsi_tools import get_elevation
        
        result = await get_elevation(latitude, longitude)
        
        if result.get("success"):
            return f"標高: {result['elevation']}m（データソース: {result.get('data_source', '不明')}）"
        else:
            return f"標高データ取得エラー: {result.get('error', '不明なエラー')}"
    
    tools.append(get_elevation_tool)
    
    # -------------------------------------------------------------------------
    # 浸水リスク判定ツール
    # -------------------------------------------------------------------------
    
    class CheckFloodRiskInput(BaseModel):
        """浸水リスク判定の入力スキーマ"""
        latitude: float = Field(description="緯度")
        longitude: float = Field(description="経度")
        scenario: str = Field(
            default="L2",
            description="想定シナリオ（L1: 計画規模, L2: 想定最大規模）"
        )
    
    @tool("check_flood_risk", args_schema=CheckFloodRiskInput)
    async def check_flood_risk_tool(latitude: float, longitude: float, scenario: str = "L2") -> str:
        """指定地点の浸水リスクを判定します。洪水浸水想定区域のデータに基づき、想定浸水深を取得します。"""
        from src.tools.hazard_tools import check_flood_risk
        
        result = await check_flood_risk(latitude, longitude, scenario)
        
        depth = result.get("flood_depth", 0)
        level = result.get("risk_level", "unknown")
        recommendation = result.get("recommendation", "")
        
        return f"""浸水リスク判定結果:
- 想定浸水深: {depth}m
- リスクレベル: {level}
- 推奨: {recommendation}"""
    
    tools.append(check_flood_risk_tool)
    
    # -------------------------------------------------------------------------
    # 土砂災害警戒区域判定ツール
    # -------------------------------------------------------------------------
    
    class CheckLandslideZoneInput(BaseModel):
        """土砂災害警戒区域判定の入力スキーマ"""
        latitude: float = Field(description="緯度")
        longitude: float = Field(description="経度")
    
    @tool("check_landslide_zone", args_schema=CheckLandslideZoneInput)
    async def check_landslide_zone_tool(latitude: float, longitude: float) -> str:
        """指定地点が土砂災害警戒区域内かを判定します。イエローゾーン・レッドゾーンを確認します。"""
        from src.tools.hazard_tools import check_landslide_zone
        
        result = await check_landslide_zone(latitude, longitude)
        
        in_zone = result.get("is_in_hazard_zone", False)
        level = result.get("risk_level", "none")
        zones = result.get("zones", [])
        recommendation = result.get("recommendation", "")
        
        zone_info = ""
        if zones:
            for z in zones:
                zone_info += f"  - {z.get('zone_type', '')}: {z.get('phenomenon_type', '')}\n"
        
        return f"""土砂災害警戒区域判定結果:
- 警戒区域内: {'はい' if in_zone else 'いいえ'}
- リスクレベル: {level}
{zone_info}- 推奨: {recommendation}"""
    
    tools.append(check_landslide_zone_tool)
    
    # -------------------------------------------------------------------------
    # 総合リスク評価ツール
    # -------------------------------------------------------------------------
    
    class CheckComprehensiveRiskInput(BaseModel):
        """総合リスク評価の入力スキーマ"""
        latitude: float = Field(description="緯度")
        longitude: float = Field(description="経度")
    
    @tool("check_comprehensive_risk", args_schema=CheckComprehensiveRiskInput)
    async def check_comprehensive_risk_tool(latitude: float, longitude: float) -> str:
        """指定地点の総合災害リスク（浸水+土砂災害）を評価します。"""
        from src.tools.hazard_tools import check_comprehensive_risk
        
        result = await check_comprehensive_risk(latitude, longitude)
        
        overall = result.get("overall_risk_level", "unknown")
        priority = result.get("evacuation_priority", 5)
        summary = result.get("summary", "")
        
        return f"""総合リスク評価結果:
- 総合リスクレベル: {overall}
- 避難優先度: {priority}/5（1が最優先）
- サマリー: {summary}"""
    
    tools.append(check_comprehensive_risk_tool)
    
    # -------------------------------------------------------------------------
    # 避難所推奨ツール
    # -------------------------------------------------------------------------
    
    class RecommendShelterInput(BaseModel):
        """避難所推奨の入力スキーマ"""
        latitude: float = Field(description="現在地の緯度")
        longitude: float = Field(description="現在地の経度")
        wheelchair: bool = Field(default=False, description="車椅子使用者がいる")
        elderly: bool = Field(default=False, description="高齢者が同伴")
        pets: bool = Field(default=False, description="ペットを連れている")
        flood_risk: bool = Field(default=False, description="浸水リスクを回避したい")
    
    @tool("recommend_shelter", args_schema=RecommendShelterInput)
    async def recommend_shelter_tool(
        latitude: float,
        longitude: float,
        wheelchair: bool = False,
        elderly: bool = False,
        pets: bool = False,
        flood_risk: bool = False
    ) -> str:
        """ユーザーの状況に応じて最適な避難所を推奨します。"""
        from src.tools.shelter_tools import recommend_shelter
        
        result = await recommend_shelter(
            latitude=latitude,
            longitude=longitude,
            wheelchair=wheelchair,
            elderly=elderly,
            pets=pets,
            flood_risk=flood_risk
        )
        
        top = result.get("top_recommendation")
        
        if not top:
            return "条件に合う避難所が見つかりませんでした。"
        
        recommendations = result.get("recommendations", [])
        
        output = f"""推奨避難所:
【第1候補】{top.get('name', '不明')}
- 住所: {top.get('address', '不明')}
- 徒歩時間: {top.get('walking_time', '不明')}
- 推奨理由: {top.get('why', '')}
"""
        
        if len(recommendations) > 1:
            output += "\n【代替候補】\n"
            for rec in recommendations[1:3]:
                output += f"- {rec.get('name', '不明')} ({rec.get('walking_time', '')})\n"
        
        return output
    
    tools.append(recommend_shelter_tool)
    
    # -------------------------------------------------------------------------
    # 避難所状態確認ツール
    # -------------------------------------------------------------------------
    
    class GetShelterStatusInput(BaseModel):
        """避難所状態確認の入力スキーマ"""
        shelter_id: str = Field(description="避難所ID")
    
    @tool("get_shelter_status", args_schema=GetShelterStatusInput)
    async def get_shelter_status_tool(shelter_id: str) -> str:
        """避難所のリアルタイム開設状況・収容状況を確認します。"""
        from src.tools.shelter_tools import get_shelter_status
        
        result = await get_shelter_status(shelter_id)
        
        if not result.get("id"):
            return f"避難所ID '{shelter_id}' が見つかりませんでした。"
        
        return f"""避難所状態:
- 名称: {result.get('name', '不明')}
- 開設状況: {result.get('open_status', '不明')}
- 収容人数: {result.get('current_occupancy', 0)}/{result.get('capacity', 0)}
- 残り収容可能: {result.get('available_capacity', 0)}人
- 混雑度: {result.get('occupancy_rate', 0):.1f}%"""
    
    tools.append(get_shelter_status_tool)
    
    # -------------------------------------------------------------------------
    # ナレッジベース検索ツール
    # -------------------------------------------------------------------------
    
    class SearchKnowledgeBaseInput(BaseModel):
        """ナレッジベース検索の入力スキーマ"""
        query: str = Field(description="検索クエリ（避難に関する質問）")
    
    @tool("search_knowledge_base", args_schema=SearchKnowledgeBaseInput)
    def search_knowledge_base_tool(query: str) -> str:
        """避難マニュアルやガイドラインから関連情報を検索します。"""
        from src.knowledge_base.retriever import get_rag_retriever
        
        retriever = get_rag_retriever()
        context = retriever.retrieve_for_evacuation(query)
        
        if not context.has_results:
            return "関連する情報が見つかりませんでした。"
        
        # 上位3件を返す
        output = f"【検索結果: {len(context.results)}件】\n\n"
        
        for i, result in enumerate(context.results[:3], 1):
            output += f"---\n【結果{i}】ソース: {result.source}\n"
            output += f"関連度: {result.score:.2f}\n"
            output += f"{result.content[:500]}...\n"
        
        return output
    
    tools.append(search_knowledge_base_tool)
    
    logger.info(f"{len(tools)} 個のLangChainツールを作成")
    return tools


# =============================================================================
# エージェント作成
# =============================================================================

def create_evacuation_agent(model_name: str = "gpt-4o-mini"):
    """避難支援エージェントを作成
    
    Args:
        model_name: 使用するLLMモデル名
    
    Returns:
        AgentExecutor: LangChainエージェント
    """
    try:
        from langchain_openai import ChatOpenAI
        from langchain.agents import AgentExecutor, create_tool_calling_agent
        from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
    except ImportError as e:
        logger.error(f"LangChain依存関係が不足: {e}")
        return None
    
    # ツールを作成
    tools = create_langchain_tools()
    
    if not tools:
        logger.error("ツールの作成に失敗")
        return None
    
    # LLMを初期化
    llm = ChatOpenAI(model=model_name, temperature=0.2)
    
    # プロンプトテンプレート
    prompt = ChatPromptTemplate.from_messages([
        ("system", """あなたは「避難支援エージェント」です。
国土地理院の地理空間データとナレッジベースの避難マニュアルを活用して、
ユーザーの避難判断を支援します。

## できること
- 災害リスク（浸水・土砂災害）の評価
- 最適な避難所の提案
- 避難に関する質問への回答

## 行動指針
1. 安全を最優先に判断する
2. 具体的な数値（標高、浸水深、距離）を示す
3. 複数の選択肢がある場合は代替案も提示する
4. 不確かな情報は推測しない

## 応答形式
- 結論を最初に述べる
- 根拠を明確に説明する
- 具体的なアクションを提示する
"""),
        MessagesPlaceholder(variable_name="chat_history", optional=True),
        ("human", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ])
    
    # エージェントを作成
    agent = create_tool_calling_agent(llm, tools, prompt)
    
    # エージェントエグゼキューターを作成
    agent_executor = AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,
        max_iterations=10,
        handle_parsing_errors=True
    )
    
    logger.info("避難支援エージェントを作成しました")
    return agent_executor


# =============================================================================
# 簡易実行関数
# =============================================================================

async def run_agent_query(query: str, model_name: str = "gpt-4o-mini") -> str:
    """エージェントにクエリを実行
    
    Args:
        query: ユーザーからの質問
        model_name: 使用するLLMモデル
    
    Returns:
        str: エージェントの回答
    """
    agent = create_evacuation_agent(model_name)
    
    if not agent:
        return "エージェントの初期化に失敗しました。"
    
    try:
        result = await agent.ainvoke({"input": query})
        return result.get("output", "回答を生成できませんでした。")
    except Exception as e:
        logger.error(f"エージェント実行エラー: {e}")
        return f"エラーが発生しました: {e}"
