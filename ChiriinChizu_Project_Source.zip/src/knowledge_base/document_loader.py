"""
ドキュメントローダー

各種形式のドキュメント（PDF、Markdown、テキスト等）を読み込み、
RAGナレッジベース用にチャンク化する
"""

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass

from .config import (
    ChunkingConfig,
    DocumentMetadata,
    DocumentType,
    RAGConfig,
)

logger = logging.getLogger(__name__)


# =============================================================================
# ドキュメントチャンク
# =============================================================================

@dataclass
class DocumentChunk:
    """ドキュメントチャンク"""
    
    content: str                    # テキスト内容
    metadata: Dict[str, Any]        # メタデータ
    chunk_index: int                # チャンクインデックス
    total_chunks: int               # 全チャンク数
    
    @property
    def char_count(self) -> int:
        """文字数"""
        return len(self.content)


# =============================================================================
# テキストスプリッター
# =============================================================================

class JapaneseTextSplitter:
    """日本語対応テキストスプリッター
    
    日本語の文構造を考慮したチャンク分割を行う
    """
    
    def __init__(self, config: ChunkingConfig = None):
        self.config = config or ChunkingConfig()
    
    def split_text(self, text: str) -> List[str]:
        """テキストをチャンクに分割"""
        chunks = []
        current_chunk = ""
        
        # セパレータで分割を試行
        segments = self._split_by_separators(text)
        
        for segment in segments:
            # 現在のチャンクに追加してもサイズ内なら追加
            if len(current_chunk) + len(segment) <= self.config.chunk_size:
                current_chunk += segment
            else:
                # 現在のチャンクを保存
                if current_chunk.strip():
                    chunks.append(current_chunk.strip())
                
                # セグメントがチャンクサイズを超える場合は強制分割
                if len(segment) > self.config.chunk_size:
                    sub_chunks = self._force_split(segment)
                    chunks.extend(sub_chunks[:-1])
                    current_chunk = sub_chunks[-1] if sub_chunks else ""
                else:
                    current_chunk = segment
        
        # 最後のチャンクを追加
        if current_chunk.strip():
            chunks.append(current_chunk.strip())
        
        # オーバーラップ処理
        if self.config.chunk_overlap > 0:
            chunks = self._add_overlap(chunks)
        
        return chunks
    
    def _split_by_separators(self, text: str) -> List[str]:
        """セパレータで分割"""
        segments = [text]
        
        for separator in self.config.separators:
            if not separator:
                continue
            
            new_segments = []
            for segment in segments:
                parts = segment.split(separator)
                for i, part in enumerate(parts):
                    if i < len(parts) - 1:
                        new_segments.append(part + separator)
                    else:
                        new_segments.append(part)
            segments = new_segments
        
        return [s for s in segments if s]
    
    def _force_split(self, text: str) -> List[str]:
        """強制的にサイズで分割"""
        chunks = []
        for i in range(0, len(text), self.config.chunk_size):
            chunks.append(text[i:i + self.config.chunk_size])
        return chunks
    
    def _add_overlap(self, chunks: List[str]) -> List[str]:
        """チャンク間にオーバーラップを追加"""
        if len(chunks) <= 1:
            return chunks
        
        overlapped = []
        for i, chunk in enumerate(chunks):
            if i > 0:
                # 前のチャンクの末尾を追加
                overlap_text = chunks[i - 1][-self.config.chunk_overlap:]
                chunk = overlap_text + chunk
            overlapped.append(chunk)
        
        return overlapped


# =============================================================================
# ドキュメントローダー
# =============================================================================

class DocumentLoader:
    """ドキュメントローダー"""
    
    def __init__(self, config: RAGConfig = None):
        self.config = config or RAGConfig()
        self.text_splitter = JapaneseTextSplitter(self.config.chunking)
    
    def load_text_file(
        self,
        file_path: str,
        metadata: DocumentMetadata
    ) -> List[DocumentChunk]:
        """テキストファイルを読み込み"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            
            return self._create_chunks(content, metadata)
        
        except Exception as e:
            logger.error(f"テキストファイル読み込みエラー: {file_path} - {e}")
            return []
    
    def load_markdown_file(
        self,
        file_path: str,
        metadata: DocumentMetadata
    ) -> List[DocumentChunk]:
        """Markdownファイルを読み込み"""
        return self.load_text_file(file_path, metadata)
    
    def load_from_string(
        self,
        content: str,
        metadata: DocumentMetadata
    ) -> List[DocumentChunk]:
        """文字列から読み込み"""
        return self._create_chunks(content, metadata)
    
    def load_directory(
        self,
        directory_path: str,
        doc_type: DocumentType,
        extensions: List[str] = None
    ) -> List[DocumentChunk]:
        """ディレクトリ内のファイルを一括読み込み"""
        extensions = extensions or [".txt", ".md"]
        all_chunks = []
        
        directory = Path(directory_path)
        if not directory.exists():
            logger.warning(f"ディレクトリが存在しません: {directory_path}")
            return []
        
        for file_path in directory.rglob("*"):
            if file_path.suffix.lower() in extensions:
                metadata = DocumentMetadata(
                    doc_type=doc_type,
                    source=str(file_path),
                    title=file_path.stem
                )
                chunks = self.load_text_file(str(file_path), metadata)
                all_chunks.extend(chunks)
        
        logger.info(f"{len(all_chunks)} チャンクを読み込み: {directory_path}")
        return all_chunks
    
    def _create_chunks(
        self,
        content: str,
        metadata: DocumentMetadata
    ) -> List[DocumentChunk]:
        """コンテンツをチャンク化"""
        text_chunks = self.text_splitter.split_text(content)
        
        chunks = []
        for i, text in enumerate(text_chunks):
            chunk_metadata = metadata.to_dict()
            chunk_metadata["chunk_index"] = i
            chunk_metadata["total_chunks"] = len(text_chunks)
            
            chunks.append(DocumentChunk(
                content=text,
                metadata=chunk_metadata,
                chunk_index=i,
                total_chunks=len(text_chunks)
            ))
        
        return chunks


# =============================================================================
# サンプルドキュメント生成
# =============================================================================

def create_sample_evacuation_documents() -> List[DocumentChunk]:
    """サンプル避難マニュアルドキュメントを生成
    
    実際の運用ではPDFやファイルから読み込む
    """
    loader = DocumentLoader()
    
    # 避難計画マニュアル（サンプル）
    evacuation_manual = """
# 避難計画マニュアル

## 1. 避難の基本原則

### 1.1 早期避難の重要性
災害時には、安全なうちに避難を開始することが最も重要です。
特に土砂災害や洪水の場合、状況が悪化してからでは避難が困難になります。

### 1.2 警戒レベルと避難行動

#### 警戒レベル1（早期注意情報）
災害への心構えを高める段階です。
最新の防災気象情報に注意してください。

#### 警戒レベル2（大雨・洪水注意報）
避難に備え、ハザードマップ等により自らの避難行動を確認しましょう。

#### 警戒レベル3（高齢者等避難）
高齢者等、避難に時間を要する人は避難を開始してください。
その他の人も避難の準備を整え、自発的に避難するタイミングです。

#### 警戒レベル4（避難指示）
危険な場所から全員避難してください。
これ以降に発令される警戒レベル5を待ってはいけません。

#### 警戒レベル5（緊急安全確保）
すでに何らかの災害が発生している可能性が極めて高い状況です。
命を守る最善の行動をとってください。

## 2. 避難所の種類

### 2.1 指定避難所
災害発生後に避難した住民等を滞在させるための施設です。
学校の体育館や公民館などが指定されています。

### 2.2 指定緊急避難場所
災害の危険から緊急的に逃れるための場所です。
公園や広場などのオープンスペースが指定されています。

### 2.3 福祉避難所
高齢者や障害者など、特別な配慮を必要とする方のための避難所です。
バリアフリー設備や専門スタッフが配置されています。

## 3. 避難時の注意事項

### 3.1 持ち出し品
- 飲料水（1人1日3リットル）
- 食料（最低3日分）
- 懐中電灯
- 携帯ラジオ
- 常備薬
- 貴重品（現金、保険証等）

### 3.2 避難経路
- 事前にハザードマップで危険箇所を確認
- 浸水想定区域や土砂災害警戒区域を避ける
- 河川や崖から離れたルートを選択
- 複数の経路を確認しておく

### 3.3 車での避難
車での避難は原則として控えてください。
渋滞や冠水により、かえって危険な状況に陥る可能性があります。
"""

    chunks1 = loader.load_from_string(
        evacuation_manual,
        DocumentMetadata(
            doc_type=DocumentType.EVACUATION_MANUAL,
            source="sample_evacuation_manual",
            title="避難計画マニュアル",
            author="防災課"
        )
    )
    
    # 浸水時の対応ガイドライン
    flood_guideline = """
# 浸水時の対応ガイドライン

## 1. 浸水深と危険度

### 0.5m未満（床下浸水）
- 歩行は可能ですが、足元に注意が必要です
- 床下への浸水により、設備への影響が出始めます
- 貴重品を高い場所に移動させてください

### 0.5m〜1.0m（床上浸水）
- 歩行が困難になり始めます
- 車での移動は非常に危険です
- 垂直避難（2階以上への移動）を検討してください

### 1.0m〜2.0m
- 1階部分が完全に浸水する深さです
- 外出は極めて危険です
- 2階以上への垂直避難を行ってください

### 2.0m以上
- 2階部分も浸水する可能性があります
- 3階以上または高台への避難が必要です
- 救助要請をする場合に備えてください

## 2. 垂直避難の判断

以下の場合は無理に水平避難せず、垂直避難を選択してください：

- すでに周辺が浸水している
- 夜間で視界が悪い
- 避難所までの経路が浸水している
- 高齢者や乳幼児がいる

## 3. 河川氾濫時の注意

### 堤防決壊の前兆
- 堤防からの漏水
- 堤防の陥没や変形
- 濁った水の噴出

これらの前兆を発見したら、直ちに行政機関に通報し、
河川から離れた場所に避難してください。
"""

    chunks2 = loader.load_from_string(
        flood_guideline,
        DocumentMetadata(
            doc_type=DocumentType.DISASTER_GUIDELINE,
            source="flood_response_guideline",
            title="浸水時の対応ガイドライン",
            tags=["洪水", "浸水", "避難"]
        )
    )
    
    # 土砂災害対応
    landslide_guideline = """
# 土砂災害対応ガイドライン

## 1. 土砂災害の種類

### がけ崩れ（急傾斜地の崩壊）
斜面が突然崩れ落ちる現象です。
前兆なく発生することが多く、逃げる時間的余裕がありません。
傾斜角30度以上、高さ5m以上の斜面で発生リスクが高まります。

### 土石流
山腹や川底の土砂が、長雨や集中豪雨によって一気に下流へ押し流される現象です。
流速は時速20〜40kmにも達し、大きな破壊力を持ちます。

### 地すべり
斜面の一部または全部がゆっくりと下方に移動する現象です。
がけ崩れに比べると移動速度は遅いですが、広範囲に被害が及びます。

## 2. 土砂災害警戒区域

### イエローゾーン（土砂災害警戒区域）
土砂災害のおそれがある区域です。
警戒避難体制の整備が義務付けられています。
大雨時は早めの避難を心がけてください。

### レッドゾーン（土砂災害特別警戒区域）
特に危険性が高い区域です。
住宅等の新築には一定の制限があります。
大雨警報発令時は速やかに避難してください。

## 3. 前兆現象

以下の前兆を感じたら、直ちに安全な場所に避難してください：

- 斜面からの異常な出水や濁り水
- 小石がパラパラと落ちてくる
- 斜面にひび割れができる
- 地鳴りや山鳴りがする
- 樹木が傾いている
- 川の水位が急に低下する（上流で土砂が堆積している可能性）

## 4. 避難の方向

土砂災害からの避難は、土砂の流れる方向と直角方向に逃げることが基本です。
がけ崩れの場合は、斜面から離れる方向に避難してください。
"""

    chunks3 = loader.load_from_string(
        landslide_guideline,
        DocumentMetadata(
            doc_type=DocumentType.DISASTER_GUIDELINE,
            source="landslide_response_guideline",
            title="土砂災害対応ガイドライン",
            tags=["土砂災害", "がけ崩れ", "土石流", "地すべり"]
        )
    )
    
    all_chunks = chunks1 + chunks2 + chunks3
    logger.info(f"サンプルドキュメント生成完了: {len(all_chunks)} チャンク")
    
    return all_chunks
