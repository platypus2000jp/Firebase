"""
地理院地図API × Foundry IQ Agentic RAG パッケージ
"""

__version__ = "0.1.0"
__author__ = "Your Name"
