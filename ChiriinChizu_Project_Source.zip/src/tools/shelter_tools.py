"""
避難所関連ツール

Foundry IQ Ontologyとの連携を想定した避難所検索・管理機能
"""

import asyncio
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
import math

from ..config import EvacuationThresholds

logger = logging.getLogger(__name__)


# =============================================================================
# 列挙型定義
# =============================================================================

class ShelterType(Enum):
    """避難所タイプ"""
    DESIGNATED = "designated"           # 指定避難所
    WELFARE = "welfare"                 # 福祉避難所
    TEMPORARY = "temporary"             # 一時避難所
    WIDE_AREA = "wide_area"            # 広域避難場所
    TSUNAMI = "tsunami"                 # 津波避難ビル
    VERTICAL = "vertical"               # 垂直避難施設


class ShelterFacility(Enum):
    """避難所設備"""
    WHEELCHAIR_ACCESS = "wheelchair_access"  # 車椅子対応
    TOILET = "toilet"                        # トイレ
    ACCESSIBLE_TOILET = "accessible_toilet"  # 多目的トイレ
    SHOWER = "shower"                        # シャワー
    COOKING = "cooking"                      # 調理設備
    GENERATOR = "generator"                  # 自家発電
    COMMUNICATION = "communication"          # 通信設備
    MEDICAL = "medical"                      # 医療設備
    PET_FRIENDLY = "pet_friendly"            # ペット対応
    NURSERY = "nursery"                      # 授乳室


class OpenStatus(Enum):
    """開設状況"""
    OPEN = "open"           # 開設中
    CLOSED = "closed"       # 閉鎖中
    PREPARING = "preparing" # 準備中
    FULL = "full"           # 満員


# =============================================================================
# データクラス
# =============================================================================

@dataclass
class ShelterInfo:
    """避難所情報"""
    id: str
    name: str
    address: str
    latitude: float
    longitude: float
    elevation: float                    # 標高（メートル）
    shelter_type: ShelterType
    capacity: int                       # 収容人数
    current_occupancy: int = 0          # 現在の利用者数
    open_status: OpenStatus = OpenStatus.CLOSED
    floor_count: int = 1                # 階数（垂直避難用）
    facilities: List[ShelterFacility] = field(default_factory=list)
    target_disasters: List[str] = field(default_factory=list)  # 対象災害（洪水、土砂等）
    contact_phone: Optional[str] = None
    notes: Optional[str] = None
    
    @property
    def available_capacity(self) -> int:
        """残り収容可能人数"""
        return max(0, self.capacity - self.current_occupancy)
    
    @property
    def occupancy_rate(self) -> float:
        """収容率（%）"""
        if self.capacity == 0:
            return 100.0
        return (self.current_occupancy / self.capacity) * 100
    
    @property
    def is_wheelchair_accessible(self) -> bool:
        """車椅子対応かどうか"""
        return ShelterFacility.WHEELCHAIR_ACCESS in self.facilities
    
    @property
    def is_available(self) -> bool:
        """利用可能かどうか"""
        return (
            self.open_status == OpenStatus.OPEN and
            self.available_capacity > 0
        )


@dataclass
class ShelterSearchResult:
    """避難所検索結果"""
    shelters: List[ShelterInfo]
    total_count: int
    search_radius_km: float
    center_latitude: float
    center_longitude: float


@dataclass
class ShelterRecommendation:
    """避難所推奨結果"""
    shelter: ShelterInfo
    distance_km: float              # 直線距離
    estimated_walking_time_min: int # 推定徒歩時間
    suitability_score: float        # 適合スコア（0-100）
    reasons: List[str]              # 推奨理由


# =============================================================================
# デモ用避難所データ
# =============================================================================

# 実際の実装ではFoundry IQのOntologyから取得
DEMO_SHELTERS = [
    ShelterInfo(
        id="shelter_001",
        name="中央小学校",
        address="東京都足立区中央本町1-1-1",
        latitude=35.7756,
        longitude=139.8042,
        elevation=3.5,
        shelter_type=ShelterType.DESIGNATED,
        capacity=500,
        current_occupancy=0,
        floor_count=3,
        facilities=[
            ShelterFacility.WHEELCHAIR_ACCESS,
            ShelterFacility.TOILET,
            ShelterFacility.ACCESSIBLE_TOILET,
            ShelterFacility.COOKING,
        ],
        target_disasters=["洪水", "地震"],
    ),
    ShelterInfo(
        id="shelter_002",
        name="北部市民センター",
        address="東京都足立区北部2-2-2",
        latitude=35.7856,
        longitude=139.7942,
        elevation=5.2,
        shelter_type=ShelterType.DESIGNATED,
        capacity=300,
        current_occupancy=50,
        floor_count=5,
        facilities=[
            ShelterFacility.WHEELCHAIR_ACCESS,
            ShelterFacility.TOILET,
            ShelterFacility.ACCESSIBLE_TOILET,
            ShelterFacility.GENERATOR,
            ShelterFacility.COMMUNICATION,
        ],
        target_disasters=["洪水", "地震", "土砂"],
        open_status=OpenStatus.OPEN,
    ),
    ShelterInfo(
        id="shelter_003",
        name="高台公園",
        address="東京都足立区高台町3-3-3",
        latitude=35.7900,
        longitude=139.8100,
        elevation=12.0,
        shelter_type=ShelterType.WIDE_AREA,
        capacity=2000,
        floor_count=1,
        facilities=[
            ShelterFacility.TOILET,
        ],
        target_disasters=["地震", "火災"],
    ),
    ShelterInfo(
        id="shelter_004",
        name="南部福祉センター",
        address="東京都足立区南部4-4-4",
        latitude=35.7650,
        longitude=139.8150,
        elevation=4.0,
        shelter_type=ShelterType.WELFARE,
        capacity=100,
        current_occupancy=20,
        floor_count=2,
        facilities=[
            ShelterFacility.WHEELCHAIR_ACCESS,
            ShelterFacility.TOILET,
            ShelterFacility.ACCESSIBLE_TOILET,
            ShelterFacility.MEDICAL,
            ShelterFacility.NURSERY,
        ],
        target_disasters=["洪水", "地震"],
        open_status=OpenStatus.OPEN,
    ),
]


# =============================================================================
# 避難所管理クライアント
# =============================================================================

class ShelterClient:
    """避難所検索・管理クライアント
    
    Foundry IQ Ontologyとの連携を想定
    現時点ではデモデータを使用
    """
    
    def __init__(self):
        self.thresholds = EvacuationThresholds()
        # 実際の実装ではFoundry IQへの接続を初期化
        self._shelters = DEMO_SHELTERS
    
    # -------------------------------------------------------------------------
    # 避難所検索
    # -------------------------------------------------------------------------
    
    async def find_nearby_shelters(
        self,
        latitude: float,
        longitude: float,
        radius_km: float = 2.0,
        limit: int = 10
    ) -> ShelterSearchResult:
        """
        指定地点周辺の避難所を検索
        
        Args:
            latitude: 緯度
            longitude: 経度
            radius_km: 検索半径（km）
            limit: 最大取得数
        
        Returns:
            ShelterSearchResult: 検索結果
        """
        nearby = []
        
        for shelter in self._shelters:
            distance = self._haversine_distance(
                latitude, longitude,
                shelter.latitude, shelter.longitude
            )
            if distance <= radius_km:
                nearby.append((shelter, distance))
        
        # 距離でソート
        nearby.sort(key=lambda x: x[1])
        
        # 制限数を適用
        nearby = nearby[:limit]
        
        return ShelterSearchResult(
            shelters=[s for s, _ in nearby],
            total_count=len(nearby),
            search_radius_km=radius_km,
            center_latitude=latitude,
            center_longitude=longitude
        )
    
    async def find_shelters_by_criteria(
        self,
        latitude: float,
        longitude: float,
        radius_km: float = 2.0,
        min_elevation: Optional[float] = None,
        require_wheelchair: bool = False,
        require_open: bool = True,
        target_disaster: Optional[str] = None,
        min_capacity: int = 0
    ) -> ShelterSearchResult:
        """
        条件に合致する避難所を検索
        
        Args:
            latitude: 緯度
            longitude: 経度
            radius_km: 検索半径（km）
            min_elevation: 最低標高（メートル）
            require_wheelchair: 車椅子対応必須
            require_open: 開設中のみ
            target_disaster: 対象災害タイプ
            min_capacity: 最低収容人数
        
        Returns:
            ShelterSearchResult: 検索結果
        """
        nearby = await self.find_nearby_shelters(latitude, longitude, radius_km, limit=100)
        
        filtered = []
        for shelter in nearby.shelters:
            # 標高フィルタ
            if min_elevation is not None and shelter.elevation < min_elevation:
                continue
            
            # 車椅子対応フィルタ
            if require_wheelchair and not shelter.is_wheelchair_accessible:
                continue
            
            # 開設状況フィルタ
            if require_open and not shelter.is_available:
                continue
            
            # 対象災害フィルタ
            if target_disaster and target_disaster not in shelter.target_disasters:
                continue
            
            # 収容人数フィルタ
            if shelter.available_capacity < min_capacity:
                continue
            
            filtered.append(shelter)
        
        return ShelterSearchResult(
            shelters=filtered,
            total_count=len(filtered),
            search_radius_km=radius_km,
            center_latitude=latitude,
            center_longitude=longitude
        )
    
    async def recommend_shelter(
        self,
        latitude: float,
        longitude: float,
        user_requirements: Dict[str, Any] = None
    ) -> List[ShelterRecommendation]:
        """
        ユーザー要件に基づき最適な避難所を推奨
        
        Args:
            latitude: 現在地緯度
            longitude: 現在地経度
            user_requirements: ユーザー要件
                - wheelchair: 車椅子使用
                - elderly: 高齢者同伴
                - pets: ペット同伴
                - flood_risk: 浸水リスクを回避
        
        Returns:
            List[ShelterRecommendation]: 推奨避難所リスト（優先度順）
        """
        user_requirements = user_requirements or {}
        
        # 周辺避難所を取得
        nearby = await self.find_nearby_shelters(latitude, longitude, radius_km=5.0)
        
        recommendations = []
        
        for shelter in nearby.shelters:
            distance = self._haversine_distance(
                latitude, longitude,
                shelter.latitude, shelter.longitude
            )
            
            # 推定徒歩時間（時速4kmとして計算）
            walking_time = int(distance / 4.0 * 60)
            
            # 適合スコアを計算
            score, reasons = self._calculate_suitability(
                shelter, distance, user_requirements
            )
            
            if score > 0:  # スコアが0以上の避難所のみ
                recommendations.append(ShelterRecommendation(
                    shelter=shelter,
                    distance_km=distance,
                    estimated_walking_time_min=walking_time,
                    suitability_score=score,
                    reasons=reasons
                ))
        
        # スコアでソート（降順）
        recommendations.sort(key=lambda x: x.suitability_score, reverse=True)
        
        return recommendations[:5]  # 上位5件を返す
    
    def _calculate_suitability(
        self,
        shelter: ShelterInfo,
        distance_km: float,
        requirements: Dict[str, Any]
    ) -> Tuple[float, List[str]]:
        """適合スコアと理由を計算"""
        score = 100.0
        reasons = []
        
        # 距離による減点（1kmごとに10点減点）
        distance_penalty = min(distance_km * 10, 50)
        score -= distance_penalty
        
        # 開設状況
        if shelter.open_status != OpenStatus.OPEN:
            if shelter.open_status == OpenStatus.FULL:
                score -= 100  # 満員は除外
                reasons.append("満員のため利用不可")
            else:
                score -= 30
                reasons.append("現在閉鎖中")
        else:
            reasons.append("開設中")
        
        # 車椅子対応
        if requirements.get("wheelchair"):
            if shelter.is_wheelchair_accessible:
                score += 20
                reasons.append("車椅子対応あり")
            else:
                score -= 50
                reasons.append("車椅子非対応")
        
        # 高齢者対応（福祉避難所を優先）
        if requirements.get("elderly"):
            if shelter.shelter_type == ShelterType.WELFARE:
                score += 30
                reasons.append("福祉避難所")
            if ShelterFacility.MEDICAL in shelter.facilities:
                score += 10
                reasons.append("医療設備あり")
        
        # ペット対応
        if requirements.get("pets"):
            if ShelterFacility.PET_FRIENDLY in shelter.facilities:
                score += 20
                reasons.append("ペット対応")
            else:
                score -= 20
                reasons.append("ペット対応なし")
        
        # 浸水リスク回避
        if requirements.get("flood_risk"):
            # 標高が高いほど加点
            if shelter.elevation >= 10:
                score += 30
                reasons.append(f"高台（標高{shelter.elevation}m）")
            elif shelter.floor_count >= 3:
                score += 20
                reasons.append(f"垂直避難可能（{shelter.floor_count}階建て）")
            elif shelter.elevation < 5:
                score -= 20
                reasons.append(f"低地（標高{shelter.elevation}m）注意")
        
        # 収容状況
        if shelter.occupancy_rate < 50:
            score += 10
            reasons.append("余裕あり")
        elif shelter.occupancy_rate > 80:
            score -= 10
            reasons.append("混雑")
        
        return max(0, score), reasons
    
    # -------------------------------------------------------------------------
    # 避難所情報取得
    # -------------------------------------------------------------------------
    
    async def get_shelter_by_id(self, shelter_id: str) -> Optional[ShelterInfo]:
        """IDで避難所情報を取得"""
        for shelter in self._shelters:
            if shelter.id == shelter_id:
                return shelter
        return None
    
    async def get_shelter_status(self, shelter_id: str) -> Dict[str, Any]:
        """避難所の現在の状態を取得
        
        Foundry IQのリアルタイムデータと連携想定
        """
        shelter = await self.get_shelter_by_id(shelter_id)
        if not shelter:
            return {"error": "避難所が見つかりません"}
        
        return {
            "id": shelter.id,
            "name": shelter.name,
            "open_status": shelter.open_status.value,
            "capacity": shelter.capacity,
            "current_occupancy": shelter.current_occupancy,
            "available_capacity": shelter.available_capacity,
            "occupancy_rate": shelter.occupancy_rate,
            "is_available": shelter.is_available
        }
    
    # -------------------------------------------------------------------------
    # ユーティリティ
    # -------------------------------------------------------------------------
    
    def _haversine_distance(
        self,
        lat1: float, lon1: float,
        lat2: float, lon2: float
    ) -> float:
        """2点間の距離を計算（km）"""
        R = 6371  # 地球半径（km）
        
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lon2 - lon1)
        
        a = (math.sin(delta_phi / 2) ** 2 +
             math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        
        return R * c


# =============================================================================
# Foundry IQ ツール定義用ラッパー
# =============================================================================

_shelter_client: Optional[ShelterClient] = None

def get_shelter_client() -> ShelterClient:
    """ShelterClientのシングルトンインスタンスを取得"""
    global _shelter_client
    if _shelter_client is None:
        _shelter_client = ShelterClient()
    return _shelter_client


async def find_nearby_shelters(
    latitude: float,
    longitude: float,
    radius_km: float = 2.0
) -> Dict[str, Any]:
    """
    周辺の避難所を検索する
    
    指定地点から一定距離内にある避難所をリストアップします。
    
    Args:
        latitude: 緯度
        longitude: 経度
        radius_km: 検索半径（km、デフォルト: 2.0）
    
    Returns:
        dict: {
            "shelters": 避難所リスト,
            "total_count": 総数,
            "search_radius_km": 検索半径
        }
    """
    client = get_shelter_client()
    result = await client.find_nearby_shelters(latitude, longitude, radius_km)
    
    return {
        "shelters": [
            {
                "id": s.id,
                "name": s.name,
                "address": s.address,
                "latitude": s.latitude,
                "longitude": s.longitude,
                "elevation": s.elevation,
                "type": s.shelter_type.value,
                "capacity": s.capacity,
                "available_capacity": s.available_capacity,
                "is_open": s.open_status == OpenStatus.OPEN,
                "is_wheelchair_accessible": s.is_wheelchair_accessible,
                "target_disasters": s.target_disasters
            }
            for s in result.shelters
        ],
        "total_count": result.total_count,
        "search_radius_km": result.search_radius_km
    }


async def find_accessible_shelters(
    latitude: float,
    longitude: float,
    min_elevation: Optional[float] = None,
    require_wheelchair: bool = False,
    target_disaster: Optional[str] = None
) -> Dict[str, Any]:
    """
    条件に合致する避難所を検索する
    
    バリアフリー対応、標高条件、対象災害などでフィルタリングします。
    
    Args:
        latitude: 緯度
        longitude: 経度
        min_elevation: 最低標高（メートル）、浸水回避時に指定
        require_wheelchair: 車椅子対応必須
        target_disaster: 対象災害（"洪水", "土砂", "地震"等）
    
    Returns:
        dict: 条件に合致する避難所リスト
    """
    client = get_shelter_client()
    result = await client.find_shelters_by_criteria(
        latitude=latitude,
        longitude=longitude,
        radius_km=5.0,
        min_elevation=min_elevation,
        require_wheelchair=require_wheelchair,
        require_open=True,
        target_disaster=target_disaster
    )
    
    return {
        "shelters": [
            {
                "id": s.id,
                "name": s.name,
                "address": s.address,
                "latitude": s.latitude,
                "longitude": s.longitude,
                "elevation": s.elevation,
                "type": s.shelter_type.value,
                "available_capacity": s.available_capacity,
                "facilities": [f.value for f in s.facilities]
            }
            for s in result.shelters
        ],
        "total_count": result.total_count,
        "filters_applied": {
            "min_elevation": min_elevation,
            "wheelchair": require_wheelchair,
            "disaster": target_disaster
        }
    }


async def recommend_shelter(
    latitude: float,
    longitude: float,
    wheelchair: bool = False,
    elderly: bool = False,
    pets: bool = False,
    flood_risk: bool = False
) -> Dict[str, Any]:
    """
    最適な避難所を推奨する
    
    ユーザーの状況（車椅子、高齢者、ペット、浸水リスク等）を考慮し、
    最適な避難所を優先度順にリストアップします。
    
    Args:
        latitude: 現在地緯度
        longitude: 現在地経度
        wheelchair: 車椅子使用者がいる
        elderly: 高齢者が同伴
        pets: ペットを連れている
        flood_risk: 浸水リスクを回避したい
    
    Returns:
        dict: {
            "recommendations": 推奨避難所リスト（優先度順）,
            "top_recommendation": 最も推奨される避難所
        }
    """
    client = get_shelter_client()
    
    requirements = {
        "wheelchair": wheelchair,
        "elderly": elderly,
        "pets": pets,
        "flood_risk": flood_risk
    }
    
    recommendations = await client.recommend_shelter(
        latitude, longitude, requirements
    )
    
    result = {
        "recommendations": [
            {
                "shelter": {
                    "id": r.shelter.id,
                    "name": r.shelter.name,
                    "address": r.shelter.address,
                    "latitude": r.shelter.latitude,
                    "longitude": r.shelter.longitude,
                    "elevation": r.shelter.elevation
                },
                "distance_km": round(r.distance_km, 2),
                "walking_time_min": r.estimated_walking_time_min,
                "suitability_score": round(r.suitability_score, 1),
                "reasons": r.reasons
            }
            for r in recommendations
        ]
    }
    
    if recommendations:
        top = recommendations[0]
        result["top_recommendation"] = {
            "name": top.shelter.name,
            "address": top.shelter.address,
            "walking_time": f"約{top.estimated_walking_time_min}分",
            "why": ", ".join(top.reasons[:3])
        }
    
    return result


async def get_shelter_status(shelter_id: str) -> Dict[str, Any]:
    """
    避難所の現在の状態を取得する
    
    リアルタイムの開設状況、収容状況を確認します。
    
    Args:
        shelter_id: 避難所ID
    
    Returns:
        dict: 避難所の現在の状態
    """
    client = get_shelter_client()
    return await client.get_shelter_status(shelter_id)
