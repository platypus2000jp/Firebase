"""
地理院地図API × Foundry IQ ツールパッケージ
"""

from .gsi_tools import (
    get_elevation,
    get_elevation_profile,
    get_disaster_map_tiles,
    GSIApiClient,
)

from .hazard_tools import (
    check_flood_risk,
    check_landslide_zone,
    check_comprehensive_risk,
    evaluate_route_safety,
    HazardAssessmentClient,
)

from .shelter_tools import (
    find_nearby_shelters,
    find_accessible_shelters,
    recommend_shelter,
    get_shelter_status,
    ShelterClient,
)

__all__ = [
    # GSI API ツール
    "get_elevation",
    "get_elevation_profile",
    "get_disaster_map_tiles",
    "GSIApiClient",
    
    # 災害リスク判定ツール
    "check_flood_risk",
    "check_landslide_zone",
    "check_comprehensive_risk",
    "evaluate_route_safety",
    "HazardAssessmentClient",
    
    # 避難所ツール
    "find_nearby_shelters",
    "find_accessible_shelters",
    "recommend_shelter",
    "get_shelter_status",
    "ShelterClient",
]
