"""
地理院地図API ツール関数

国土地理院が提供するAPIと連携し、標高データ・地図タイルを取得する
避難支援Agentic RAGのコアツール
"""

import asyncio
import aiohttp
import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..config import (
    GSIEndpoints,
    GSITileLayers,
    RateLimitConfig,
    CacheConfig,
    EvacuationThresholds,
)

logger = logging.getLogger(__name__)


# =============================================================================
# データクラス
# =============================================================================

@dataclass
class ElevationResult:
    """標高取得結果"""
    latitude: float
    longitude: float
    elevation: float          # 標高（メートル）
    data_source: str          # データソース（5m DEM, 10m DEM等）
    success: bool
    error_message: Optional[str] = None


@dataclass
class ElevationProfilePoint:
    """経路上の標高プロファイル点"""
    latitude: float
    longitude: float
    elevation: float
    distance_from_start: float  # 開始点からの距離（メートル）


@dataclass
class ElevationProfile:
    """経路標高プロファイル"""
    points: List[ElevationProfilePoint]
    total_distance: float       # 総距離（メートル）
    elevation_gain: float       # 累積標高上昇（メートル）
    elevation_loss: float       # 累積標高下降（メートル）
    max_elevation: float        # 最高標高
    min_elevation: float        # 最低標高
    max_gradient: float         # 最大勾配（%）
    is_wheelchair_accessible: bool  # 車椅子対応可否


# =============================================================================
# キャッシュ管理
# =============================================================================

class CacheManager:
    """APIレスポンスのキャッシュ管理"""
    
    def __init__(self, config: CacheConfig = CacheConfig()):
        self.config = config
        self.cache_dir = Path(config.CACHE_DIR)
        if config.ENABLED:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_cache_key(self, endpoint: str, params: Dict) -> str:
        """キャッシュキーを生成"""
        key_data = f"{endpoint}:{json.dumps(params, sort_keys=True)}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def get(self, endpoint: str, params: Dict, ttl: int) -> Optional[Any]:
        """キャッシュから取得"""
        if not self.config.ENABLED:
            return None
        
        cache_key = self._get_cache_key(endpoint, params)
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        if not cache_file.exists():
            return None
        
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                cached = json.load(f)
            
            if time.time() - cached["timestamp"] > ttl:
                cache_file.unlink()
                return None
            
            return cached["data"]
        except Exception as e:
            logger.warning(f"キャッシュ読み込みエラー: {e}")
            return None
    
    def set(self, endpoint: str, params: Dict, data: Any) -> None:
        """キャッシュに保存"""
        if not self.config.ENABLED:
            return
        
        cache_key = self._get_cache_key(endpoint, params)
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        try:
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump({
                    "timestamp": time.time(),
                    "data": data
                }, f, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"キャッシュ書き込みエラー: {e}")


# =============================================================================
# レート制限
# =============================================================================

class RateLimiter:
    """API呼び出しレート制限"""
    
    def __init__(self, config: RateLimitConfig = RateLimitConfig()):
        self.config = config
        self._last_request_time = 0.0
        self._lock = asyncio.Lock()
    
    async def acquire(self):
        """レート制限を適用して待機"""
        async with self._lock:
            elapsed = time.time() - self._last_request_time
            if elapsed < self.config.MIN_REQUEST_INTERVAL:
                await asyncio.sleep(self.config.MIN_REQUEST_INTERVAL - elapsed)
            self._last_request_time = time.time()


# =============================================================================
# GSI APIクライアント
# =============================================================================

class GSIApiClient:
    """国土地理院API クライアント"""
    
    def __init__(self):
        self.cache = CacheManager()
        self.rate_limiter = RateLimiter()
        self.thresholds = EvacuationThresholds()
    
    # -------------------------------------------------------------------------
    # 標高API
    # -------------------------------------------------------------------------
    
    async def get_elevation(
        self,
        latitude: float,
        longitude: float
    ) -> ElevationResult:
        """
        指定地点の標高を取得
        
        Args:
            latitude: 緯度（度）
            longitude: 経度（度）
        
        Returns:
            ElevationResult: 標高データと取得結果
        
        Example:
            >>> client = GSIApiClient()
            >>> result = await client.get_elevation(35.6812, 139.7671)
            >>> print(f"標高: {result.elevation}m")
        """
        params = {"lat": latitude, "lon": longitude, "outtype": "JSON"}
        
        # キャッシュ確認
        cached = self.cache.get(
            GSIEndpoints.ELEVATION_API,
            params,
            CacheConfig.ELEVATION_TTL
        )
        if cached:
            return ElevationResult(
                latitude=latitude,
                longitude=longitude,
                elevation=cached["elevation"],
                data_source=cached.get("hsrc", "unknown"),
                success=True
            )
        
        # レート制限適用
        await self.rate_limiter.acquire()
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    GSIEndpoints.ELEVATION_API,
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status != 200:
                        return ElevationResult(
                            latitude=latitude,
                            longitude=longitude,
                            elevation=0.0,
                            data_source="",
                            success=False,
                            error_message=f"HTTP {response.status}"
                        )
                    
                    data = await response.json()
                    
                    # エラーチェック
                    elevation = data.get("elevation")
                    if elevation is None or elevation == "-----":
                        return ElevationResult(
                            latitude=latitude,
                            longitude=longitude,
                            elevation=0.0,
                            data_source="",
                            success=False,
                            error_message="標高データが存在しない地点です"
                        )
                    
                    result = ElevationResult(
                        latitude=latitude,
                        longitude=longitude,
                        elevation=float(elevation),
                        data_source=data.get("hsrc", "unknown"),
                        success=True
                    )
                    
                    # キャッシュ保存
                    self.cache.set(GSIEndpoints.ELEVATION_API, params, data)
                    
                    return result
                    
        except asyncio.TimeoutError:
            return ElevationResult(
                latitude=latitude,
                longitude=longitude,
                elevation=0.0,
                data_source="",
                success=False,
                error_message="リクエストタイムアウト"
            )
        except Exception as e:
            logger.error(f"標高API呼び出しエラー: {e}")
            return ElevationResult(
                latitude=latitude,
                longitude=longitude,
                elevation=0.0,
                data_source="",
                success=False,
                error_message=str(e)
            )
    
    async def get_elevation_profile(
        self,
        coordinates: List[Tuple[float, float]],
        num_samples: int = 20
    ) -> ElevationProfile:
        """
        経路上の標高プロファイルを取得
        
        避難経路の勾配確認、車椅子対応ルート判定に使用
        
        Args:
            coordinates: 経路座標リスト [(lat, lon), ...]
            num_samples: サンプリング点数
        
        Returns:
            ElevationProfile: 経路標高プロファイル
        
        Example:
            >>> route = [(35.68, 139.76), (35.69, 139.77)]
            >>> profile = await client.get_elevation_profile(route)
            >>> print(f"最大勾配: {profile.max_gradient}%")
            >>> print(f"車椅子対応: {profile.is_wheelchair_accessible}")
        """
        if len(coordinates) < 2:
            raise ValueError("経路には2点以上の座標が必要です")
        
        # 経路上のサンプル点を生成
        sample_points = self._interpolate_route(coordinates, num_samples)
        
        # 各点の標高を取得
        profile_points: List[ElevationProfilePoint] = []
        cumulative_distance = 0.0
        
        for i, (lat, lon) in enumerate(sample_points):
            result = await self.get_elevation(lat, lon)
            
            if i > 0:
                # 前の点からの距離を計算
                prev_lat, prev_lon = sample_points[i - 1]
                cumulative_distance += self._haversine_distance(
                    prev_lat, prev_lon, lat, lon
                )
            
            if result.success:
                profile_points.append(ElevationProfilePoint(
                    latitude=lat,
                    longitude=lon,
                    elevation=result.elevation,
                    distance_from_start=cumulative_distance
                ))
        
        # プロファイル統計を計算
        elevations = [p.elevation for p in profile_points]
        
        elevation_gain = 0.0
        elevation_loss = 0.0
        max_gradient = 0.0
        
        for i in range(1, len(profile_points)):
            elev_diff = profile_points[i].elevation - profile_points[i-1].elevation
            dist_diff = profile_points[i].distance_from_start - profile_points[i-1].distance_from_start
            
            if elev_diff > 0:
                elevation_gain += elev_diff
            else:
                elevation_loss += abs(elev_diff)
            
            if dist_diff > 0:
                gradient = abs(elev_diff / dist_diff) * 100
                max_gradient = max(max_gradient, gradient)
        
        is_wheelchair_accessible = max_gradient <= self.thresholds.WHEELCHAIR_MAX_GRADIENT
        
        return ElevationProfile(
            points=profile_points,
            total_distance=cumulative_distance,
            elevation_gain=elevation_gain,
            elevation_loss=elevation_loss,
            max_elevation=max(elevations) if elevations else 0.0,
            min_elevation=min(elevations) if elevations else 0.0,
            max_gradient=max_gradient,
            is_wheelchair_accessible=is_wheelchair_accessible
        )
    
    # -------------------------------------------------------------------------
    # 地図タイル
    # -------------------------------------------------------------------------
    
    def get_tile_url(
        self,
        layer: str,
        latitude: float,
        longitude: float,
        zoom: int = 15
    ) -> str:
        """
        指定地点の地図タイルURLを取得
        
        Args:
            layer: レイヤー名（std, relief, slopemap等）
            latitude: 緯度
            longitude: 経度
            zoom: ズームレベル（5-18）
        
        Returns:
            str: タイルURL
        """
        x, y = self._latlon_to_tile(latitude, longitude, zoom)
        return GSITileLayers.get_tile_url(layer, zoom, x, y)
    
    def get_disaster_related_tiles(
        self,
        latitude: float,
        longitude: float,
        zoom: int = 15
    ) -> Dict[str, str]:
        """
        災害関連の地図タイルURL一覧を取得
        
        避難支援に関連する複数レイヤーのタイルURLを返す
        
        Returns:
            Dict[str, str]: レイヤー名とURLのマッピング
        """
        x, y = self._latlon_to_tile(latitude, longitude, zoom)
        
        return {
            "standard": GSITileLayers.get_tile_url(GSITileLayers.STANDARD, zoom, x, y),
            "relief": GSITileLayers.get_tile_url(GSITileLayers.RELIEF, zoom, x, y),
            "hillshade": GSITileLayers.get_tile_url(GSITileLayers.HILLSHADE, zoom, x, y),
            "slope": GSITileLayers.get_tile_url(GSITileLayers.SLOPE, zoom, x, y),
            "flood_control": GSITileLayers.get_tile_url(GSITileLayers.FLOOD_CONTROL, zoom, x, y),
        }
    
    # -------------------------------------------------------------------------
    # ユーティリティメソッド
    # -------------------------------------------------------------------------
    
    def _latlon_to_tile(self, lat: float, lon: float, zoom: int) -> Tuple[int, int]:
        """緯度経度をタイル座標に変換"""
        import math
        n = 2 ** zoom
        x = int((lon + 180.0) / 360.0 * n)
        y = int((1.0 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2.0 * n)
        return x, y
    
    def _haversine_distance(
        self,
        lat1: float, lon1: float,
        lat2: float, lon2: float
    ) -> float:
        """2点間の距離を計算（メートル）"""
        import math
        R = 6371000  # 地球半径（メートル）
        
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lon2 - lon1)
        
        a = (math.sin(delta_phi / 2) ** 2 +
             math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        
        return R * c
    
    def _interpolate_route(
        self,
        coordinates: List[Tuple[float, float]],
        num_samples: int
    ) -> List[Tuple[float, float]]:
        """経路上の等間隔サンプル点を生成"""
        if len(coordinates) <= num_samples:
            return coordinates
        
        # 簡易的な線形補間
        result = []
        total_segments = len(coordinates) - 1
        for i in range(num_samples):
            t = i / (num_samples - 1) * total_segments
            seg_idx = min(int(t), total_segments - 1)
            local_t = t - seg_idx
            
            lat1, lon1 = coordinates[seg_idx]
            lat2, lon2 = coordinates[seg_idx + 1]
            
            lat = lat1 + (lat2 - lat1) * local_t
            lon = lon1 + (lon2 - lon1) * local_t
            result.append((lat, lon))
        
        return result


# =============================================================================
# Foundry IQ ツール定義用ラッパー
# =============================================================================

# シングルトンインスタンス
_client: Optional[GSIApiClient] = None

def get_client() -> GSIApiClient:
    """GSIApiClientのシングルトンインスタンスを取得"""
    global _client
    if _client is None:
        _client = GSIApiClient()
    return _client


# Foundry IQ / LangChain等のエージェントフレームワーク向けツール関数

async def get_elevation(latitude: float, longitude: float) -> Dict[str, Any]:
    """
    指定地点の標高を取得する
    
    この関数はFoundry IQのエージェントが避難経路の安全性を評価する際に使用します。
    標高情報から、浸水リスクや垂直避難の可能性を判断できます。
    
    Args:
        latitude: 緯度（例: 35.6812）
        longitude: 経度（例: 139.7671）
    
    Returns:
        dict: {
            "elevation": 標高（メートル）,
            "data_source": データソース,
            "success": 成功フラグ,
            "error": エラーメッセージ（あれば）
        }
    """
    client = get_client()
    result = await client.get_elevation(latitude, longitude)
    
    return {
        "elevation": result.elevation,
        "data_source": result.data_source,
        "success": result.success,
        "error": result.error_message
    }


async def get_elevation_profile(
    route_coordinates: List[Dict[str, float]],
    sample_count: int = 20
) -> Dict[str, Any]:
    """
    避難経路の標高プロファイルを取得する
    
    経路上の標高変化を分析し、車椅子対応可否や危険な急傾斜の有無を判定します。
    
    Args:
        route_coordinates: 経路座標リスト [{"lat": 緯度, "lon": 経度}, ...]
        sample_count: サンプリング点数（デフォルト: 20）
    
    Returns:
        dict: {
            "total_distance": 総距離（メートル）,
            "max_gradient": 最大勾配（%）,
            "is_wheelchair_accessible": 車椅子対応可否,
            "elevation_gain": 累積上昇（メートル）,
            "elevation_loss": 累積下降（メートル）,
            "max_elevation": 最高標高,
            "min_elevation": 最低標高,
            "profile_points": 標高プロファイル点リスト
        }
    """
    client = get_client()
    coords = [(p["lat"], p["lon"]) for p in route_coordinates]
    
    profile = await client.get_elevation_profile(coords, sample_count)
    
    return {
        "total_distance": profile.total_distance,
        "max_gradient": profile.max_gradient,
        "is_wheelchair_accessible": profile.is_wheelchair_accessible,
        "elevation_gain": profile.elevation_gain,
        "elevation_loss": profile.elevation_loss,
        "max_elevation": profile.max_elevation,
        "min_elevation": profile.min_elevation,
        "profile_points": [
            {
                "lat": p.latitude,
                "lon": p.longitude,
                "elevation": p.elevation,
                "distance": p.distance_from_start
            }
            for p in profile.points
        ]
    }


def get_disaster_map_tiles(
    latitude: float,
    longitude: float,
    zoom: int = 15
) -> Dict[str, str]:
    """
    指定地点の災害関連地図タイルURLを取得
    
    避難支援に必要な各種地図レイヤー（標高図、傾斜量図、治水地形分類図等）の
    タイルURLを一括で取得します。
    
    Args:
        latitude: 緯度
        longitude: 経度
        zoom: ズームレベル（5-18、デフォルト: 15）
    
    Returns:
        dict: レイヤー名とタイルURLのマッピング
    """
    client = get_client()
    return client.get_disaster_related_tiles(latitude, longitude, zoom)
