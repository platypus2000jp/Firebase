"""
災害リスク判定ツール

土砂災害警戒区域・浸水想定区域の判定機能を提供
避難支援Agentic RAGで使用
"""

import asyncio
import aiohttp
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from ..config import (
    MLITEndpoints,
    LandslideZoneCodes,
    EvacuationThresholds,
    RateLimitConfig,
    CacheConfig,
)
from .gsi_tools import CacheManager, RateLimiter

logger = logging.getLogger(__name__)


# =============================================================================
# 列挙型定義
# =============================================================================

class RiskLevel(Enum):
    """リスクレベル"""
    NONE = "none"           # リスクなし
    LOW = "low"             # 低リスク
    MEDIUM = "medium"       # 中リスク
    HIGH = "high"           # 高リスク
    CRITICAL = "critical"   # 危険


class DisasterType(Enum):
    """災害タイプ"""
    FLOOD = "flood"              # 洪水・浸水
    LANDSLIDE = "landslide"      # 土砂災害（総称）
    STEEP_SLOPE = "steep_slope"  # 急傾斜地の崩壊
    DEBRIS_FLOW = "debris_flow"  # 土石流
    LAND_SLIP = "land_slip"      # 地すべり


class LandslideZoneType(Enum):
    """土砂災害警戒区域タイプ"""
    YELLOW = "yellow"  # 土砂災害警戒区域（イエローゾーン）
    RED = "red"        # 土砂災害特別警戒区域（レッドゾーン）


# =============================================================================
# データクラス
# =============================================================================

@dataclass
class FloodRiskResult:
    """浸水リスク判定結果"""
    latitude: float
    longitude: float
    flood_depth: float              # 想定浸水深（メートル）
    risk_level: RiskLevel
    flood_duration_hours: Optional[float] = None  # 浸水継続時間
    river_name: Optional[str] = None              # 関連河川名
    scenario: Optional[str] = None                # 想定シナリオ（L1/L2等）
    success: bool = True
    error_message: Optional[str] = None
    
    @property
    def recommendation(self) -> str:
        """避難推奨アクションを返す"""
        if self.flood_depth >= EvacuationThresholds.FLOOD_DEPTH_CRITICAL:
            return "即時避難が必要です。3階以上または高台への避難を推奨します。"
        elif self.flood_depth >= EvacuationThresholds.FLOOD_DEPTH_HIGH:
            return "避難準備を開始してください。垂直避難（2階以上）も検討してください。"
        elif self.flood_depth >= EvacuationThresholds.FLOOD_DEPTH_MEDIUM:
            return "避難情報に注意してください。床上浸水の可能性があります。"
        elif self.flood_depth >= EvacuationThresholds.FLOOD_DEPTH_LOW:
            return "床下浸水の可能性があります。貴重品の上階移動を推奨します。"
        else:
            return "現時点でのリスクは低いですが、気象情報に注意してください。"


@dataclass
class LandslideZoneInfo:
    """土砂災害警戒区域情報"""
    zone_type: LandslideZoneType       # イエロー/レッド
    phenomenon_type: str               # 急傾斜地の崩壊/土石流/地すべり
    zone_name: str                     # 区域名
    location: str                      # 所在地
    prefecture_code: str               # 都道府県コード
    published_date: Optional[str] = None  # 公示日


@dataclass
class LandslideRiskResult:
    """土砂災害リスク判定結果"""
    latitude: float
    longitude: float
    is_in_hazard_zone: bool           # 警戒区域内か
    zones: List[LandslideZoneInfo] = field(default_factory=list)
    risk_level: RiskLevel = RiskLevel.NONE
    success: bool = True
    error_message: Optional[str] = None
    
    @property
    def recommendation(self) -> str:
        """避難推奨アクションを返す"""
        if not self.is_in_hazard_zone:
            return "土砂災害警戒区域外です。ただし、局所的な危険には注意してください。"
        
        has_red_zone = any(z.zone_type == LandslideZoneType.RED for z in self.zones)
        
        if has_red_zone:
            return "土砂災害特別警戒区域（レッドゾーン）内です。大雨時は早期避難が必須です。"
        else:
            return "土砂災害警戒区域（イエローゾーン）内です。大雨警報時は避難を検討してください。"


@dataclass
class ComprehensiveRiskResult:
    """総合リスク評価結果"""
    latitude: float
    longitude: float
    flood_risk: Optional[FloodRiskResult] = None
    landslide_risk: Optional[LandslideRiskResult] = None
    overall_risk_level: RiskLevel = RiskLevel.NONE
    primary_risk_type: Optional[DisasterType] = None
    evacuation_priority: int = 0  # 避難優先度（1が最高）
    
    @property
    def summary(self) -> str:
        """リスクサマリーを生成"""
        risks = []
        
        if self.flood_risk and self.flood_risk.flood_depth > 0:
            risks.append(f"浸水想定深: {self.flood_risk.flood_depth}m")
        
        if self.landslide_risk and self.landslide_risk.is_in_hazard_zone:
            zone_types = set(z.zone_type.value for z in self.landslide_risk.zones)
            risks.append(f"土砂災害警戒区域: {', '.join(zone_types)}")
        
        if not risks:
            return "この地点には顕著な災害リスクは確認されていません。"
        
        return "検出されたリスク: " + "; ".join(risks)


# =============================================================================
# 災害リスク判定クライアント
# =============================================================================

class HazardAssessmentClient:
    """災害リスク評価クライアント"""
    
    def __init__(self):
        self.cache = CacheManager()
        self.rate_limiter = RateLimiter()
        self.thresholds = EvacuationThresholds()
    
    # -------------------------------------------------------------------------
    # 浸水リスク判定
    # -------------------------------------------------------------------------
    
    async def check_flood_risk(
        self,
        latitude: float,
        longitude: float,
        scenario: str = "L2"  # L1: 計画規模, L2: 想定最大規模
    ) -> FloodRiskResult:
        """
        指定地点の浸水リスクを判定
        
        浸水ナビAPIまたは国土数値情報APIを使用して
        洪水浸水想定区域のデータを取得
        
        Args:
            latitude: 緯度
            longitude: 経度
            scenario: 想定シナリオ（L1: 計画規模, L2: 想定最大規模）
        
        Returns:
            FloodRiskResult: 浸水リスク判定結果
        """
        # レート制限適用
        await self.rate_limiter.acquire()
        
        try:
            # 国土数値情報 洪水浸水想定区域APIを呼び出し
            # 注: 実際のAPI仕様に合わせて実装を調整
            async with aiohttp.ClientSession() as session:
                # タイル座標を計算
                z = 14  # ズームレベル
                x, y = self._latlon_to_tile(latitude, longitude, z)
                
                params = {
                    "response_format": "geojson",
                    "z": z,
                    "x": x,
                    "y": y
                }
                
                async with session.get(
                    MLITEndpoints.FLOOD_ZONE_API,
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=15)
                ) as response:
                    if response.status != 200:
                        # APIが到達不能な場合はデモ値を返す
                        return self._create_demo_flood_result(latitude, longitude)
                    
                    data = await response.json()
                    return self._parse_flood_response(latitude, longitude, data)
                    
        except Exception as e:
            logger.warning(f"浸水リスクAPI呼び出しエラー: {e}")
            # デモモード: 実際のAPIが利用できない場合
            return self._create_demo_flood_result(latitude, longitude)
    
    def _create_demo_flood_result(
        self,
        latitude: float,
        longitude: float
    ) -> FloodRiskResult:
        """デモ用の浸水リスク結果を生成"""
        # 標高が低い地域をシミュレート
        # 実際の実装では標高APIと連携
        import random
        demo_depth = random.choice([0.0, 0.0, 0.5, 1.0, 2.0])
        
        return FloodRiskResult(
            latitude=latitude,
            longitude=longitude,
            flood_depth=demo_depth,
            risk_level=self._classify_flood_risk(demo_depth),
            scenario="L2（想定最大規模）- デモモード",
            success=True
        )
    
    def _parse_flood_response(
        self,
        latitude: float,
        longitude: float,
        data: Dict
    ) -> FloodRiskResult:
        """浸水APIレスポンスをパース"""
        # GeoJSONフォーマットの解析
        # 実際のAPI仕様に合わせて実装
        features = data.get("features", [])
        
        if not features:
            return FloodRiskResult(
                latitude=latitude,
                longitude=longitude,
                flood_depth=0.0,
                risk_level=RiskLevel.NONE,
                success=True
            )
        
        # 最大浸水深を取得
        max_depth = 0.0
        for feature in features:
            props = feature.get("properties", {})
            depth = props.get("flood_depth", 0.0)
            if depth > max_depth:
                max_depth = depth
        
        return FloodRiskResult(
            latitude=latitude,
            longitude=longitude,
            flood_depth=max_depth,
            risk_level=self._classify_flood_risk(max_depth),
            success=True
        )
    
    def _classify_flood_risk(self, depth: float) -> RiskLevel:
        """浸水深からリスクレベルを判定"""
        t = self.thresholds
        if depth >= t.FLOOD_DEPTH_CRITICAL:
            return RiskLevel.CRITICAL
        elif depth >= t.FLOOD_DEPTH_HIGH:
            return RiskLevel.HIGH
        elif depth >= t.FLOOD_DEPTH_MEDIUM:
            return RiskLevel.MEDIUM
        elif depth >= t.FLOOD_DEPTH_LOW:
            return RiskLevel.LOW
        else:
            return RiskLevel.NONE
    
    # -------------------------------------------------------------------------
    # 土砂災害警戒区域判定
    # -------------------------------------------------------------------------
    
    async def check_landslide_zone(
        self,
        latitude: float,
        longitude: float
    ) -> LandslideRiskResult:
        """
        指定地点が土砂災害警戒区域内かを判定
        
        国土数値情報 土砂災害警戒区域APIを使用
        
        Args:
            latitude: 緯度
            longitude: 経度
        
        Returns:
            LandslideRiskResult: 土砂災害リスク判定結果
        """
        await self.rate_limiter.acquire()
        
        try:
            async with aiohttp.ClientSession() as session:
                # タイル座標を計算
                z = 14
                x, y = self._latlon_to_tile(latitude, longitude, z)
                
                params = {
                    "response_format": "geojson",
                    "z": z,
                    "x": x,
                    "y": y
                }
                
                async with session.get(
                    MLITEndpoints.LANDSLIDE_ZONE_API,
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=15)
                ) as response:
                    if response.status != 200:
                        return self._create_demo_landslide_result(latitude, longitude)
                    
                    data = await response.json()
                    return self._parse_landslide_response(latitude, longitude, data)
                    
        except Exception as e:
            logger.warning(f"土砂災害警戒区域API呼び出しエラー: {e}")
            return self._create_demo_landslide_result(latitude, longitude)
    
    def _create_demo_landslide_result(
        self,
        latitude: float,
        longitude: float
    ) -> LandslideRiskResult:
        """デモ用の土砂災害リスク結果を生成"""
        import random
        
        # ランダムにリスクを生成（デモ用）
        is_in_zone = random.choice([False, False, True])
        
        if not is_in_zone:
            return LandslideRiskResult(
                latitude=latitude,
                longitude=longitude,
                is_in_hazard_zone=False,
                risk_level=RiskLevel.NONE,
                success=True
            )
        
        zone_type = random.choice([LandslideZoneType.YELLOW, LandslideZoneType.RED])
        phenomenon = random.choice(list(LandslideZoneCodes.PHENOMENON_TYPES.values()))
        
        return LandslideRiskResult(
            latitude=latitude,
            longitude=longitude,
            is_in_hazard_zone=True,
            zones=[
                LandslideZoneInfo(
                    zone_type=zone_type,
                    phenomenon_type=phenomenon,
                    zone_name="デモ区域",
                    location="デモ所在地",
                    prefecture_code="13"
                )
            ],
            risk_level=RiskLevel.HIGH if zone_type == LandslideZoneType.RED else RiskLevel.MEDIUM,
            success=True
        )
    
    def _parse_landslide_response(
        self,
        latitude: float,
        longitude: float,
        data: Dict
    ) -> LandslideRiskResult:
        """土砂災害警戒区域APIレスポンスをパース"""
        features = data.get("features", [])
        
        if not features:
            return LandslideRiskResult(
                latitude=latitude,
                longitude=longitude,
                is_in_hazard_zone=False,
                risk_level=RiskLevel.NONE,
                success=True
            )
        
        zones = []
        for feature in features:
            props = feature.get("properties", {})
            
            # 属性コードを解析
            phenomenon_code = props.get("A33_001", 1)
            zone_code = props.get("A33_002", 1)
            
            zone_type = LandslideZoneType.RED if zone_code == 2 else LandslideZoneType.YELLOW
            phenomenon = LandslideZoneCodes.PHENOMENON_TYPES.get(phenomenon_code, "不明")
            
            zones.append(LandslideZoneInfo(
                zone_type=zone_type,
                phenomenon_type=phenomenon,
                zone_name=props.get("A33_005", ""),
                location=props.get("A33_006", ""),
                prefecture_code=props.get("A33_003", ""),
                published_date=props.get("A33_007")
            ))
        
        # 最も危険度の高いゾーンでリスクレベルを決定
        has_red = any(z.zone_type == LandslideZoneType.RED for z in zones)
        
        return LandslideRiskResult(
            latitude=latitude,
            longitude=longitude,
            is_in_hazard_zone=True,
            zones=zones,
            risk_level=RiskLevel.HIGH if has_red else RiskLevel.MEDIUM,
            success=True
        )
    
    # -------------------------------------------------------------------------
    # 総合リスク評価
    # -------------------------------------------------------------------------
    
    async def evaluate_comprehensive_risk(
        self,
        latitude: float,
        longitude: float
    ) -> ComprehensiveRiskResult:
        """
        指定地点の総合災害リスクを評価
        
        浸水リスクと土砂災害リスクを統合して評価
        
        Args:
            latitude: 緯度
            longitude: 経度
        
        Returns:
            ComprehensiveRiskResult: 総合リスク評価結果
        """
        # 並行してリスク評価を実行
        flood_task = self.check_flood_risk(latitude, longitude)
        landslide_task = self.check_landslide_zone(latitude, longitude)
        
        flood_result, landslide_result = await asyncio.gather(
            flood_task, landslide_task
        )
        
        # 総合リスクレベルを決定
        risk_levels = [
            flood_result.risk_level if flood_result.success else RiskLevel.NONE,
            landslide_result.risk_level if landslide_result.success else RiskLevel.NONE
        ]
        
        # 最も高いリスクレベルを採用
        level_order = [RiskLevel.NONE, RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.CRITICAL]
        overall_level = max(risk_levels, key=lambda x: level_order.index(x))
        
        # 主要なリスクタイプを特定
        primary_type = None
        if flood_result.risk_level == overall_level and flood_result.flood_depth > 0:
            primary_type = DisasterType.FLOOD
        elif landslide_result.risk_level == overall_level and landslide_result.is_in_hazard_zone:
            primary_type = DisasterType.LANDSLIDE
        
        # 避難優先度を設定
        priority = {
            RiskLevel.CRITICAL: 1,
            RiskLevel.HIGH: 2,
            RiskLevel.MEDIUM: 3,
            RiskLevel.LOW: 4,
            RiskLevel.NONE: 5
        }.get(overall_level, 5)
        
        return ComprehensiveRiskResult(
            latitude=latitude,
            longitude=longitude,
            flood_risk=flood_result,
            landslide_risk=landslide_result,
            overall_risk_level=overall_level,
            primary_risk_type=primary_type,
            evacuation_priority=priority
        )
    
    # -------------------------------------------------------------------------
    # 経路安全性評価
    # -------------------------------------------------------------------------
    
    async def evaluate_route_safety(
        self,
        route_coordinates: List[Tuple[float, float]],
        sample_interval: int = 5
    ) -> Dict[str, Any]:
        """
        避難経路の安全性を評価
        
        経路上の各地点で浸水・土砂災害リスクをチェックし、
        危険箇所を特定
        
        Args:
            route_coordinates: 経路座標リスト [(lat, lon), ...]
            sample_interval: サンプリング間隔（何点ごとにチェックするか）
        
        Returns:
            dict: 経路安全性評価結果
        """
        # サンプル点を選択
        sample_points = route_coordinates[::sample_interval]
        if route_coordinates[-1] not in sample_points:
            sample_points.append(route_coordinates[-1])
        
        # 各点のリスクを評価
        hazard_points = []
        safe_points = []
        
        for lat, lon in sample_points:
            risk = await self.evaluate_comprehensive_risk(lat, lon)
            
            point_info = {
                "lat": lat,
                "lon": lon,
                "risk_level": risk.overall_risk_level.value,
                "summary": risk.summary
            }
            
            if risk.overall_risk_level in [RiskLevel.HIGH, RiskLevel.CRITICAL]:
                hazard_points.append(point_info)
            else:
                safe_points.append(point_info)
        
        is_route_safe = len(hazard_points) == 0
        
        return {
            "is_safe": is_route_safe,
            "total_points_checked": len(sample_points),
            "hazard_points": hazard_points,
            "hazard_count": len(hazard_points),
            "recommendation": (
                "この経路は安全と判定されました。"
                if is_route_safe else
                f"経路上に{len(hazard_points)}箇所の危険地点があります。代替ルートを検討してください。"
            )
        }
    
    # -------------------------------------------------------------------------
    # ユーティリティ
    # -------------------------------------------------------------------------
    
    def _latlon_to_tile(self, lat: float, lon: float, zoom: int) -> Tuple[int, int]:
        """緯度経度をタイル座標に変換"""
        import math
        n = 2 ** zoom
        x = int((lon + 180.0) / 360.0 * n)
        y = int((1.0 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2.0 * n)
        return x, y


# =============================================================================
# Foundry IQ ツール定義用ラッパー
# =============================================================================

_hazard_client: Optional[HazardAssessmentClient] = None

def get_hazard_client() -> HazardAssessmentClient:
    """HazardAssessmentClientのシングルトンインスタンスを取得"""
    global _hazard_client
    if _hazard_client is None:
        _hazard_client = HazardAssessmentClient()
    return _hazard_client


async def check_flood_risk(
    latitude: float,
    longitude: float,
    scenario: str = "L2"
) -> Dict[str, Any]:
    """
    指定地点の浸水リスクを判定する
    
    洪水浸水想定区域データに基づき、想定浸水深とリスクレベルを返します。
    避難判断の基礎情報として使用します。
    
    Args:
        latitude: 緯度（例: 35.6812）
        longitude: 経度（例: 139.7671）
        scenario: 想定シナリオ（"L1": 計画規模, "L2": 想定最大規模）
    
    Returns:
        dict: {
            "flood_depth": 想定浸水深（メートル）,
            "risk_level": リスクレベル,
            "recommendation": 避難推奨アクション,
            "success": 成功フラグ
        }
    """
    client = get_hazard_client()
    result = await client.check_flood_risk(latitude, longitude, scenario)
    
    return {
        "flood_depth": result.flood_depth,
        "risk_level": result.risk_level.value,
        "recommendation": result.recommendation,
        "river_name": result.river_name,
        "scenario": result.scenario,
        "success": result.success,
        "error": result.error_message
    }


async def check_landslide_zone(
    latitude: float,
    longitude: float
) -> Dict[str, Any]:
    """
    指定地点が土砂災害警戒区域内かを判定する
    
    土砂災害警戒区域（イエローゾーン）および
    土砂災害特別警戒区域（レッドゾーン）を判定します。
    
    Args:
        latitude: 緯度
        longitude: 経度
    
    Returns:
        dict: {
            "is_in_hazard_zone": 警戒区域内フラグ,
            "zone_types": 区域タイプリスト,
            "risk_level": リスクレベル,
            "recommendation": 避難推奨アクション,
            "zones": 区域詳細情報リスト
        }
    """
    client = get_hazard_client()
    result = await client.check_landslide_zone(latitude, longitude)
    
    return {
        "is_in_hazard_zone": result.is_in_hazard_zone,
        "zone_types": [z.zone_type.value for z in result.zones],
        "phenomenon_types": [z.phenomenon_type for z in result.zones],
        "risk_level": result.risk_level.value,
        "recommendation": result.recommendation,
        "zones": [
            {
                "type": z.zone_type.value,
                "phenomenon": z.phenomenon_type,
                "name": z.zone_name,
                "location": z.location
            }
            for z in result.zones
        ],
        "success": result.success,
        "error": result.error_message
    }


async def check_comprehensive_risk(
    latitude: float,
    longitude: float
) -> Dict[str, Any]:
    """
    指定地点の総合災害リスクを評価する
    
    浸水リスクと土砂災害リスクを統合し、総合的なリスク評価を行います。
    避難の優先度判断に使用します。
    
    Args:
        latitude: 緯度
        longitude: 経度
    
    Returns:
        dict: {
            "overall_risk_level": 総合リスクレベル,
            "primary_risk_type": 主要リスクタイプ,
            "evacuation_priority": 避難優先度（1が最高）,
            "summary": リスクサマリー,
            "flood_risk": 浸水リスク詳細,
            "landslide_risk": 土砂災害リスク詳細
        }
    """
    client = get_hazard_client()
    result = await client.evaluate_comprehensive_risk(latitude, longitude)
    
    return {
        "overall_risk_level": result.overall_risk_level.value,
        "primary_risk_type": result.primary_risk_type.value if result.primary_risk_type else None,
        "evacuation_priority": result.evacuation_priority,
        "summary": result.summary,
        "flood_risk": {
            "depth": result.flood_risk.flood_depth if result.flood_risk else 0,
            "level": result.flood_risk.risk_level.value if result.flood_risk else "none"
        },
        "landslide_risk": {
            "in_zone": result.landslide_risk.is_in_hazard_zone if result.landslide_risk else False,
            "level": result.landslide_risk.risk_level.value if result.landslide_risk else "none"
        }
    }


async def evaluate_route_safety(
    route_coordinates: List[Dict[str, float]]
) -> Dict[str, Any]:
    """
    避難経路の安全性を評価する
    
    経路上の危険箇所を特定し、安全な避難が可能かを判定します。
    
    Args:
        route_coordinates: 経路座標リスト [{"lat": 緯度, "lon": 経度}, ...]
    
    Returns:
        dict: {
            "is_safe": 安全フラグ,
            "hazard_count": 危険箇所数,
            "hazard_points": 危険地点リスト,
            "recommendation": 推奨アクション
        }
    """
    client = get_hazard_client()
    coords = [(p["lat"], p["lon"]) for p in route_coordinates]
    
    return await client.evaluate_route_safety(coords)
