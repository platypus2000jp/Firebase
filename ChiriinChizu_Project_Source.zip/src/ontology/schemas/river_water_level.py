"""
河川水位 Ontology スキーマ定義

Palantir Foundry Ontology用の河川水位オブジェクト定義
"""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional


class WaterLevelStatus(Enum):
    """水位状況"""
    NORMAL = "normal"                    # 平常
    ATTENTION = "attention"              # 水防団待機水位
    WARNING = "warning"                  # 氾濫注意水位
    DANGER = "danger"                    # 避難判断水位
    CRITICAL = "critical"                # 氾濫危険水位
    OVERFLOW = "overflow"                # 氾濫発生


@dataclass
class RiverWaterLevelSchema:
    """
    河川水位 Ontology オブジェクト スキーマ
    
    Foundry Ontologyの「RiverWaterLevel」オブジェクトタイプに対応
    国土交通省 川の防災情報等との連携を想定
    
    Attributes:
        station_id: 観測所ID（主キー）
        station_name: 観測所名
        river_name: 河川名
        river_system: 水系名
        latitude: 観測所緯度
        longitude: 観測所経度
        current_level: 現在水位（メートル）
        standby_level: 水防団待機水位
        attention_level: 氾濫注意水位
        warning_level: 避難判断水位
        danger_level: 氾濫危険水位
        levee_height: 堤防高
        status: 水位状況
        trend: 水位傾向（上昇/横ばい/下降）
        last_updated: 最終更新日時
    """
    
    # 主キー
    station_id: str
    
    # 観測所情報
    station_name: str
    river_name: str
    river_system: Optional[str] = None
    
    # 位置情報
    latitude: float = 0.0
    longitude: float = 0.0
    prefecture: Optional[str] = None
    municipality: Optional[str] = None
    
    # 水位データ（メートル）
    current_level: float = 0.0
    
    # 基準水位（メートル）
    standby_level: Optional[float] = None      # 水防団待機水位
    attention_level: Optional[float] = None    # 氾濫注意水位
    warning_level: Optional[float] = None      # 避難判断水位
    danger_level: Optional[float] = None       # 氾濫危険水位
    levee_height: Optional[float] = None       # 堤防高
    
    # 状態
    status: WaterLevelStatus = WaterLevelStatus.NORMAL
    trend: str = "stable"  # rising, stable, falling
    
    # メタデータ
    last_updated: Optional[datetime] = None
    data_source: str = "国土交通省 川の防災情報"
    
    @property
    def is_dangerous(self) -> bool:
        """危険水位を超えているか"""
        if self.danger_level and self.current_level >= self.danger_level:
            return True
        return self.status in [WaterLevelStatus.DANGER, WaterLevelStatus.CRITICAL, WaterLevelStatus.OVERFLOW]
    
    @property
    def requires_attention(self) -> bool:
        """注意が必要か"""
        if self.attention_level and self.current_level >= self.attention_level:
            return True
        return self.status != WaterLevelStatus.NORMAL
    
    @property
    def margin_to_danger(self) -> Optional[float]:
        """危険水位までの余裕（メートル）"""
        if self.danger_level:
            return self.danger_level - self.current_level
        return None
    
    @property
    def level_percentage(self) -> Optional[float]:
        """堤防高に対する水位の割合（%）"""
        if self.levee_height and self.levee_height > 0:
            return (self.current_level / self.levee_height) * 100
        return None
    
    def determine_status(self) -> WaterLevelStatus:
        """現在水位から状態を判定"""
        if self.levee_height and self.current_level >= self.levee_height:
            return WaterLevelStatus.OVERFLOW
        if self.danger_level and self.current_level >= self.danger_level:
            return WaterLevelStatus.CRITICAL
        if self.warning_level and self.current_level >= self.warning_level:
            return WaterLevelStatus.DANGER
        if self.attention_level and self.current_level >= self.attention_level:
            return WaterLevelStatus.WARNING
        if self.standby_level and self.current_level >= self.standby_level:
            return WaterLevelStatus.ATTENTION
        return WaterLevelStatus.NORMAL
    
    def to_foundry_object(self) -> dict:
        """Foundry Ontologyオブジェクト形式に変換"""
        return {
            "primaryKey": self.station_id,
            "properties": {
                "station_name": self.station_name,
                "river_name": self.river_name,
                "river_system": self.river_system,
                "latitude": self.latitude,
                "longitude": self.longitude,
                "prefecture": self.prefecture,
                "municipality": self.municipality,
                "current_level": self.current_level,
                "standby_level": self.standby_level,
                "attention_level": self.attention_level,
                "warning_level": self.warning_level,
                "danger_level": self.danger_level,
                "levee_height": self.levee_height,
                "status": self.status.value,
                "trend": self.trend,
                "last_updated": self.last_updated.isoformat() if self.last_updated else None,
                "data_source": self.data_source,
            }
        }
    
    @classmethod
    def from_foundry_object(cls, obj: dict) -> "RiverWaterLevelSchema":
        """Foundry Ontologyオブジェクトからインスタンスを生成"""
        props = obj.get("properties", {})
        
        return cls(
            station_id=obj.get("primaryKey", ""),
            station_name=props.get("station_name", ""),
            river_name=props.get("river_name", ""),
            river_system=props.get("river_system"),
            latitude=props.get("latitude", 0.0),
            longitude=props.get("longitude", 0.0),
            prefecture=props.get("prefecture"),
            municipality=props.get("municipality"),
            current_level=props.get("current_level", 0.0),
            standby_level=props.get("standby_level"),
            attention_level=props.get("attention_level"),
            warning_level=props.get("warning_level"),
            danger_level=props.get("danger_level"),
            levee_height=props.get("levee_height"),
            status=WaterLevelStatus(props.get("status", "normal")),
            trend=props.get("trend", "stable"),
            last_updated=datetime.fromisoformat(props["last_updated"]) if props.get("last_updated") else None,
            data_source=props.get("data_source", ""),
        )


# =============================================================================
# Foundry Ontology 型定義（OSDK生成用参考）
# =============================================================================

RIVER_WATER_LEVEL_OBJECT_TYPE = {
    "apiName": "RiverWaterLevel",
    "displayName": "河川水位",
    "description": "河川の水位観測データ",
    "primaryKeyPropertyApiName": "station_id",
    "properties": [
        {"apiName": "station_id", "dataType": "string", "description": "観測所ID（主キー）"},
        {"apiName": "station_name", "dataType": "string", "description": "観測所名"},
        {"apiName": "river_name", "dataType": "string", "description": "河川名"},
        {"apiName": "river_system", "dataType": "string", "description": "水系名"},
        {"apiName": "latitude", "dataType": "double", "description": "緯度"},
        {"apiName": "longitude", "dataType": "double", "description": "経度"},
        {"apiName": "prefecture", "dataType": "string", "description": "都道府県"},
        {"apiName": "municipality", "dataType": "string", "description": "市区町村"},
        {"apiName": "current_level", "dataType": "double", "description": "現在水位（メートル）"},
        {"apiName": "standby_level", "dataType": "double", "description": "水防団待機水位"},
        {"apiName": "attention_level", "dataType": "double", "description": "氾濫注意水位"},
        {"apiName": "warning_level", "dataType": "double", "description": "避難判断水位"},
        {"apiName": "danger_level", "dataType": "double", "description": "氾濫危険水位"},
        {"apiName": "levee_height", "dataType": "double", "description": "堤防高"},
        {"apiName": "status", "dataType": "string", "description": "水位状況"},
        {"apiName": "trend", "dataType": "string", "description": "水位傾向"},
        {"apiName": "last_updated", "dataType": "timestamp", "description": "最終更新日時"},
        {"apiName": "data_source", "dataType": "string", "description": "データソース"},
    ]
}
