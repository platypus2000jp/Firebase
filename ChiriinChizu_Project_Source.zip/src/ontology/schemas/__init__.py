"""
Ontology スキーマパッケージ

Foundry Ontology オブジェクトタイプの定義
"""

from .evacuation_shelter import (
    EvacuationShelterSchema,
    ShelterType,
    OpenStatus,
    Facility,
    EVACUATION_SHELTER_OBJECT_TYPE,
)

from .disaster_event import (
    DisasterEventSchema,
    DisasterType,
    Severity,
    AlertLevel,
    GeoShape,
    DISASTER_EVENT_OBJECT_TYPE,
)

from .river_water_level import (
    RiverWaterLevelSchema,
    WaterLevelStatus,
    RIVER_WATER_LEVEL_OBJECT_TYPE,
)


__all__ = [
    # 避難所
    "EvacuationShelterSchema",
    "ShelterType",
    "OpenStatus",
    "Facility",
    "EVACUATION_SHELTER_OBJECT_TYPE",
    
    # 災害イベント
    "DisasterEventSchema",
    "DisasterType",
    "Severity",
    "AlertLevel",
    "GeoShape",
    "DISASTER_EVENT_OBJECT_TYPE",
    
    # 河川水位
    "RiverWaterLevelSchema",
    "WaterLevelStatus",
    "RIVER_WATER_LEVEL_OBJECT_TYPE",
]
