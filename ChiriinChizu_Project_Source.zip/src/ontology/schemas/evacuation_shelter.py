"""
避難所 Ontology スキーマ定義

Palantir Foundry Ontology用の避難所オブジェクト定義
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional


class ShelterType(Enum):
    """避難所種別"""
    DESIGNATED = "designated"           # 指定避難所
    WELFARE = "welfare"                 # 福祉避難所
    TEMPORARY = "temporary"             # 一時避難所
    WIDE_AREA = "wide_area"            # 広域避難場所
    TSUNAMI = "tsunami"                 # 津波避難ビル
    VERTICAL = "vertical"               # 垂直避難施設


class OpenStatus(Enum):
    """開設状況"""
    OPEN = "open"           # 開設中
    CLOSED = "closed"       # 閉鎖中
    PREPARING = "preparing" # 準備中
    FULL = "full"           # 満員


class Facility(Enum):
    """避難所設備"""
    WHEELCHAIR_ACCESS = "wheelchair_access"
    TOILET = "toilet"
    ACCESSIBLE_TOILET = "accessible_toilet"
    SHOWER = "shower"
    COOKING = "cooking"
    GENERATOR = "generator"
    COMMUNICATION = "communication"
    MEDICAL = "medical"
    PET_FRIENDLY = "pet_friendly"
    NURSERY = "nursery"


@dataclass
class EvacuationShelterSchema:
    """
    避難所 Ontology オブジェクト スキーマ
    
    Foundry Ontologyの「EvacuationShelter」オブジェクトタイプに対応
    
    Attributes:
        shelter_id: 主キー（Foundry Object RID）
        name: 避難所名
        address: 住所
        latitude: 緯度（WGS84）
        longitude: 経度（WGS84）
        elevation: 標高（メートル）
        shelter_type: 避難所種別
        capacity: 収容人数
        current_occupancy: 現在利用者数
        open_status: 開設状況
        floor_count: 階数
        facilities: 設備リスト
        target_disasters: 対象災害リスト
        contact_phone: 連絡先電話番号
        municipality_code: 自治体コード（JIS X 0402）
        last_updated: 最終更新日時
    """
    
    # 主キー
    shelter_id: str
    
    # 基本情報
    name: str
    address: str
    
    # 位置情報
    latitude: float
    longitude: float
    elevation: float = 0.0
    
    # 種別・設備
    shelter_type: ShelterType = ShelterType.DESIGNATED
    floor_count: int = 1
    facilities: List[Facility] = field(default_factory=list)
    
    # 収容情報
    capacity: int = 0
    current_occupancy: int = 0
    open_status: OpenStatus = OpenStatus.CLOSED
    
    # 対象災害
    target_disasters: List[str] = field(default_factory=list)
    
    # 連絡先・管理情報
    contact_phone: Optional[str] = None
    municipality_code: Optional[str] = None
    notes: Optional[str] = None
    
    # メタデータ
    last_updated: Optional[datetime] = None
    
    @property
    def available_capacity(self) -> int:
        """残り収容可能人数"""
        return max(0, self.capacity - self.current_occupancy)
    
    @property
    def occupancy_rate(self) -> float:
        """収容率（%）"""
        if self.capacity == 0:
            return 100.0
        return (self.current_occupancy / self.capacity) * 100
    
    @property
    def is_wheelchair_accessible(self) -> bool:
        """車椅子対応かどうか"""
        return Facility.WHEELCHAIR_ACCESS in self.facilities
    
    @property
    def is_available(self) -> bool:
        """利用可能かどうか"""
        return (
            self.open_status == OpenStatus.OPEN and
            self.available_capacity > 0
        )
    
    def to_foundry_object(self) -> dict:
        """Foundry Ontologyオブジェクト形式に変換"""
        return {
            "primaryKey": self.shelter_id,
            "properties": {
                "name": self.name,
                "address": self.address,
                "latitude": self.latitude,
                "longitude": self.longitude,
                "elevation": self.elevation,
                "shelter_type": self.shelter_type.value,
                "floor_count": self.floor_count,
                "facilities": [f.value for f in self.facilities],
                "capacity": self.capacity,
                "current_occupancy": self.current_occupancy,
                "open_status": self.open_status.value,
                "target_disasters": self.target_disasters,
                "contact_phone": self.contact_phone,
                "municipality_code": self.municipality_code,
                "notes": self.notes,
                "last_updated": self.last_updated.isoformat() if self.last_updated else None
            }
        }
    
    @classmethod
    def from_foundry_object(cls, obj: dict) -> "EvacuationShelterSchema":
        """Foundry Ontologyオブジェクトからインスタンスを生成"""
        props = obj.get("properties", {})
        
        return cls(
            shelter_id=obj.get("primaryKey", ""),
            name=props.get("name", ""),
            address=props.get("address", ""),
            latitude=props.get("latitude", 0.0),
            longitude=props.get("longitude", 0.0),
            elevation=props.get("elevation", 0.0),
            shelter_type=ShelterType(props.get("shelter_type", "designated")),
            floor_count=props.get("floor_count", 1),
            facilities=[Facility(f) for f in props.get("facilities", [])],
            capacity=props.get("capacity", 0),
            current_occupancy=props.get("current_occupancy", 0),
            open_status=OpenStatus(props.get("open_status", "closed")),
            target_disasters=props.get("target_disasters", []),
            contact_phone=props.get("contact_phone"),
            municipality_code=props.get("municipality_code"),
            notes=props.get("notes"),
            last_updated=datetime.fromisoformat(props["last_updated"]) if props.get("last_updated") else None
        )


# =============================================================================
# Foundry Ontology 型定義（OSDK生成用参考）
# =============================================================================

EVACUATION_SHELTER_OBJECT_TYPE = {
    "apiName": "EvacuationShelter",
    "displayName": "避難所",
    "description": "災害時に住民が避難する施設",
    "primaryKeyPropertyApiName": "shelter_id",
    "properties": [
        {"apiName": "shelter_id", "dataType": "string", "description": "避難所ID（主キー）"},
        {"apiName": "name", "dataType": "string", "description": "避難所名"},
        {"apiName": "address", "dataType": "string", "description": "住所"},
        {"apiName": "latitude", "dataType": "double", "description": "緯度"},
        {"apiName": "longitude", "dataType": "double", "description": "経度"},
        {"apiName": "elevation", "dataType": "double", "description": "標高（メートル）"},
        {"apiName": "shelter_type", "dataType": "string", "description": "避難所種別"},
        {"apiName": "floor_count", "dataType": "integer", "description": "階数"},
        {"apiName": "facilities", "dataType": "string[]", "description": "設備リスト"},
        {"apiName": "capacity", "dataType": "integer", "description": "収容人数"},
        {"apiName": "current_occupancy", "dataType": "integer", "description": "現在利用者数"},
        {"apiName": "open_status", "dataType": "string", "description": "開設状況"},
        {"apiName": "target_disasters", "dataType": "string[]", "description": "対象災害"},
        {"apiName": "contact_phone", "dataType": "string", "description": "連絡先電話番号"},
        {"apiName": "municipality_code", "dataType": "string", "description": "自治体コード"},
        {"apiName": "notes", "dataType": "string", "description": "備考"},
        {"apiName": "last_updated", "dataType": "timestamp", "description": "最終更新日時"},
    ]
}
