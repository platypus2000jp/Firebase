"""
災害イベント Ontology スキーマ定義

Palantir Foundry Ontology用の災害イベントオブジェクト定義
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional, Tuple


class DisasterType(Enum):
    """災害種別"""
    FLOOD = "flood"                  # 洪水
    HEAVY_RAIN = "heavy_rain"       # 大雨
    LANDSLIDE = "landslide"          # 土砂災害
    EARTHQUAKE = "earthquake"        # 地震
    TSUNAMI = "tsunami"              # 津波
    TYPHOON = "typhoon"              # 台風
    STORM_SURGE = "storm_surge"      # 高潮
    VOLCANIC = "volcanic"            # 火山
    FIRE = "fire"                    # 火災
    OTHER = "other"                  # その他


class Severity(Enum):
    """深刻度レベル"""
    ADVISORY = "advisory"            # 注意（注意報）
    WARNING = "warning"              # 警戒（警報）
    EMERGENCY = "emergency"          # 特別警報
    CRITICAL = "critical"            # 緊急事態


class AlertLevel(Enum):
    """警戒レベル（内閣府5段階）"""
    LEVEL_1 = "level_1"  # 早期注意情報
    LEVEL_2 = "level_2"  # 大雨・洪水注意報
    LEVEL_3 = "level_3"  # 高齢者等避難
    LEVEL_4 = "level_4"  # 避難指示
    LEVEL_5 = "level_5"  # 緊急安全確保


@dataclass
class GeoShape:
    """地理的形状（ポリゴン）
    
    Foundry Ontologyの GeoShape 型に対応
    """
    type: str = "Polygon"  # Polygon, MultiPolygon, etc.
    coordinates: List[List[Tuple[float, float]]] = field(default_factory=list)
    
    def to_geojson(self) -> dict:
        """GeoJSON形式に変換"""
        return {
            "type": self.type,
            "coordinates": self.coordinates
        }
    
    @classmethod
    def from_geojson(cls, geojson: dict) -> "GeoShape":
        """GeoJSONからインスタンスを生成"""
        return cls(
            type=geojson.get("type", "Polygon"),
            coordinates=geojson.get("coordinates", [])
        )
    
    @classmethod
    def from_bbox(cls, min_lat: float, min_lon: float, max_lat: float, max_lon: float) -> "GeoShape":
        """バウンディングボックスからポリゴンを生成"""
        return cls(
            type="Polygon",
            coordinates=[[[min_lon, min_lat], [max_lon, min_lat], 
                         [max_lon, max_lat], [min_lon, max_lat], 
                         [min_lon, min_lat]]]
        )


@dataclass
class DisasterEventSchema:
    """
    災害イベント Ontology オブジェクト スキーマ
    
    Foundry Ontologyの「DisasterEvent」オブジェクトタイプに対応
    
    Attributes:
        event_id: 主キー
        disaster_type: 災害種別
        severity: 深刻度
        alert_level: 警戒レベル
        affected_area: 影響範囲（GeoShape）
        affected_municipalities: 影響自治体コードリスト
        start_time: 発生日時
        end_time: 終息日時
        description: 詳細説明
        source: 情報源（気象庁、自治体等）
        is_active: 発生中フラグ
    """
    
    # 主キー
    event_id: str
    
    # 災害情報
    disaster_type: DisasterType
    severity: Severity = Severity.ADVISORY
    alert_level: Optional[AlertLevel] = None
    
    # 影響範囲
    affected_area: Optional[GeoShape] = None
    affected_municipalities: List[str] = field(default_factory=list)
    
    # 期間
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    
    # 詳細
    title: str = ""
    description: str = ""
    source: str = ""
    source_url: Optional[str] = None
    
    # 状態
    is_active: bool = True
    
    # メタデータ
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    @property
    def is_ongoing(self) -> bool:
        """現在進行中かどうか"""
        if not self.is_active:
            return False
        if self.end_time and datetime.now() > self.end_time:
            return False
        return True
    
    @property
    def requires_evacuation(self) -> bool:
        """避難が必要かどうか"""
        if self.alert_level:
            return self.alert_level in [AlertLevel.LEVEL_3, AlertLevel.LEVEL_4, AlertLevel.LEVEL_5]
        return self.severity in [Severity.WARNING, Severity.EMERGENCY, Severity.CRITICAL]
    
    def to_foundry_object(self) -> dict:
        """Foundry Ontologyオブジェクト形式に変換"""
        return {
            "primaryKey": self.event_id,
            "properties": {
                "disaster_type": self.disaster_type.value,
                "severity": self.severity.value,
                "alert_level": self.alert_level.value if self.alert_level else None,
                "affected_area": self.affected_area.to_geojson() if self.affected_area else None,
                "affected_municipalities": self.affected_municipalities,
                "start_time": self.start_time.isoformat() if self.start_time else None,
                "end_time": self.end_time.isoformat() if self.end_time else None,
                "title": self.title,
                "description": self.description,
                "source": self.source,
                "source_url": self.source_url,
                "is_active": self.is_active,
                "created_at": self.created_at.isoformat() if self.created_at else None,
                "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            }
        }
    
    @classmethod
    def from_foundry_object(cls, obj: dict) -> "DisasterEventSchema":
        """Foundry Ontologyオブジェクトからインスタンスを生成"""
        props = obj.get("properties", {})
        
        return cls(
            event_id=obj.get("primaryKey", ""),
            disaster_type=DisasterType(props.get("disaster_type", "other")),
            severity=Severity(props.get("severity", "advisory")),
            alert_level=AlertLevel(props["alert_level"]) if props.get("alert_level") else None,
            affected_area=GeoShape.from_geojson(props["affected_area"]) if props.get("affected_area") else None,
            affected_municipalities=props.get("affected_municipalities", []),
            start_time=datetime.fromisoformat(props["start_time"]) if props.get("start_time") else None,
            end_time=datetime.fromisoformat(props["end_time"]) if props.get("end_time") else None,
            title=props.get("title", ""),
            description=props.get("description", ""),
            source=props.get("source", ""),
            source_url=props.get("source_url"),
            is_active=props.get("is_active", True),
            created_at=datetime.fromisoformat(props["created_at"]) if props.get("created_at") else None,
            updated_at=datetime.fromisoformat(props["updated_at"]) if props.get("updated_at") else None,
        )


# =============================================================================
# Foundry Ontology 型定義（OSDK生成用参考）
# =============================================================================

DISASTER_EVENT_OBJECT_TYPE = {
    "apiName": "DisasterEvent",
    "displayName": "災害イベント",
    "description": "発生中または過去の災害イベント情報",
    "primaryKeyPropertyApiName": "event_id",
    "properties": [
        {"apiName": "event_id", "dataType": "string", "description": "イベントID（主キー）"},
        {"apiName": "disaster_type", "dataType": "string", "description": "災害種別"},
        {"apiName": "severity", "dataType": "string", "description": "深刻度"},
        {"apiName": "alert_level", "dataType": "string", "description": "警戒レベル"},
        {"apiName": "affected_area", "dataType": "geoShape", "description": "影響範囲"},
        {"apiName": "affected_municipalities", "dataType": "string[]", "description": "影響自治体コード"},
        {"apiName": "start_time", "dataType": "timestamp", "description": "発生日時"},
        {"apiName": "end_time", "dataType": "timestamp", "description": "終息日時"},
        {"apiName": "title", "dataType": "string", "description": "タイトル"},
        {"apiName": "description", "dataType": "string", "description": "詳細説明"},
        {"apiName": "source", "dataType": "string", "description": "情報源"},
        {"apiName": "source_url", "dataType": "string", "description": "情報源URL"},
        {"apiName": "is_active", "dataType": "boolean", "description": "発生中フラグ"},
        {"apiName": "created_at", "dataType": "timestamp", "description": "作成日時"},
        {"apiName": "updated_at", "dataType": "timestamp", "description": "更新日時"},
    ]
}
