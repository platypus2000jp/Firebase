"""
Foundry Ontology クライアント

Palantir Foundry OSDKを使用したOntologyへのアクセス
"""

import asyncio
import logging
import os
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from abc import ABC, abstractmethod

from .schemas import (
    EvacuationShelterSchema,
    DisasterEventSchema,
    RiverWaterLevelSchema,
    ShelterType,
    OpenStatus,
    DisasterType,
    Severity,
)

logger = logging.getLogger(__name__)


# =============================================================================
# 設定
# =============================================================================

@dataclass
class FoundryConfig:
    """Foundry接続設定"""
    
    url: str = ""
    client_id: str = ""
    client_secret: str = ""
    ontology_rid: str = ""
    
    @classmethod
    def from_env(cls) -> "FoundryConfig":
        """環境変数から設定を読み込み"""
        return cls(
            url=os.getenv("FOUNDRY_URL", ""),
            client_id=os.getenv("FOUNDRY_CLIENT_ID", ""),
            client_secret=os.getenv("FOUNDRY_CLIENT_SECRET", ""),
            ontology_rid=os.getenv("ONTOLOGY_RID", ""),
        )
    
    @property
    def is_configured(self) -> bool:
        """設定が完了しているか"""
        return bool(self.url and self.client_id and self.client_secret)


# =============================================================================
# 抽象クライアント
# =============================================================================

class OntologyClientBase(ABC):
    """Ontologyクライアント 抽象基底クラス"""
    
    @abstractmethod
    async def get_shelters_in_area(
        self,
        min_lat: float,
        min_lon: float,
        max_lat: float,
        max_lon: float,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[EvacuationShelterSchema]:
        """指定エリア内の避難所を取得"""
        pass
    
    @abstractmethod
    async def get_shelter_by_id(self, shelter_id: str) -> Optional[EvacuationShelterSchema]:
        """IDで避難所を取得"""
        pass
    
    @abstractmethod
    async def update_shelter_status(
        self,
        shelter_id: str,
        open_status: OpenStatus,
        current_occupancy: Optional[int] = None
    ) -> bool:
        """避難所の状態を更新"""
        pass
    
    @abstractmethod
    async def get_active_disasters(
        self,
        disaster_types: Optional[List[DisasterType]] = None
    ) -> List[DisasterEventSchema]:
        """発生中の災害イベントを取得"""
        pass
    
    @abstractmethod
    async def get_river_levels(
        self,
        station_ids: Optional[List[str]] = None,
        only_dangerous: bool = False
    ) -> List[RiverWaterLevelSchema]:
        """河川水位データを取得"""
        pass


# =============================================================================
# デモ実装（Foundry未接続時用）
# =============================================================================

class DemoOntologyClient(OntologyClientBase):
    """
    デモ用 Ontology クライアント
    
    Foundry環境がない場合のローカルテスト用
    """
    
    def __init__(self):
        self._shelters = self._create_demo_shelters()
        self._disasters = self._create_demo_disasters()
        self._river_levels = self._create_demo_river_levels()
    
    def _create_demo_shelters(self) -> List[EvacuationShelterSchema]:
        """デモ用避難所データを生成"""
        from .schemas import Facility
        
        return [
            EvacuationShelterSchema(
                shelter_id="shelter_001",
                name="中央小学校",
                address="東京都足立区中央本町1-1-1",
                latitude=35.7756,
                longitude=139.8042,
                elevation=3.5,
                shelter_type=ShelterType.DESIGNATED,
                capacity=500,
                current_occupancy=0,
                open_status=OpenStatus.CLOSED,
                floor_count=3,
                facilities=[Facility.WHEELCHAIR_ACCESS, Facility.TOILET, Facility.ACCESSIBLE_TOILET],
                target_disasters=["洪水", "地震"],
                municipality_code="13121",
                last_updated=datetime.now(),
            ),
            EvacuationShelterSchema(
                shelter_id="shelter_002",
                name="北部市民センター",
                address="東京都足立区北部2-2-2",
                latitude=35.7856,
                longitude=139.7942,
                elevation=5.2,
                shelter_type=ShelterType.DESIGNATED,
                capacity=300,
                current_occupancy=50,
                open_status=OpenStatus.OPEN,
                floor_count=5,
                facilities=[Facility.WHEELCHAIR_ACCESS, Facility.TOILET, Facility.GENERATOR],
                target_disasters=["洪水", "地震", "土砂"],
                municipality_code="13121",
                last_updated=datetime.now(),
            ),
            EvacuationShelterSchema(
                shelter_id="shelter_003",
                name="高台公園",
                address="東京都足立区高台町3-3-3",
                latitude=35.7900,
                longitude=139.8100,
                elevation=12.0,
                shelter_type=ShelterType.WIDE_AREA,
                capacity=2000,
                current_occupancy=0,
                open_status=OpenStatus.CLOSED,
                floor_count=1,
                facilities=[Facility.TOILET],
                target_disasters=["地震", "火災"],
                municipality_code="13121",
                last_updated=datetime.now(),
            ),
            EvacuationShelterSchema(
                shelter_id="shelter_004",
                name="南部福祉センター",
                address="東京都足立区南部4-4-4",
                latitude=35.7650,
                longitude=139.8150,
                elevation=4.0,
                shelter_type=ShelterType.WELFARE,
                capacity=100,
                current_occupancy=20,
                open_status=OpenStatus.OPEN,
                floor_count=2,
                facilities=[Facility.WHEELCHAIR_ACCESS, Facility.MEDICAL, Facility.NURSERY],
                target_disasters=["洪水", "地震"],
                municipality_code="13121",
                last_updated=datetime.now(),
            ),
        ]
    
    def _create_demo_disasters(self) -> List[DisasterEventSchema]:
        """デモ用災害イベントデータを生成"""
        from .schemas import AlertLevel, GeoShape
        
        return [
            DisasterEventSchema(
                event_id="disaster_001",
                disaster_type=DisasterType.HEAVY_RAIN,
                severity=Severity.WARNING,
                alert_level=AlertLevel.LEVEL_3,
                title="大雨警報（足立区）",
                description="足立区全域に大雨警報が発令されています。高齢者等は避難を開始してください。",
                affected_municipalities=["13121"],
                affected_area=GeoShape.from_bbox(35.75, 139.78, 35.82, 139.85),
                start_time=datetime.now(),
                is_active=True,
                source="気象庁",
                created_at=datetime.now(),
            ),
        ]
    
    def _create_demo_river_levels(self) -> List[RiverWaterLevelSchema]:
        """デモ用河川水位データを生成"""
        from .schemas import WaterLevelStatus
        
        return [
            RiverWaterLevelSchema(
                station_id="river_001",
                station_name="荒川 岩淵水門",
                river_name="荒川",
                river_system="荒川水系",
                latitude=35.7850,
                longitude=139.7200,
                prefecture="東京都",
                municipality="北区",
                current_level=4.5,
                standby_level=3.0,
                attention_level=5.0,
                warning_level=6.5,
                danger_level=7.5,
                levee_height=10.0,
                status=WaterLevelStatus.ATTENTION,
                trend="rising",
                last_updated=datetime.now(),
            ),
            RiverWaterLevelSchema(
                station_id="river_002",
                station_name="中川 平井大橋",
                river_name="中川",
                river_system="利根川水系",
                latitude=35.7100,
                longitude=139.8400,
                prefecture="東京都",
                municipality="江戸川区",
                current_level=2.8,
                standby_level=3.0,
                attention_level=4.0,
                warning_level=5.0,
                danger_level=6.0,
                levee_height=8.0,
                status=WaterLevelStatus.NORMAL,
                trend="stable",
                last_updated=datetime.now(),
            ),
        ]
    
    async def get_shelters_in_area(
        self,
        min_lat: float,
        min_lon: float,
        max_lat: float,
        max_lon: float,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[EvacuationShelterSchema]:
        """指定エリア内の避難所を取得"""
        result = []
        
        for shelter in self._shelters:
            # 範囲内チェック
            if not (min_lat <= shelter.latitude <= max_lat and
                    min_lon <= shelter.longitude <= max_lon):
                continue
            
            # フィルター適用
            if filters:
                if filters.get("require_open") and shelter.open_status != OpenStatus.OPEN:
                    continue
                if filters.get("require_wheelchair") and not shelter.is_wheelchair_accessible:
                    continue
                if filters.get("min_elevation") and shelter.elevation < filters["min_elevation"]:
                    continue
                if filters.get("shelter_type") and shelter.shelter_type.value != filters["shelter_type"]:
                    continue
            
            result.append(shelter)
        
        return result
    
    async def get_shelter_by_id(self, shelter_id: str) -> Optional[EvacuationShelterSchema]:
        """IDで避難所を取得"""
        for shelter in self._shelters:
            if shelter.shelter_id == shelter_id:
                return shelter
        return None
    
    async def update_shelter_status(
        self,
        shelter_id: str,
        open_status: OpenStatus,
        current_occupancy: Optional[int] = None
    ) -> bool:
        """避難所の状態を更新"""
        for shelter in self._shelters:
            if shelter.shelter_id == shelter_id:
                shelter.open_status = open_status
                if current_occupancy is not None:
                    shelter.current_occupancy = current_occupancy
                shelter.last_updated = datetime.now()
                logger.info(f"避難所更新: {shelter_id} -> {open_status.value}")
                return True
        return False
    
    async def get_active_disasters(
        self,
        disaster_types: Optional[List[DisasterType]] = None
    ) -> List[DisasterEventSchema]:
        """発生中の災害イベントを取得"""
        result = []
        
        for disaster in self._disasters:
            if not disaster.is_active:
                continue
            if disaster_types and disaster.disaster_type not in disaster_types:
                continue
            result.append(disaster)
        
        return result
    
    async def get_river_levels(
        self,
        station_ids: Optional[List[str]] = None,
        only_dangerous: bool = False
    ) -> List[RiverWaterLevelSchema]:
        """河川水位データを取得"""
        result = []
        
        for river in self._river_levels:
            if station_ids and river.station_id not in station_ids:
                continue
            if only_dangerous and not river.is_dangerous:
                continue
            result.append(river)
        
        return result


# =============================================================================
# Foundry OSDK 実装（実接続用）
# =============================================================================

class FoundryOSDKClient(OntologyClientBase):
    """
    Palantir Foundry OSDK クライアント
    
    実際のFoundry環境への接続用
    OSDK生成コードと組み合わせて使用
    """
    
    def __init__(self, config: FoundryConfig):
        self.config = config
        self._client = None
        self._ontology = None
    
    async def connect(self) -> bool:
        """Foundryに接続"""
        if not self.config.is_configured:
            logger.warning("Foundry設定が不完全です")
            return False
        
        try:
            # 注: 実際のOSDKはPalantirから生成されるクライアントを使用
            # from foundry_osdk import FoundryClient
            # self._client = FoundryClient(
            #     hostname=self.config.url,
            #     auth=ConfidentialClientAuth(
            #         client_id=self.config.client_id,
            #         client_secret=self.config.client_secret,
            #     )
            # )
            # self._ontology = self._client.ontology(self.config.ontology_rid)
            
            logger.info(f"Foundry接続成功: {self.config.url}")
            return True
            
        except Exception as e:
            logger.error(f"Foundry接続エラー: {e}")
            return False
    
    async def get_shelters_in_area(
        self,
        min_lat: float,
        min_lon: float,
        max_lat: float,
        max_lon: float,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[EvacuationShelterSchema]:
        """指定エリア内の避難所を取得"""
        # 実際のOSDK実装例:
        # shelters = await self._ontology.objects.EvacuationShelter.where(
        #     (EvacuationShelter.latitude >= min_lat) &
        #     (EvacuationShelter.latitude <= max_lat) &
        #     (EvacuationShelter.longitude >= min_lon) &
        #     (EvacuationShelter.longitude <= max_lon)
        # ).all()
        
        logger.warning("Foundry OSDK未接続: デモモードにフォールバック")
        demo_client = DemoOntologyClient()
        return await demo_client.get_shelters_in_area(min_lat, min_lon, max_lat, max_lon, filters)
    
    async def get_shelter_by_id(self, shelter_id: str) -> Optional[EvacuationShelterSchema]:
        """IDで避難所を取得"""
        # 実際のOSDK実装例:
        # return await self._ontology.objects.EvacuationShelter.get(shelter_id)
        
        demo_client = DemoOntologyClient()
        return await demo_client.get_shelter_by_id(shelter_id)
    
    async def update_shelter_status(
        self,
        shelter_id: str,
        open_status: OpenStatus,
        current_occupancy: Optional[int] = None
    ) -> bool:
        """避難所の状態を更新"""
        # 実際のOSDK実装例（Actionを使用）:
        # await self._ontology.actions.updateShelterStatus(
        #     shelter_id=shelter_id,
        #     open_status=open_status.value,
        #     current_occupancy=current_occupancy
        # )
        
        demo_client = DemoOntologyClient()
        return await demo_client.update_shelter_status(shelter_id, open_status, current_occupancy)
    
    async def get_active_disasters(
        self,
        disaster_types: Optional[List[DisasterType]] = None
    ) -> List[DisasterEventSchema]:
        """発生中の災害イベントを取得"""
        # 実際のOSDK実装例:
        # return await self._ontology.objects.DisasterEvent.where(
        #     DisasterEvent.is_active == True
        # ).all()
        
        demo_client = DemoOntologyClient()
        return await demo_client.get_active_disasters(disaster_types)
    
    async def get_river_levels(
        self,
        station_ids: Optional[List[str]] = None,
        only_dangerous: bool = False
    ) -> List[RiverWaterLevelSchema]:
        """河川水位データを取得"""
        demo_client = DemoOntologyClient()
        return await demo_client.get_river_levels(station_ids, only_dangerous)


# =============================================================================
# クライアントファクトリ
# =============================================================================

_ontology_client: Optional[OntologyClientBase] = None

def get_ontology_client() -> OntologyClientBase:
    """Ontologyクライアントを取得
    
    環境変数の設定に応じてFoundry実接続またはデモモードを返す
    """
    global _ontology_client
    
    if _ontology_client is None:
        config = FoundryConfig.from_env()
        
        if config.is_configured:
            logger.info("Foundry OSDK クライアントを初期化")
            _ontology_client = FoundryOSDKClient(config)
        else:
            logger.info("デモモードで起動（Foundry未設定）")
            _ontology_client = DemoOntologyClient()
    
    return _ontology_client


def set_ontology_client(client: OntologyClientBase) -> None:
    """Ontologyクライアントを設定（テスト用）"""
    global _ontology_client
    _ontology_client = client
