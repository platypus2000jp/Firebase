"""
Ontology パッケージ

Palantir Foundry Ontologyとの連携
"""

from .foundry_client import (
    FoundryConfig,
    OntologyClientBase,
    DemoOntologyClient,
    FoundryOSDKClient,
    get_ontology_client,
    set_ontology_client,
)

from .schemas import (
    # 避難所
    EvacuationShelterSchema,
    ShelterType,
    OpenStatus,
    Facility,
    
    # 災害イベント
    DisasterEventSchema,
    DisasterType,
    Severity,
    AlertLevel,
    GeoShape,
    
    # 河川水位
    RiverWaterLevelSchema,
    WaterLevelStatus,
)


__all__ = [
    # クライアント
    "FoundryConfig",
    "OntologyClientBase",
    "DemoOntologyClient",
    "FoundryOSDKClient",
    "get_ontology_client",
    "set_ontology_client",
    
    # 避難所スキーマ
    "EvacuationShelterSchema",
    "ShelterType",
    "OpenStatus",
    "Facility",
    
    # 災害イベントスキーマ
    "DisasterEventSchema",
    "DisasterType",
    "Severity",
    "AlertLevel",
    "GeoShape",
    
    # 河川水位スキーマ
    "RiverWaterLevelSchema",
    "WaterLevelStatus",
]
