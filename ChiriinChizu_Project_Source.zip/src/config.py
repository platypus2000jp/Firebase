"""
地理院地図API × Foundry IQ Agentic RAG - 設定ファイル

API エンドポイント、レート制限、キャッシュ設定を管理
"""

from dataclasses import dataclass
from typing import Dict
import os

# =============================================================================
# 国土地理院 API エンドポイント
# =============================================================================

class GSIEndpoints:
    """国土地理院API エンドポイント定義"""
    
    # 標高API
    ELEVATION_API = "https://cyberjapandata2.gsi.go.jp/general/dem/scripts/getelevation.php"
    
    # 地理院タイル ベースURL
    TILE_BASE_URL = "https://cyberjapandata.gsi.go.jp/xyz"
    
    # 浸水ナビAPI（国土地理院）
    SHINSUINAVI_API = "https://suiboumap.gsi.go.jp"


class GSITileLayers:
    """地理院タイル レイヤー定義（避難支援関連）"""
    
    # ベースマップ
    STANDARD = "std"           # 標準地図
    PALE = "pale"              # 淡色地図
    BLANK = "blank"            # 白地図
    
    # 航空写真
    PHOTO = "seamlessphoto"    # 電子国土基本図（オルソ画像）
    
    # 地形・標高関連
    RELIEF = "relief"                    # 色別標高図
    HILLSHADE = "hillshademap"           # 陰影起伏図
    SLOPE = "slopemap"                   # 傾斜量図
    SLOPE_AVALANCHE = "slopezone1map"    # 全国傾斜量区分図（雪崩関連）
    
    # 災害・防災関連
    FLOOD_CONTROL = "lcmfc2"   # 治水地形分類図
    SWALE = "swale"            # 明治期の低湿地
    ACTIVE_FAULT = "afm"       # 活断層図
    
    @classmethod
    def get_tile_url(cls, layer: str, z: int, x: int, y: int) -> str:
        """タイルURLを生成"""
        return f"{GSIEndpoints.TILE_BASE_URL}/{layer}/{z}/{x}/{y}.png"
    
    @classmethod
    def get_available_layers(cls) -> Dict[str, str]:
        """利用可能なレイヤー一覧を取得"""
        return {
            "standard": cls.STANDARD,
            "pale": cls.PALE,
            "photo": cls.PHOTO,
            "relief": cls.RELIEF,
            "hillshade": cls.HILLSHADE,
            "slope": cls.SLOPE,
            "flood_control": cls.FLOOD_CONTROL,
        }


# =============================================================================
# 国土交通省 API エンドポイント
# =============================================================================

class MLITEndpoints:
    """国土交通省 不動産情報ライブラリ API エンドポイント"""
    
    # 土砂災害警戒区域
    LANDSLIDE_ZONE_API = "https://www.reinfolib.mlit.go.jp/ex-api/external/XKT029"
    
    # 洪水浸水想定区域
    FLOOD_ZONE_API = "https://www.reinfolib.mlit.go.jp/ex-api/external/XKT030"


# =============================================================================
# 土砂災害警戒区域 属性コード
# =============================================================================

class LandslideZoneCodes:
    """土砂災害警戒区域の属性コード定義"""
    
    # 現象の種類 (A33_001)
    PHENOMENON_TYPES = {
        1: "急傾斜地の崩壊",
        2: "土石流",
        3: "地すべり"
    }
    
    # 区域区分 (A33_002)
    ZONE_TYPES = {
        1: "土砂災害警戒区域（イエローゾーン）",
        2: "土砂災害特別警戒区域（レッドゾーン）"
    }


# =============================================================================
# API レート制限設定
# =============================================================================

@dataclass
class RateLimitConfig:
    """API呼び出しレート制限設定
    
    地理院地図APIの利用規約に準拠:
    - 1秒に1回程度のアクセスを推奨
    - 過度なアクセスは遮断される可能性あり
    """
    
    # リクエスト間隔（秒）
    MIN_REQUEST_INTERVAL: float = 1.0
    
    # バッチリクエスト時の最大同時リクエスト数
    MAX_CONCURRENT_REQUESTS: int = 5
    
    # リトライ設定
    MAX_RETRIES: int = 3
    RETRY_DELAY: float = 2.0


# =============================================================================
# キャッシュ設定
# =============================================================================

@dataclass
class CacheConfig:
    """APIレスポンス キャッシュ設定"""
    
    # キャッシュ有効化
    ENABLED: bool = True
    
    # キャッシュディレクトリ
    CACHE_DIR: str = ".cache/gsi_api"
    
    # 標高データのキャッシュ有効期限（秒）- 変更頻度が低いため長め
    ELEVATION_TTL: int = 86400 * 30  # 30日
    
    # タイルデータのキャッシュ有効期限（秒）
    TILE_TTL: int = 86400 * 7  # 7日
    
    # 災害警戒区域データのキャッシュ有効期限（秒）
    HAZARD_ZONE_TTL: int = 86400  # 1日


# =============================================================================
# 座標系設定
# =============================================================================

class CoordinateSystem:
    """座標系・測地系設定"""
    
    # 測地系
    EPSG_WGS84 = 4326    # 世界測地系（GPS）
    EPSG_JGD2011 = 6668  # 日本測地系2011
    
    # デフォルト
    DEFAULT_CRS = EPSG_WGS84


# =============================================================================
# 避難基準設定
# =============================================================================

@dataclass
class EvacuationThresholds:
    """避難判断の閾値設定"""
    
    # 浸水深の危険度レベル（メートル）
    FLOOD_DEPTH_LOW: float = 0.5      # 床下浸水
    FLOOD_DEPTH_MEDIUM: float = 1.0   # 床上浸水
    FLOOD_DEPTH_HIGH: float = 2.0     # 1階天井まで
    FLOOD_DEPTH_CRITICAL: float = 5.0 # 2階以上まで
    
    # 傾斜角の危険度レベル（度）
    SLOPE_STEEP: float = 30.0         # 急傾斜
    
    # 経路の勾配制限（%）- 車椅子対応
    WHEELCHAIR_MAX_GRADIENT: float = 5.0
    
    # 標高差の安全マージン（メートル）
    ELEVATION_SAFETY_MARGIN: float = 5.0


# =============================================================================
# ログ設定
# =============================================================================

class LogConfig:
    """ログ設定"""
    
    # ログレベル
    LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    # ログフォーマット
    FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
