"""
Foundry IQ エージェント定義

ツールのFunction Calling形式定義とReActワークフロー
"""

from typing import Any, Dict, List

# =============================================================================
# ツール定義（OpenAI Function Calling / Foundry IQ 互換形式）
# =============================================================================

EVACUATION_AGENT_TOOLS: List[Dict[str, Any]] = [
    # -------------------------------------------------------------------------
    # 標高・地形ツール
    # -------------------------------------------------------------------------
    {
        "name": "get_elevation",
        "description": """指定地点の標高（海抜）を取得します。
        
用途:
- 浸水リスクの判断（低地の特定）
- 避難所の安全性評価（高台かどうか）
- 垂直避難の必要性判断

標高値はメートル単位で返されます。""",
        "parameters": {
            "type": "object",
            "properties": {
                "latitude": {
                    "type": "number",
                    "description": "緯度（例: 35.6812）"
                },
                "longitude": {
                    "type": "number",
                    "description": "経度（例: 139.7671）"
                }
            },
            "required": ["latitude", "longitude"]
        }
    },
    {
        "name": "get_elevation_profile",
        "description": """避難経路上の標高プロファイルを取得します。
        
用途:
- 経路の勾配確認（急な坂の有無）
- 車椅子対応ルートの判定（勾配5%以下）
- 経路上の冠水リスク地点の特定（低地部分）

経路全体の標高変化、最大勾配、累積上昇/下降を分析します。""",
        "parameters": {
            "type": "object",
            "properties": {
                "route_coordinates": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "lat": {"type": "number"},
                            "lon": {"type": "number"}
                        },
                        "required": ["lat", "lon"]
                    },
                    "description": "経路座標のリスト"
                },
                "sample_count": {
                    "type": "integer",
                    "description": "サンプリング点数（デフォルト: 20）",
                    "default": 20
                }
            },
            "required": ["route_coordinates"]
        }
    },
    
    # -------------------------------------------------------------------------
    # 災害リスク判定ツール
    # -------------------------------------------------------------------------
    {
        "name": "check_flood_risk",
        "description": """指定地点の浸水リスクを判定します。
        
洪水浸水想定区域のデータに基づき、想定浸水深を取得します。

浸水深の目安:
- 0.5m未満: 床下浸水の可能性
- 0.5-1.0m: 床上浸水
- 1.0-2.0m: 1階天井まで
- 2.0-5.0m: 2階まで
- 5.0m以上: 3階以上まで

シナリオはL1（計画規模）またはL2（想定最大規模）を指定できます。""",
        "parameters": {
            "type": "object",
            "properties": {
                "latitude": {
                    "type": "number",
                    "description": "緯度"
                },
                "longitude": {
                    "type": "number",
                    "description": "経度"
                },
                "scenario": {
                    "type": "string",
                    "enum": ["L1", "L2"],
                    "description": "想定シナリオ（L1: 計画規模, L2: 想定最大規模）",
                    "default": "L2"
                }
            },
            "required": ["latitude", "longitude"]
        }
    },
    {
        "name": "check_landslide_zone",
        "description": """指定地点が土砂災害警戒区域内かを判定します。
        
土砂災害防止法に基づく警戒区域を確認します:
- イエローゾーン（土砂災害警戒区域）: 警戒避難体制の整備が必要
- レッドゾーン（土砂災害特別警戒区域）: 一定の開発行為が制限される

現象の種類:
- 急傾斜地の崩壊（がけ崩れ）
- 土石流
- 地すべり""",
        "parameters": {
            "type": "object",
            "properties": {
                "latitude": {
                    "type": "number",
                    "description": "緯度"
                },
                "longitude": {
                    "type": "number",
                    "description": "経度"
                }
            },
            "required": ["latitude", "longitude"]
        }
    },
    {
        "name": "check_comprehensive_risk",
        "description": """指定地点の総合災害リスクを評価します。
        
浸水リスクと土砂災害リスクを統合的に評価し、
総合的なリスクレベルと主要なリスクタイプを判定します。

避難の優先度（1が最高、5が最低）も出力します。""",
        "parameters": {
            "type": "object",
            "properties": {
                "latitude": {
                    "type": "number",
                    "description": "緯度"
                },
                "longitude": {
                    "type": "number",
                    "description": "経度"
                }
            },
            "required": ["latitude", "longitude"]
        }
    },
    {
        "name": "evaluate_route_safety",
        "description": """避難経路の安全性を評価します。
        
経路上の各地点で災害リスクをチェックし、
危険箇所を特定します。

冠水の恐れがある低地、土砂災害警戒区域を通過する
箇所があれば警告します。""",
        "parameters": {
            "type": "object",
            "properties": {
                "route_coordinates": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "lat": {"type": "number"},
                            "lon": {"type": "number"}
                        },
                        "required": ["lat", "lon"]
                    },
                    "description": "経路座標のリスト"
                }
            },
            "required": ["route_coordinates"]
        }
    },
    
    # -------------------------------------------------------------------------
    # 避難所ツール
    # -------------------------------------------------------------------------
    {
        "name": "find_nearby_shelters",
        "description": """周辺の避難所を検索します。
        
指定地点から一定距離内にある避難所をリストアップします。
距離順にソートされた結果を返します。""",
        "parameters": {
            "type": "object",
            "properties": {
                "latitude": {
                    "type": "number",
                    "description": "緯度"
                },
                "longitude": {
                    "type": "number",
                    "description": "経度"
                },
                "radius_km": {
                    "type": "number",
                    "description": "検索半径（km）",
                    "default": 2.0
                }
            },
            "required": ["latitude", "longitude"]
        }
    },
    {
        "name": "find_accessible_shelters",
        "description": """条件に合致する避難所を検索します。
        
以下の条件でフィルタリングできます:
- 車椅子対応（バリアフリー）
- 最低標高（浸水回避）
- 対象災害タイプ（洪水、土砂、地震等）

開設中で利用可能な避難所のみを返します。""",
        "parameters": {
            "type": "object",
            "properties": {
                "latitude": {
                    "type": "number",
                    "description": "緯度"
                },
                "longitude": {
                    "type": "number",
                    "description": "経度"
                },
                "min_elevation": {
                    "type": "number",
                    "description": "最低標高（メートル）"
                },
                "require_wheelchair": {
                    "type": "boolean",
                    "description": "車椅子対応必須",
                    "default": False
                },
                "target_disaster": {
                    "type": "string",
                    "description": "対象災害（洪水、土砂、地震等）"
                }
            },
            "required": ["latitude", "longitude"]
        }
    },
    {
        "name": "recommend_shelter",
        "description": """最適な避難所を推奨します。
        
ユーザーの状況（車椅子、高齢者、ペット、浸水リスク等）を
考慮し、最適な避難所を優先度順にリストアップします。

各避難所について適合スコアと推奨理由を提示します。""",
        "parameters": {
            "type": "object",
            "properties": {
                "latitude": {
                    "type": "number",
                    "description": "現在地の緯度"
                },
                "longitude": {
                    "type": "number",
                    "description": "現在地の経度"
                },
                "wheelchair": {
                    "type": "boolean",
                    "description": "車椅子使用者がいる",
                    "default": False
                },
                "elderly": {
                    "type": "boolean",
                    "description": "高齢者が同伴",
                    "default": False
                },
                "pets": {
                    "type": "boolean",
                    "description": "ペットを連れている",
                    "default": False
                },
                "flood_risk": {
                    "type": "boolean",
                    "description": "浸水リスクを回避したい",
                    "default": False
                }
            },
            "required": ["latitude", "longitude"]
        }
    },
    {
        "name": "get_shelter_status",
        "description": """避難所の現在の状態を取得します。
        
リアルタイムの開設状況、収容状況を確認します。
混雑度や残り収容人数を把握できます。""",
        "parameters": {
            "type": "object",
            "properties": {
                "shelter_id": {
                    "type": "string",
                    "description": "避難所ID"
                }
            },
            "required": ["shelter_id"]
        }
    },
    
    # -------------------------------------------------------------------------
    # 地図タイルツール
    # -------------------------------------------------------------------------
    {
        "name": "get_disaster_map_tiles",
        "description": """災害関連の地図タイルURLを取得します。
        
以下の地図レイヤーURLを一括で取得できます:
- 標準地図（ベースマップ）
- 色別標高図（標高の可視化）
- 陰影起伏図（地形の把握）
- 傾斜量図（土砂災害リスクの可視化）
- 治水地形分類図（浸水リスクの把握）

これらのURLは地図表示UIで使用します。""",
        "parameters": {
            "type": "object",
            "properties": {
                "latitude": {
                    "type": "number",
                    "description": "緯度"
                },
                "longitude": {
                    "type": "number",
                    "description": "経度"
                },
                "zoom": {
                    "type": "integer",
                    "description": "ズームレベル（5-18）",
                    "default": 15
                }
            },
            "required": ["latitude", "longitude"]
        }
    }
]


# =============================================================================
# エージェント システムプロンプト
# =============================================================================

EVACUATION_AGENT_SYSTEM_PROMPT = """あなたは「避難支援エージェント」です。
国土地理院の地理空間データとFoundry IQの避難所情報を活用して、
ユーザーの避難判断を支援します。

# 役割
- 災害リスク（浸水・土砂災害）の評価
- 最適な避難所の提案
- 安全な避難経路の検討
- 車椅子・高齢者・ペット等への配慮

# 行動指針
1. **安全最優先**: 常に最も安全な選択肢を提案する
2. **根拠の明示**: 判断の根拠（標高、警戒区域、距離等）を説明する
3. **複数選択肢**: 可能な場合は代替案も提示する
4. **リアルタイム性**: 避難所の開設状況を確認する

# 思考プロセス（ReAct）
1. Thought: ユーザーの状況と必要な情報を整理
2. Action: 適切なツールを選択して実行
3. Observation: ツールの結果を確認
4. (繰り返し)
5. Answer: 総合的な避難提案を行う

# 応答形式
- 結論を最初に述べる
- 重要な数値（標高、距離、浸水深等）を明記
- 具体的なアクションを提示
- 注意事項や制約を追記

# 制約
- 医療的な判断は行わない
- 天候の急変等には対応できない旨を伝える
- 最終判断はユーザーに委ねる
"""


# =============================================================================
# ReAct ワークフロー例
# =============================================================================

EXAMPLE_REACT_WORKFLOW = """
## ユーザー入力例
「現在地（緯度35.78, 経度139.80）から、車椅子で移動可能な避難所を探してください。浸水が心配です。」

## エージェントの思考プロセス

### Thought 1
ユーザーは車椅子使用者であり、浸水リスクを心配している。
まず現在地の浸水リスクを確認し、その後車椅子対応の避難所を探す必要がある。

### Action 1
check_comprehensive_risk(latitude=35.78, longitude=139.80)

### Observation 1
{
    "overall_risk_level": "medium",
    "flood_risk": {"depth": 1.5, "level": "high"},
    "landslide_risk": {"in_zone": false, "level": "none"}
}

### Thought 2
浸水リスクが高い（想定浸水深1.5m）。車椅子対応で高台にある避難所を探す必要がある。
現在地の標高も確認して、どの程度の標高が安全か判断する。

### Action 2
get_elevation(latitude=35.78, longitude=139.80)

### Observation 2
{"elevation": 3.2, "success": true}

### Thought 3
現在地の標高は3.2m。想定浸水深1.5mを考慮すると、少なくとも5m以上の標高がある
避難所を探すべき。車椅子対応も必須条件として検索する。

### Action 3
recommend_shelter(latitude=35.78, longitude=139.80, wheelchair=true, flood_risk=true)

### Observation 3
{
    "top_recommendation": {
        "name": "北部市民センター",
        "address": "東京都足立区北部2-2-2",
        "walking_time": "約15分",
        "why": "車椅子対応あり, 高台（標高5.2m）, 開設中"
    }
}

### Answer
**推奨避難所: 北部市民センター**

現在地の状況を分析した結果、以下をお勧めします：

📍 **北部市民センター**（東京都足立区北部2-2-2）
- 徒歩約15分
- 標高5.2m（現在地より約2m高い）
- 車椅子対応あり
- 現在開設中、収容余裕あり

⚠️ **注意事項**
- 現在地は想定浸水深1.5mのエリアです
- 早めの避難を推奨します
- 移動時は低地（アンダーパス等）を避けてください
"""
