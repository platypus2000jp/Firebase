"""
AIP Agent 設定

Palantir AIP Agent Studioとの統合設定
"""

from typing import Any, Dict, List

# =============================================================================
# AIP Agent 基本設定
# =============================================================================

AIP_AGENT_CONFIG: Dict[str, Any] = {
    "agent_name": "避難支援エージェント",
    "agent_description": """
        国土地理院の地理空間データとFoundry Ontologyの避難所情報を活用し、
        災害時の避難判断を支援するAIエージェント。
        
        主な機能:
        - 災害リスク（浸水・土砂災害）の評価
        - 最適な避難所の提案
        - 安全な避難経路の検討
        - リアルタイム情報（水位、開設状況）の統合
    """,
    
    # 使用するOntologyオブジェクト
    "ontology_objects": [
        "EvacuationShelter",   # 避難所
        "DisasterEvent",       # 災害イベント
        "RiverWaterLevel",     # 河川水位
        "EvacuationAlert",     # 避難指示（将来実装）
    ],
    
    # 外部APIツール（地理院地図等）
    "external_tools": [
        "get_elevation",
        "get_elevation_profile",
        "check_flood_risk",
        "check_landslide_zone",
        "check_comprehensive_risk",
        "evaluate_route_safety",
        "get_disaster_map_tiles",
    ],
    
    # Ontology操作ツール
    "ontology_tools": [
        "find_shelters_in_area",
        "get_shelter_status",
        "update_shelter_status",
        "get_active_disasters",
        "get_river_levels",
    ],
    
    # エージェント設定
    "settings": {
        "max_iterations": 10,           # 最大思考ステップ数
        "temperature": 0.2,             # 生成温度（低めで安定した応答）
        "enable_function_calling": True,
        "enable_streaming": True,
    }
}


# =============================================================================
# Ontology ツール定義（AIP Agent Studio用）
# =============================================================================

ONTOLOGY_TOOL_DEFINITIONS: List[Dict[str, Any]] = [
    {
        "name": "find_shelters_in_area",
        "description": """指定エリア内の避難所をOntologyから検索します。
        
        Foundryに登録された避難所マスターデータから、
        位置・条件に合致する避難所を取得します。
        
        フィルタ条件:
        - 開設中のみ
        - 車椅子対応
        - 最低標高
        - 避難所種別
        """,
        "parameters": {
            "type": "object",
            "properties": {
                "min_lat": {
                    "type": "number",
                    "description": "検索範囲の最小緯度"
                },
                "min_lon": {
                    "type": "number",
                    "description": "検索範囲の最小経度"
                },
                "max_lat": {
                    "type": "number",
                    "description": "検索範囲の最大緯度"
                },
                "max_lon": {
                    "type": "number",
                    "description": "検索範囲の最大経度"
                },
                "require_open": {
                    "type": "boolean",
                    "description": "開設中の避難所のみを検索",
                    "default": True
                },
                "require_wheelchair": {
                    "type": "boolean",
                    "description": "車椅子対応必須",
                    "default": False
                },
                "min_elevation": {
                    "type": "number",
                    "description": "最低標高（メートル）"
                }
            },
            "required": ["min_lat", "min_lon", "max_lat", "max_lon"]
        }
    },
    {
        "name": "get_shelter_status",
        "description": """避難所の現在の状態をOntologyから取得します。
        
        リアルタイムの開設状況、収容人数、混雑度などを確認できます。
        """,
        "parameters": {
            "type": "object",
            "properties": {
                "shelter_id": {
                    "type": "string",
                    "description": "避難所ID"
                }
            },
            "required": ["shelter_id"]
        }
    },
    {
        "name": "update_shelter_status",
        "description": """避難所の状態を更新します。
        
        開設状況や現在の収容人数を更新できます。
        このアクションには適切な権限が必要です。
        """,
        "parameters": {
            "type": "object",
            "properties": {
                "shelter_id": {
                    "type": "string",
                    "description": "避難所ID"
                },
                "open_status": {
                    "type": "string",
                    "enum": ["open", "closed", "preparing", "full"],
                    "description": "開設状況"
                },
                "current_occupancy": {
                    "type": "integer",
                    "description": "現在の利用者数"
                }
            },
            "required": ["shelter_id", "open_status"]
        }
    },
    {
        "name": "get_active_disasters",
        "description": """発生中の災害イベントをOntologyから取得します。
        
        現在有効な災害情報（警報、注意報、避難指示等）を確認できます。
        特定の災害種別でフィルタリングすることも可能です。
        """,
        "parameters": {
            "type": "object",
            "properties": {
                "disaster_types": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": ["flood", "heavy_rain", "landslide", "earthquake", "tsunami", "typhoon"]
                    },
                    "description": "取得する災害種別（省略時は全種別）"
                }
            }
        }
    },
    {
        "name": "get_river_levels",
        "description": """河川の現在水位をOntologyから取得します。
        
        水位観測所のリアルタイムデータを確認できます。
        危険水位を超えている観測所のみをフィルタすることも可能です。
        """,
        "parameters": {
            "type": "object",
            "properties": {
                "station_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "取得する観測所ID（省略時は全観測所）"
                },
                "only_dangerous": {
                    "type": "boolean",
                    "description": "危険水位を超えた観測所のみ",
                    "default": False
                }
            }
        }
    }
]


# =============================================================================
# AIP Logic 関数定義
# =============================================================================

AIP_LOGIC_FUNCTIONS: List[Dict[str, Any]] = [
    {
        "name": "evaluate_evacuation_need",
        "description": """避難の必要性を総合評価するAIP Logic関数。
        
        入力:
        - 位置情報（緯度経度）
        - ユーザー属性（車椅子、高齢者等）
        
        処理:
        1. 現在地の災害リスクを評価
        2. 発生中の災害イベントを確認
        3. 周辺の河川水位を確認
        4. 総合的な避難必要性を判定
        
        出力:
        - 避難推奨レベル
        - 推奨避難所
        - 推奨行動
        """,
        "input_schema": {
            "type": "object",
            "properties": {
                "latitude": {"type": "number"},
                "longitude": {"type": "number"},
                "user_attributes": {
                    "type": "object",
                    "properties": {
                        "wheelchair": {"type": "boolean"},
                        "elderly": {"type": "boolean"},
                        "pets": {"type": "boolean"},
                        "children": {"type": "boolean"}
                    }
                }
            },
            "required": ["latitude", "longitude"]
        },
        "output_schema": {
            "type": "object",
            "properties": {
                "evacuation_needed": {"type": "boolean"},
                "urgency_level": {"type": "string", "enum": ["none", "low", "medium", "high", "immediate"]},
                "recommended_shelter": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string"},
                        "name": {"type": "string"},
                        "distance_km": {"type": "number"}
                    }
                },
                "recommended_actions": {"type": "array", "items": {"type": "string"}},
                "risk_summary": {"type": "string"}
            }
        }
    }
]


# =============================================================================
# システムプロンプト（AIP Agent Studio用）
# =============================================================================

AIP_AGENT_SYSTEM_PROMPT = """あなたは「避難支援エージェント」です。
Palantir Foundry上の災害・避難所データと、国土地理院の地理空間データを活用して、
ユーザーの避難判断を支援します。

# あなたができること

## 1. 災害リスクの評価
- 浸水リスク（洪水浸水想定区域）の判定
- 土砂災害警戒区域（イエロー/レッドゾーン）の判定
- 総合的な災害リスクの評価

## 2. 避難所の検索と推奨
- 周辺の避難所をFoundry Ontologyから検索
- 車椅子対応、標高条件などでフィルタリング
- ユーザー条件に最適な避難所を推奨
- リアルタイムの開設状況・混雑度を確認

## 3. 避難経路の評価
- 標高プロファイルから勾配を確認
- 経路上の危険箇所を特定
- 車椅子対応ルートかどうかを判定

## 4. リアルタイム情報の統合
- 発生中の災害イベントを取得
- 河川水位データを確認
- 避難指示・警報の状況を把握

# 行動指針

1. **安全最優先**: 常に最も安全な選択肢を提案する
2. **根拠の明示**: 判断の根拠となるデータ（標高、警戒区域、水位等）を説明する
3. **個別対応**: ユーザーの状況（車椅子、高齢者等）に応じたアドバイス
4. **リアルタイム性**: 最新のFoundryデータを参照する

# 応答形式

1. **結論を最初に** - 避難が必要かどうかを明確に
2. **根拠を説明** - なぜそう判断したかをデータとともに
3. **具体的なアクション** - 何をすべきかを具体的に
4. **注意事項** - 制約や留意点があれば追記

# 制約

- 医療的な判断は行いません
- 最終判断はユーザー自身に委ねてください
- 実際の災害時は自治体の指示に従ってください
"""
