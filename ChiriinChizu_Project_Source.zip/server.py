"""
FastAPI バックエンドサーバー

避難支援APIとWebUIを提供
"""

import asyncio
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

# ロギング設定
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# FastAPIアプリ
app = FastAPI(
    title="避難支援 Agentic RAG API",
    description="国土地理院地図API × Foundry IQ 避難支援システム",
    version="1.0.0"
)

# セキュリティ: CORS設定 (ISO 27002/27017)
# 本番環境では環境変数から許可オリジンを読み込む
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],  # 必要最小限に制限
    allow_headers=["*"],
)

@app.middleware("http")
async def add_security_headers(request, call_next):
    """セキュリティヘッダーを追加 (OWASP / ISO 27002)"""
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = "default-src 'self'; img-src 'self' https: data:; style-src 'self' 'unsafe-inline' https:; script-src 'self' 'unsafe-inline' https:;"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return response


# =============================================================================
# リクエスト/レスポンスモデル
# =============================================================================

class LocationRequest(BaseModel):
    """位置情報リクエスト"""
    latitude: float
    longitude: float


class ElevationResponse(BaseModel):
    """標高レスポンス"""
    elevation: float
    success: bool
    data_source: Optional[str] = None
    error: Optional[str] = None


class FloodRiskResponse(BaseModel):
    """浸水リスクレスポンス"""
    flood_depth: float
    risk_level: str
    recommendation: str
    success: bool


class LandslideRiskResponse(BaseModel):
    """土砂災害リスクレスポンス"""
    is_in_hazard_zone: bool
    risk_level: str
    zones: List[Dict[str, Any]]
    recommendation: str
    success: bool


class ComprehensiveRiskResponse(BaseModel):
    """総合リスクレスポンス"""
    overall_risk_level: str
    evacuation_priority: int
    flood_risk: Dict[str, Any]
    landslide_risk: Dict[str, Any]
    summary: str


class ShelterSearchRequest(BaseModel):
    """避難所検索リクエスト"""
    latitude: float
    longitude: float
    radius_km: float = 2.0
    require_wheelchair: bool = False
    require_open: bool = False


class ShelterResponse(BaseModel):
    """避難所レスポンス"""
    id: str
    name: str
    address: str
    latitude: float
    longitude: float
    elevation: float
    capacity: int
    current_occupancy: int
    open_status: str
    is_wheelchair_accessible: bool


class ChatRequest(BaseModel):
    """チャットリクエスト"""
    message: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class ChatResponse(BaseModel):
    """チャットレスポンス"""
    response: str
    tools_used: List[str]
    sources: List[str]


# =============================================================================
# APIエンドポイント
# =============================================================================

@app.get("/")
async def root():
    """ルート - UIを返す"""
    ui_path = Path(__file__).parent / "ui" / "index.html"
    if ui_path.exists():
        return FileResponse(ui_path)
    return {"message": "避難支援 Agentic RAG API", "status": "running"}


@app.get("/api/health")
async def health_check():
    """ヘルスチェック"""
    return {"status": "healthy", "version": "1.0.0"}


@app.post("/api/elevation", response_model=ElevationResponse)
async def get_elevation(request: LocationRequest):
    """標高を取得"""
    try:
        from src.tools.gsi_tools import get_elevation as gsi_get_elevation
        
        result = await gsi_get_elevation(request.latitude, request.longitude)
        
        return ElevationResponse(
            elevation=result.get("elevation", 0.0),
            success=result.get("success", False),
            data_source=result.get("data_source"),
            error=result.get("error")
        )
    except Exception as e:
        logger.error(f"標高取得エラー: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/flood-risk", response_model=FloodRiskResponse)
async def check_flood_risk(request: LocationRequest):
    """浸水リスクを判定"""
    try:
        from src.tools.hazard_tools import check_flood_risk as hazard_check_flood_risk
        
        result = await hazard_check_flood_risk(request.latitude, request.longitude)
        
        return FloodRiskResponse(
            flood_depth=result.get("flood_depth", 0.0),
            risk_level=result.get("risk_level", "unknown"),
            recommendation=result.get("recommendation", ""),
            success=result.get("success", False)
        )
    except Exception as e:
        logger.error(f"浸水リスク判定エラー: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/landslide-risk", response_model=LandslideRiskResponse)
async def check_landslide_risk(request: LocationRequest):
    """土砂災害リスクを判定"""
    try:
        from src.tools.hazard_tools import check_landslide_zone
        
        result = await check_landslide_zone(request.latitude, request.longitude)
        
        return LandslideRiskResponse(
            is_in_hazard_zone=result.get("is_in_hazard_zone", False),
            risk_level=result.get("risk_level", "none"),
            zones=result.get("zones", []),
            recommendation=result.get("recommendation", ""),
            success=result.get("success", False)
        )
    except Exception as e:
        logger.error(f"土砂災害リスク判定エラー: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/comprehensive-risk", response_model=ComprehensiveRiskResponse)
async def get_comprehensive_risk(request: LocationRequest):
    """総合リスクを評価"""
    try:
        from src.tools.hazard_tools import check_comprehensive_risk
        
        result = await check_comprehensive_risk(request.latitude, request.longitude)
        
        return ComprehensiveRiskResponse(
            overall_risk_level=result.get("overall_risk_level", "unknown"),
            evacuation_priority=result.get("evacuation_priority", 5),
            flood_risk=result.get("flood_risk", {}),
            landslide_risk=result.get("landslide_risk", {}),
            summary=result.get("summary", "")
        )
    except Exception as e:
        logger.error(f"総合リスク評価エラー: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/shelters/search")
async def search_shelters(request: ShelterSearchRequest):
    """避難所を検索"""
    try:
        from src.tools.shelter_tools import find_nearby_shelters
        
        result = await find_nearby_shelters(
            latitude=request.latitude,
            longitude=request.longitude,
            radius_km=request.radius_km
        )
        
        return result
    except Exception as e:
        logger.error(f"避難所検索エラー: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/shelters/recommend")
async def recommend_shelter(request: ShelterSearchRequest):
    """避難所を推奨"""
    try:
        from src.tools.shelter_tools import recommend_shelter as shelter_recommend
        
        result = await shelter_recommend(
            latitude=request.latitude,
            longitude=request.longitude,
            wheelchair=request.require_wheelchair
        )
        
        return result
    except Exception as e:
        logger.error(f"避難所推奨エラー: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/shelters/{shelter_id}")
async def get_shelter(shelter_id: str):
    """避難所の詳細を取得"""
    try:
        from src.tools.shelter_tools import get_shelter_status
        
        result = await get_shelter_status(shelter_id)
        
        if not result.get("id"):
            raise HTTPException(status_code=404, detail="避難所が見つかりません")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"避難所取得エラー: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """チャット（RAGエージェント）"""
    try:
        from src.knowledge_base.retriever import get_rag_chain
        
        chain = get_rag_chain()
        
        # 位置情報があればクエリに追加
        query = request.message
        if request.latitude and request.longitude:
            query += f"（位置: 緯度{request.latitude:.4f}, 経度{request.longitude:.4f}）"
        
        result = chain.query(query)
        
        return ChatResponse(
            response=result.get("answer", "回答を生成できませんでした。"),
            tools_used=[],  # RAGチェーンではツール情報なし
            sources=result.get("sources", [])
        )
    except Exception as e:
        logger.error(f"チャットエラー: {e}")
        return ChatResponse(
            response=f"エラーが発生しました: {str(e)}",
            tools_used=[],
            sources=[]
        )


@app.get("/api/tiles/{layer}/{z}/{x}/{y}.png")
async def get_tile_url(layer: str, z: int, x: int, y: int):
    """地理院タイルURLを生成（プロキシ用）"""
    from src.config import GSITileLayers
    
    url = GSITileLayers.get_tile_url(layer, z, x, y)
    
    return {"url": url, "layer": layer, "z": z, "x": x, "y": y}


# =============================================================================
# 静的ファイル
# =============================================================================

# UIディレクトリがあればマウント
ui_dir = Path(__file__).parent / "ui"
if ui_dir.exists():
    app.mount("/ui", StaticFiles(directory=str(ui_dir), html=True), name="ui")


# =============================================================================
# メイン
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
